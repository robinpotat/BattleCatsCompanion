# Battle Cats Companion

A desktop companion for **The Battle Cats** (EN). It reads your save from
BlueStacks, decodes it, and shows your roster, combos, items, talents/orbs,
an evolve planner, and lets an AI build loadouts and evolve advice.

## Install (for players)

1. Unzip anywhere.
2. Double-click `Setup.bat` (one time) — installs Python if needed, builds a
   private venv, installs packages, and puts a "Battle Cats Companion"
   shortcut on your Desktop.
3. Open the app and click **Detect save** (it closes BlueStacks for you first).

See `SETUP.txt` for troubleshooting.

## Features

- **Roster** — every cat you own with rarity, level, DPS/HP/ATK/range
  (stats from mygamatoto), current form, abilities, talents, orbs.
- **Combos** — all combos available with your cats.
- **Talents & Orbs** — NP spent, equipped orbs, orb inventory.
- **Items** — cat fruit/behemoth stones and battle power-ups, plus your
  **cat food** and **XP**.
- **Evolve** — cats ready (or almost ready) to evolve now, plus an
  **AI recommendation** button.
- **Loadout** — type a stage; the AI looks it up on the wiki and builds a
  10-unit loadout from your roster.
- **Seed** — quick link to the bc-seek seed tracker and a local place to
  save your seed + recent gacha rolls.
- **Updates** — "Check for updates" in the Detect tab + a local update log.

## How it works

- `update_cats.py` — BlueStacks `Data.vhdx` → 7-Zip (bundled) → extract
  `SAVE_DATA` → `BCSFE_Python` (bundled in `cats_app/lib`) → data files.
- Data is cached in `cats_app/cache/bcdata`. It detects the save's game
  version and fetches missing unit data from BCData for that version
  (falling back to the bundled 15.5.0), so newer cats get correct rarity.
- The app is a Flask server (`cats_app/app.py`) opened in a window via
  pywebview (`cats_app/desktop.py`).

## Publishing an update (for the author)

When you ship a new version:

1. Rebuild the zip of the whole package folder.
2. Create a GitHub repo and upload both the zip and a `version.json`:
   ```json
   {
     "version": "0.11.1",
     "changelog": ["Fixed uber rarity for new units", "Added cat food display"],
     "zip_url": "https://raw.githubusercontent.com/YOUR_USER/YOUR_REPO/main/BattleCatsCompanion.zip"
   }
   ```
   (Zip must stay under ~100 MB for raw GitHub links.)
3. Edit `cats_app/updater.py` and set `REPO = "YOUR_USER/YOUR_REPO"`.
4. Bump `cats_app/version.txt` to the same version you publish.

Anyone running the app then sees an "Update available" button in the Detect
tab. The updater never touches `.venv`, `data.db` (their roster), `cache`,
`tmp`, or your update log.

## Everything stays local

The app only talks to: the BCData mirror (unit data), the Battle Cats wiki
(stage pages for loadouts), mygamatoto (stat webhooks), the opencode API
(for the AI), and your update URL. It never uploads your save.
