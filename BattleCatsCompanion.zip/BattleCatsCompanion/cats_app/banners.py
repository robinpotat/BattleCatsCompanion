"""Gacha banner calendar - parses the Battle Cats wiki event schedule JSON.

The wiki keeps the current rotation in Template:CurrentEvents/Schedule.json;
we cache it briefly so the wiki isn't hammered.
"""

import datetime
import json
import os
import time

import requests

APP_DIR = os.path.dirname(os.path.abspath(__file__))
RAW_URL = "https://battlecats.miraheze.org/w/index.php"
TEMPLATE = "Template:CurrentEvents/Schedule.json"
CACHE_FILE = os.path.join(APP_DIR, "cache", "banners_v3.json")
CACHE_TTL = 30 * 60
JST = datetime.timezone(datetime.timedelta(hours=9))
SWITCH_HOUR = 11  # JST - Battle Cats rotates banners/events daily at 11:00 JST
UA = {"User-Agent": "BattleCatsCompanion/1.0 (banner calendar)"}
SESSION = requests.Session()
SESSION.headers.update(UA)

_RANK = {"current": 0, "upcoming": 1, "past": 2}


def _fetch_raw():
    r = SESSION.get(RAW_URL, params={"title": TEMPLATE, "action": "raw"}, timeout=30)
    r.raise_for_status()
    return json.loads(r.text)


def _now():
    return datetime.datetime.now(JST)


def _switch_dt(s):
    """Wiki rows carry date-only ranges; the real live window starts/ends at
    SWITCH_HOUR JST on those dates (the game rotates at 11:00 JST)."""
    try:
        d = datetime.date.fromisoformat(str(s)[:10])
    except (ValueError, TypeError):
        return None
    return datetime.datetime.combine(d, datetime.time(SWITCH_HOUR, 0), tzinfo=JST)


def get_schedule(force=False):
    """Return {gacha:[...], events:[...]} with each item:
    {name, start, end, status: current|upcoming|past, days_left?}."""
    if not force and os.path.exists(CACHE_FILE):
        if time.time() - os.path.getmtime(CACHE_FILE) < CACHE_TTL:
            try:
                with open(CACHE_FILE, encoding="utf-8") as f:
                    return json.load(f)
            except Exception:
                pass
    data = _fetch_raw()
    now = _now()
    today = now.date().isoformat()
    out = {"fetched": now.strftime("%Y-%m-%d %H:%M:%S"),
           "today": today, "gacha": [], "events": []}
    for kind, dest in (("Gacha Schedule", out["gacha"]),
                       ("Event Schedule", out["events"])):
        for row in data.get(kind) or []:
            if len(row) < 3:
                continue
            name, start, end = str(row[0]), str(row[1]), str(row[2])
            start, end = start[:10], end[:10]
            start_dt, end_dt = _switch_dt(start), _switch_dt(end)
            if start_dt is None or end_dt is None:
                continue
            # A banner starting today is NOT live until today's 11:00 JST
            # switch (the previous rotation still runs); likewise one ending
            # today stays live until then.
            if start_dt <= now < end_dt:
                status = "current"
            elif now < start_dt:
                status = "upcoming"
            else:
                status = "past"
            item = {"name": name, "start": start, "end": end, "status": status}
            if status == "current":
                item["days_left"] = (end_dt.date() - now.date()).days
            dest.append(item)
    for dest in (out["gacha"], out["events"]):
        dest.sort(key=lambda e: (_RANK.get(e["status"], 9), e["start"], e["name"]))
    os.makedirs(os.path.dirname(CACHE_FILE), exist_ok=True)
    with open(CACHE_FILE, "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False)
    return out


def schedule_text():
    """Human-readable schedule summary for the AI prompt."""
    s = get_schedule()
    lines = [f"TODAY: {s['today']} (banners rotate at {SWITCH_HOUR}:00 JST - a banner 'starting today' is only live after that hour)", ""]
    cur = [e for e in s["gacha"] if e["status"] == "current"]
    up = [e for e in s["gacha"] if e["status"] == "upcoming"]
    ev = [e for e in s["events"] if e["status"] != "past"]
    lines.append("CURRENT CAPSULE BANNERS (gacha):")
    if not cur:
        lines.append("- (none)")
    for e in cur:
        left = f" ({e['days_left']} days left)" if e.get("days_left") is not None else ""
        lines.append(f"- {e['name']} : {e['start']} ~ {e['end']}{left}")
    lines.append("")
    lines.append("UPCOMING CAPSULE BANNERS:")
    if not up:
        lines.append("- (none)")
    for e in up[:10]:
        lines.append(f"- {e['name']} : {e['start']} ~ {e['end']}")
    lines.append("")
    lines.append("LIVE SPECIAL EVENTS / STAGES:")
    if not ev:
        lines.append("- (none)")
    for e in ev[:12]:
        lines.append(f"- {e['name']} : {e['start']} ~ {e['end']}")
    return "\n".join(lines)
