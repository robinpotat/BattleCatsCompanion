"""Enemy lookup - index + details scraped from the Battle Cats wiki (miraheze).

Everything is cached under cache/enemies/ so the wiki is only hit once per enemy.
"""

import json
import os
import re

import requests

APP_DIR = os.path.dirname(os.path.abspath(__file__))
API = "https://battlecats.miraheze.org/w/api.php"
CACHE_DIR = os.path.join(APP_DIR, "cache", "enemies")
INDEX_FILE = os.path.join(CACHE_DIR, "index.json")
UA = {"User-Agent": "BattleCatsCompanion/1.0 (enemy lookup)"}
SESSION = requests.Session()
SESSION.headers.update(UA)

TRAIT_ORDER = ("Traitless", "Red", "Black", "Metal", "Floating", "Alien",
               "Zombie", "Angel", "Aku", "Relic", "Witch")

TYPE_NAMES = ("Behemoth", "Colossus", "Sage", "Kaijin", "Kamikaze")


def _trait_for(name):
    """Map a wiki trait mention (category name or link label) to a display trait."""
    n = (name or "").strip()
    n = re.sub(r"^category:\s*", "", n, flags=re.I)
    n = re.sub(r"\s+enemies$", "", n, flags=re.I)
    n = n.lower()
    if not n:
        return ""
    direct = {t.lower(): t for t in TRAIT_ORDER}
    if n in direct:
        return direct[n]
    return {
        "dark": "Black",
        "white": "Traitless",
        "typeless": "Traitless",
        "starred alien": "Alien",
        "unstarred alien": "Alien",
        "eva angel": "Angel",
        "eva": "Angel",
        "soul": "Witch",
    }.get(n, "")


def _collect_traits(text, categories):
    found = []

    def add(name):
        t = _trait_for(name)
        if t and t not in found:
            found.append(t)

    tm = re.search(r"\{\{\s*Description\s*(.*?)\}\}", text, re.S | re.I)
    if tm:
        tm2 = re.search(r"\|?\s*Type\s*=\s*(.*?)(?=\n\||\n$)", tm.group(1), re.S | re.I)
        if tm2:
            block = tm2.group(1)
            for m in re.finditer(r"\[\[\s*:?\s*([^\]|]+?)\s*\|\s*([^\]|]+?)\]\]", block):
                add(m.group(1))
                add(m.group(2))
            for m in re.finditer(r"(?<!\w)(Traitless|White|Red|Black|Dark|Metal|Floating|Alien|"
                                 r"Zombie|Angel|Aku|Relic|Soul|Witch|Eva Angel)(?!\w)", block, re.I):
                add(m.group(1))

    head = re.split(r"\n==", text, maxsplit=1)[0]
    for m in re.finditer(r"\[\[\s*:?\s*Category:\s*([^\]|]+?)\s*\|\s*([^\]|]+?)\]\]", head, re.I):
        add(m.group(1))
        add(m.group(2))

    for cat in categories:
        if cat.lower().startswith("category:") and "enemies" in cat.lower():
            add(cat)

    ordered = [t for t in TRAIT_ORDER if t in found]
    ordered += [t for t in found if t not in ordered]
    return ordered


def _collect_types(text, categories):
    """Enemy types like Behemoth / Colossus / Sage, from lead-in links and categories."""
    found = []

    def add(name):
        n = re.sub(r"^category:\s*", "", name or "", flags=re.I)
        n = re.sub(r"\s+enemies$", "", n, flags=re.I).strip()
        for t in TYPE_NAMES:
            if n.lower() == t.lower() and t not in found:
                found.append(t)

    head = re.split(r"\n==", text, maxsplit=1)[0]
    for m in re.finditer(r"\[\[\s*:?\s*Category:\s*([^\]|]+?)\s*\|\s*([^\]|]+?)\]\]", head, re.I):
        add(m.group(1))
        add(m.group(2))
    for cat in categories:
        if cat.lower().startswith("category:") and "enemies" in cat.lower():
            add(cat)
    return found


def _api(params):
    params.setdefault("format", "json")
    params.setdefault("formatversion", "2")
    r = SESSION.get(API, params=params, timeout=30)
    r.raise_for_status()
    return r.json()


def _cache_get(name):
    try:
        with open(os.path.join(CACHE_DIR, name), encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return None


def _cache_put(name, data):
    os.makedirs(CACHE_DIR, exist_ok=True)
    with open(os.path.join(CACHE_DIR, name), "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False)


def _safe(name):
    return re.sub(r"[^A-Za-z0-9_.]+", "_", name)[:120]


def index(force=False):
    """All enemy page titles (cached)."""
    if not force:
        cached = _cache_get("index.json")
        if cached is not None:
            return cached
    titles = []
    cont = None
    for _ in range(80):
        params = {"action": "query", "list": "embeddedin",
                  "eititle": "Template:Enemy Info", "eilimit": 500}
        if cont:
            params.update(cont)
        data = _api(params)
        titles += [x["title"] for x in data["query"]["embeddedin"]]
        cont = data.get("continue")
        if not cont:
            break
    titles = sorted(set(titles))
    _cache_put("index.json", titles)
    return titles


def _page_data(title):
    name = "page_" + _safe(title) + ".json"
    cached = _cache_get(name)
    if cached is not None:
        return cached
    data = _api({"action": "query", "prop": "revisions|categories",
                 "rvprop": "content", "rvslots": "main", "cllimit": 60,
                 "titles": title, "redirects": "1"})
    wikitext = ""
    categories = []
    for page in data["query"]["pages"]:
        wikitext = (page.get("revisions") or [{}])[0].get("slots", {}).get("main", {}).get("content", "")
        categories = [c.get("title", "") for c in page.get("categories") or []]
        break
    out = {"title": title, "wikitext": wikitext, "categories": categories}
    _cache_put(name, out)
    return out


def _strip_wiki(s):
    s = re.sub(r"\[\[File:[^\]]*\]\]", "", s, flags=re.I)
    s = re.sub(r"\[\[([^\]|]*\|)?([^\]]*)\]\]", r"\2", s)
    s = re.sub(r"<[^>]+>", " ", s)
    s = re.sub(r"\{\{[^{}]*\}\}", " ", s)
    s = re.sub(r"'''|''", "", s)
    s = re.sub(r"\s+", " ", s)
    return s.strip()


def _field(block, key):
    m = re.search(r"\|?\s*" + re.escape(key) + r"\s*=\s*(.*?)(?=\n\||\Z)", block, re.I | re.S)
    return _strip_wiki(m.group(1)) if m else ""


def detail(title):
    data = _page_data(title)
    text = data["wikitext"]
    info = {}
    m = re.search(r"\{\{\s*Enemy Info\s*(.*?)\}\}", text, re.S | re.I)
    if m:
        block = m.group(1)
        for key in ("name", "image", "first appearance", "latest appearance", "money drop"):
            info[key] = _field(block, key)

    traits = _collect_traits(text, data["categories"])

    intro = ""
    head = re.split(r"\n==", text, maxsplit=1)[0]
    intro = _strip_wiki(head)

    variants = []
    vm = re.search(r"\{\{\s*Variant\s*(.*?)\}\}", text, re.S | re.I)
    if vm:
        lines = [s[1:].strip() for s in vm.group(1).splitlines() if s.strip().startswith("|")]
        want_name = False
        for line in lines:
            if re.match(r"^[^|=]+\s*=", line) or not line:
                want_name = True
                continue
            if want_name:
                name = _strip_wiki(line)
                if 0 < len(name) <= 60:
                    variants.append(name)
                want_name = False
            else:
                want_name = True

    return {
        "title": title,
        "info": info,
        "traits": traits,
        "types": _collect_types(text, data["categories"]),
        "intro": intro,
        "variants": variants,
        "image": info.get("image") or "",
    }


def _is_crit_cat(c):
    return any("crit" in (a or "").lower() for a in (c.get("abilities") or []))


def _entry(c, hit=None):
    return {
        "id": c["id"], "name": c["base_name"], "form": c["cur_name"],
        "rarity": c["rarity"], "level": c["level_base"],
        "traits": sorted(hit) if hit else (c.get("traits") or []),
        "abilities": (c.get("abilities") or [])[:3],
        "dps": (c.get("stats") or {}).get("dps"),
    }


def counters(enemy_traits):
    """Owned cats that counter the enemy's traits (crit cats for Metal, top DPS for traitless)."""
    try:
        import db
        cats = db.all_cats()
    except Exception:
        return []
    if not cats:
        return []
    et = {t for t in enemy_traits if t}
    if et and not (et - {"Traitless", "White"}):
        et = set()

    if "Metal" in et:
        crits = [c for c in cats if _is_crit_cat(c)]
        if crits:
            crits.sort(key=lambda c: (-(c["level_base"] or 0), -((c.get("stats") or {}).get("dps") or 0)))
            return [_entry(c) for c in crits[:14]]

    if et:
        matches = []
        for c in cats:
            hit = set(c.get("traits") or []) & et
            if hit:
                matches.append(_entry(c, hit))
        matches.sort(key=lambda m: (-(m["level"] or 0), -(m["dps"] or 0)))
        return matches[:14]
    top = sorted(cats, key=lambda c: -((c.get("stats") or {}).get("dps") or 0))[:14]
    return [_entry(c) for c in top]


def search(q):
    idx = index()
    ql = q.strip().lower()
    if not ql:
        return idx[:40]
    tokens = [t for t in re.split(r"[^a-z0-9]+", ql) if t]
    out = [t for t in idx if ql in t.lower()]
    if len(out) < 5:
        for t in idx:
            if any(tok in t.lower() for tok in tokens):
                out.append(t)
    seen = []
    for t in out:
        if t not in seen:
            seen.append(t)
    return seen[:40]
