import os
import sys
import json
import threading
import time
import contextlib
import io

PROJECT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if PROJECT_DIR not in sys.path:
    sys.path.insert(0, PROJECT_DIR)

import update_cats as uc  # noqa: E402
import db  # noqa: E402
import stats  # noqa: E402


class TeeOut:
    def __init__(self, stream, sink):
        self.stream = stream
        self.sink = sink

    def write(self, data):
        if self.stream is not None:
            try:
                self.stream.write(data)
            except Exception:
                pass
        if data.strip():
            self.sink.append(data.rstrip("\n"))
        return len(data)

    def flush(self):
        try:
            self.stream.flush()
        except Exception:
            pass


class DetectRunner:
    def __init__(self):
        self.lock = threading.Lock()
        self.running = False
        self.done = False
        self.error = None
        self.log_lines = []
        self.result = None

    def _log(self, line):
        with self.lock:
            self.log_lines.append(line)

    def snapshot(self):
        with self.lock:
            return {
                "running": self.running,
                "done": self.done,
                "error": self.error,
                "log": list(self.log_lines),
                "result": self.result,
            }

    def start(self):
        if self.running:
            return False
        with self.lock:
            self.running = True
            self.done = False
            self.error = None
            self.result = None
            self.log_lines = []
        threading.Thread(target=self._run, daemon=True).start()
        return True

    def _run(self):
        log = self._log
        try:
            uc.SECTIONS.clear()
            sink = []
            real_out = sys.stdout
            real_err = sys.stderr
            try:
                sys.stdout = TeeOut(real_out, sink)
                sys.stderr = TeeOut(real_err, sink)
                with contextlib.redirect_stdout(sys.stdout):
                    with contextlib.redirect_stderr(sys.stderr):
                        result = self._pipeline()
            finally:
                sys.stdout = real_out
                sys.stderr = real_err

            with self.lock:
                self.result = result
                self.done = True
                self.running = False
            for line in sink:
                self._log(line)
        except SystemExit:
            self._log("ERROR: pipeline aborted")
            with self.lock:
                self.error = "Pipeline aborted (see log)"
                self.done = True
                self.running = False
        except Exception as e:
            import traceback
            self._log("ERROR: " + str(e))
            for l in traceback.format_exc().splitlines():
                self._log(l)
            with self.lock:
                self.error = str(e)
                self.done = True
                self.running = False

    def _pipeline(self):
        log = self._log
        save_path = uc.step_extract()
        save_mtime = time.ctime(os.path.getmtime(save_path))
        (cats, base_l, plus_l, cur_f, unl_f, owned, talents, orb_equips,
         talent_orbs, cannons, cat_fruit, battle_items, catseyes, xp, cat_food, np) = uc.step_parse(save_path)
        save_ver = uc._ver_str(uc.SAVE_VERSION)
        prev_data = db.get_meta("data_version")
        if prev_data and prev_data != save_ver:
            log(f"  game updated: cached data was v{prev_data}, save is v{save_ver} - refreshing ...")
            uc.invalidate_cache()
        uc.step_fetch(owned)
        uc.step_combo_fetch()
        items = uc.build_items(cat_fruit, battle_items, catseyes)
        rows = uc.step_build(cats, base_l, plus_l, cur_f, unl_f, owned, save_mtime, talents, orb_equips)
        combos = uc.step_combos(owned, cur_f, unl_f, len(rows))
        uc.step_talents(owned, talents, orb_equips, talent_orbs, len(rows))
        uc.step_combine()
        stats.ensure_cache()
        stats.attach_stats(rows, log=log)

        n_cats = db.store_cats(rows)
        n_combos = db.store_combos(combos)
        orb_names = uc.load_orb_names()
        inv = {orb_names.get(int(k), f"Orb {k}"): v for k, v in talent_orbs.items() if v > 0}
        db.store_orb_inventory(inv)
        db.set_meta("last_detect", time.strftime("%Y-%m-%d %H:%M:%S"))
        db.set_meta("game_version", uc.GAME_VERSION)
        db.set_meta("data_version", save_ver)
        db.set_meta("save_version", save_ver)
        db.set_meta("cannons", json.dumps(cannons))
        db.set_meta("items", json.dumps(items, ensure_ascii=False))
        db.set_meta("xp", str(xp))
        db.set_meta("catfood", str(cat_food))
        db.set_meta("np", str(np))
        log(f"  cat food: {cat_food:,}")
        log("  xp: {:,}".format(xp))
        log("  np: {:,}".format(np))
        log("  items: " + ", ".join(f"{it['name']} x{it['count']}" for it in items["battle_items"])
            + " | cat fruit/behemoth: " + ", ".join(f"{it['name']} x{it['count']}" for it in items["cat_fruit"] if it["count"] > 0))
        if items.get("catseyes"):
            log("  catseyes: " + ", ".join(f"{it['name']} x{it['count']}" for it in items["catseyes"] if it["count"] > 0))

        changes_path = os.path.join(PROJECT_DIR, "cats_changes.txt")
        prev_changes_mtime = os.path.getmtime(changes_path) if os.path.exists(changes_path) else 0
        uc.summary(rows)
        uc.deliver()

        from collections import Counter
        rc = Counter(r["rarity"] for r in rows)
        log("Rarity breakdown: " + ", ".join(f"{k}={rc.get(k, 0)}" for k in uc.RARITY_NAMES.values()))
        unknown = [r["id"] for r in rows if r["rarity_id"] < 0]
        if unknown:
            log("  WARNING: cats with unknown rarity (missing in data): " + ", ".join(str(i) for i in unknown))

        changes = read_last_changes(prev_changes_mtime)
        log(f"Detect complete: {n_cats} cats, {n_combos} combos stored.")
        return {
            "cats": n_cats,
            "combos": n_combos,
            "orbs": len(inv),
            "changes": changes,
            "rarity": dict(rc),
            "catfood": cat_food,
            "xp": xp,
            "np": np,
        }


def read_last_changes(since=None):
    path = os.path.join(PROJECT_DIR, "cats_changes.txt")
    try:
        with open(path, encoding="utf-8") as f:
            content = f.read().strip()
        mtime = os.path.getmtime(path)
    except Exception:
        return []
    if since is not None and mtime <= since:
        return []
    entries = content.split("\n===== ")
    if not entries:
        return []
    last = entries[-1]
    if not last.startswith("===== "):
        last = "===== " + last
    return [l.rstrip() for l in last.splitlines()]
