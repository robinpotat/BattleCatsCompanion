import json
import os
import sqlite3

APP_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(APP_DIR, "data.db")


def connect():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    conn = connect()
    c = conn.cursor()
    c.executescript("""
    CREATE TABLE IF NOT EXISTS meta (
        key TEXT PRIMARY KEY,
        value TEXT
    );
    CREATE TABLE IF NOT EXISTS cats (
        id INTEGER PRIMARY KEY,
        base_name TEXT,
        rarity TEXT,
        rarity_id INTEGER,
        level_base INTEGER,
        level_plus INTEGER,
        cur_name TEXT,
        cur_label TEXT,
        cur INTEGER,
        unl INTEGER,
        mf INTEGER,
        true_avail TEXT,
        traits TEXT,
        abilities TEXT,
        immunities TEXT,
        talents_spent TEXT,
        orbs TEXT,
        stats TEXT,
        evolve TEXT
    );
    CREATE TABLE IF NOT EXISTS combos (
        name TEXT,
        effect TEXT,
        value TEXT,
        members TEXT,
        note TEXT
    );
    CREATE TABLE IF NOT EXISTS orb_inventory (
        orb_name TEXT PRIMARY KEY,
        count INTEGER
    );
    """)
    cols = [r[1] for r in c.execute("PRAGMA table_info(cats)").fetchall()]
    if "stats" not in cols:
        c.execute("ALTER TABLE cats ADD COLUMN stats TEXT")
    if "evolve" not in cols:
        c.execute("ALTER TABLE cats ADD COLUMN evolve TEXT")
    conn.commit()
    conn.close()


def set_meta(key, value):
    conn = connect()
    conn.execute("INSERT OR REPLACE INTO meta(key, value) VALUES(?, ?)", (key, str(value)))
    conn.commit()
    conn.close()


def get_meta(key):
    conn = connect()
    row = conn.execute("SELECT value FROM meta WHERE key=?", (key,)).fetchone()
    conn.close()
    return row["value"] if row else None


def store_cats(rows):
    conn = connect()
    conn.execute("DELETE FROM cats")
    for r in rows:
        conn.execute("""INSERT INTO cats(id, base_name, rarity, rarity_id, level_base, level_plus,
                       cur_name, cur_label, cur, unl, mf, true_avail, traits, abilities, immunities,
                       talents_spent, orbs, stats, evolve)
                       VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                     (r["id"], r["base_name"], r["rarity"], r["rarity_id"],
                      r["level_base"], r["level_plus"], r["cur_name"], r["cur_label"],
                      r["cur"], r["unl"], r["mf"], str(r["true_avail"]),
                      json.dumps(r["traits"], ensure_ascii=False),
                      json.dumps(r["abilities"], ensure_ascii=False),
                      json.dumps(r["immunities"], ensure_ascii=False),
                      json.dumps(r["talents_spent"], ensure_ascii=False),
                      json.dumps(r["orbs"], ensure_ascii=False),
                      json.dumps(r.get("stats"), ensure_ascii=False),
                      json.dumps(r.get("evolve"), ensure_ascii=False)))
    conn.commit()
    conn.close()
    return len(rows)


def store_combos(combos):
    conn = connect()
    conn.execute("DELETE FROM combos")
    for c in combos:
        conn.execute("INSERT INTO combos(name, effect, value, members, note) VALUES(?,?,?,?,?)",
                     (c["name"], c["effect"], c["value"], c["members_str"], c["note"]))
    conn.commit()
    conn.close()
    return len(combos)


def store_orb_inventory(inv):
    conn = connect()
    conn.execute("DELETE FROM orb_inventory")
    for name, count in inv.items():
        conn.execute("INSERT OR REPLACE INTO orb_inventory(orb_name, count) VALUES(?,?)", (name, count))
    conn.commit()
    conn.close()


def all_cats():
    conn = connect()
    rows = conn.execute("SELECT * FROM cats ORDER BY rarity_id, base_name COLLATE NOCASE").fetchall()
    conn.close()
    out = []
    for r in rows:
        d = dict(r)
        d["traits"] = json.loads(d["traits"]) if d["traits"] else []
        d["abilities"] = json.loads(d["abilities"]) if d["abilities"] else []
        d["immunities"] = json.loads(d["immunities"]) if d["immunities"] else []
        d["talents_spent"] = json.loads(d["talents_spent"]) if d["talents_spent"] else []
        d["orbs"] = json.loads(d["orbs"]) if d["orbs"] else []
        d["stats"] = json.loads(d["stats"]) if d["stats"] else None
        d["evolve"] = json.loads(d["evolve"]) if d["evolve"] else {}
        out.append(d)
    return out


def all_combos():
    conn = connect()
    rows = conn.execute("SELECT * FROM combos ORDER BY name COLLATE NOCASE").fetchall()
    conn.close()
    return [dict(r) for r in rows]


def orb_inventory():
    conn = connect()
    rows = conn.execute("SELECT orb_name, count FROM orb_inventory ORDER BY orb_name").fetchall()
    conn.close()
    return [dict(r) for r in rows]


def cats_with_talents():
    return [c for c in all_cats() if c["talents_spent"]]


def cats_with_orbs():
    return [c for c in all_cats() if c["orbs"] and any(o["name"] != "(empty)" for o in c["orbs"])]


def stats():
    conn = connect()
    n_cats = conn.execute("SELECT COUNT(*) FROM cats").fetchone()[0]
    n_combos = conn.execute("SELECT COUNT(*) FROM combos").fetchone()[0]
    conn.close()
    catfood = get_meta("catfood")
    xp = get_meta("xp")
    np = get_meta("np")
    return {
        "cats_owned": n_cats,
        "combos": n_combos,
        "last_detect": get_meta("last_detect"),
        "game_version": get_meta("game_version") or "unknown",
        "data_version": get_meta("data_version") or get_meta("game_version") or "unknown",
        "save_version": get_meta("save_version") or "",
        "catfood": int(catfood) if catfood else None,
        "xp": int(xp) if xp else None,
        "np": int(np) if np else None,
    }
