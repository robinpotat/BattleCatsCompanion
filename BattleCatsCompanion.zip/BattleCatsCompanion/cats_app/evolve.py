import json
from urllib.parse import quote

import db

FORM_LABELS = {0: "Base", 1: "Evolved", 2: "True", 3: "Ultra"}

WIKI_BASE = "https://battlecats.miraheze.org/wiki/"
_FARM_PAGES = {
    "Cat Fruit": "Cat fruit",
    "Epic Catfruit": "Epic Catfruit Seed",
}


def _farm_url(name):
    """Wiki page that lists the stages which drop this catfruit/stone."""
    title = _FARM_PAGES.get(name)
    if title is None:
        if name.endswith("Catfruit"):
            title = name + " Seed"  # e.g. "Purple Catfruit" -> "Purple Catfruit Seed"
        elif "stone" in name.lower():
            title = "Behemoth Stone"
        else:
            title = name
    return WIKI_BASE + quote(title.replace(" ", "_"), safe="()")


def plan():
    """Return which cats can evolve to their next form right now.

    Reads cats + cat fruit inventory + user XP from the DB and works out, for
    every cat that still has a higher form available, whether that evolution is
    affordable now (level ok, XP ok, all items owned), and if not, why not.
    """
    cats = db.all_cats()

    items = {}
    raw_items = db.get_meta("items")
    if raw_items:
        try:
            items = {f.get("id"): f.get("count", 0) for f in json.loads(raw_items).get("cat_fruit", [])}
        except Exception:
            items = {}

    raw_xp = db.get_meta("xp")
    xp = int(raw_xp) if raw_xp else 0

    ready, almost = [], []
    for c in cats:
        ev = c.get("evolve") or {}
        reqs = ev.get("forms") or {}
        high = max(c.get("cur", 0), c.get("unl", 0))
        if c.get("mf", 0) <= high:
            continue
        nxt = high + 1
        req = reqs.get(str(nxt))
        if not req:
            continue

        stats = c.get("stats") or {}
        nf = (stats.get("forms") or {}).get(str(nxt)) or {}
        target = nf.get("form_name") or f"{c['base_name']} (Form {nxt})"
        target_label = FORM_LABELS.get(nxt, f"F{nxt}")

        special = bool(req.get("special"))
        need_level = req.get("level")
        need_xp = req.get("xp", 0) or 0
        need_items = [it for it in req.get("items", []) if it.get("count", 0) > 0]
        have_items = [{**it, "have": items.get(it["id"], 0)} for it in need_items]
        missing_items = [it for it in have_items if it["have"] < it["count"]]

        level_ok = special or (need_level is not None and c.get("level_base", 0) >= need_level)
        xp_ok = xp >= need_xp
        items_ok = not missing_items

        blockers = []
        if special:
            blockers.append("special unlock (no catfruit)")
        elif not level_ok:
            blockers.append(f"needs Lv{need_level} (now Lv{c.get('level_base')})")
        if not xp_ok:
            blockers.append(f"needs {need_xp:,} XP (have {xp:,})")
        for it in missing_items:
            blockers.append(f"needs {it['count']} {it['name']} (have {it['have']})")

        entry = {
            "id": c["id"],
            "name": c["base_name"],
            "rarity": c["rarity"],
            "level": f"Lv{c.get('level_base')}+{c.get('level_plus')}",
            "cur_name": c.get("cur_name"),
            "form": nxt,
            "form_label": target_label,
            "form_name": target,
            "special": special,
            "need_level": need_level,
            "need_xp": need_xp,
            "items": have_items,
            "missing": [{
                "name": it["name"], "have": it["have"], "count": it["count"],
                "url": _farm_url(it["name"]),
            } for it in missing_items],
            "blockers": blockers,
        }
        ready_ok = (not special) and level_ok and xp_ok and items_ok
        entry["ready_except_items"] = (not special) and level_ok and xp_ok
        (ready if ready_ok else almost).append(entry)

    ready.sort(key=lambda e: (e["rarity"], e["name"].lower()))
    almost.sort(key=lambda e: (
        e["special"],
        0 if e["ready_except_items"] else 1,  # cats blocked only by items first
        len(e["blockers"]), e["rarity"], e["name"].lower()))

    missing = {}
    for e in almost:
        for it in e["items"]:
            if it["have"] < it["count"]:
                missing[it["name"]] = missing.get(it["name"], 0) + (it["count"] - it["have"])

    return {
        "xp": xp,
        "ready": ready,
        "almost": almost,
        "ready_count": len(ready),
        "almost_count": len(almost),
        "missing_fruit": [{"name": k, "need": v} for k, v in sorted(missing.items())],
    }


def plan_text():
    """Compact one-line summary of affordable evolutions for the AI prompt."""
    p = plan()
    if not p["ready"]:
        return "No true/ultra evolutions are affordable with your current items and XP."
    lines = [f"EVOLUTIONS YOU CAN AFFORD RIGHT NOW ({p['ready_count']}):"]
    for e in p["ready"]:
        it = ", ".join(f"{it['name']} x{it['count']}" for it in e["items"]) or "no items"
        lines.append(f"  {e['name']} -> {e['form_name']} ({e['form_label']}): {it}, {e['need_xp']:,} XP")
    return "\n".join(lines)


def plan_detail_text():
    """Full planner detail (ready + almost, with blockers) for the AI advice prompt."""
    p = plan()
    lines = [f"XP on hand: {p['xp']:,}"]
    lines.append("")
    lines.append(f"READY TO EVOLVE NOW ({p['ready_count']}):")
    if p["ready"]:
        for e in p["ready"]:
            it = ", ".join(f"{it['name']} {it['have']}/{it['count']}" for it in e["items"]) or "no items needed"
            lines.append(f"  - {e['name']} ({e['rarity']}) Lv{e['level']} -> {e['form_name']} "
                         f"[{e['form_label']}]: {it}; {e['need_xp']:,} XP")
    else:
        lines.append("  (none)")
    lines.append("")
    lines.append(f"ALMOST (missing level / XP / items; blockers shown):")
    for e in p["almost"]:
        blk = " | ".join(e["blockers"]) or ""
        it = ", ".join(f"{it['name']} {it['have']}/{it['count']}" for it in e["items"]) or "no items needed"
        lines.append(f"  - {e['name']} ({e['rarity']}) Lv{e['level']} -> {e['form_name']} "
                     f"[{e['form_label']}]: {it}; {e['need_xp']:,} XP  [{blk}]")
    if p.get("missing_fruit"):
        lines.append("")
        need = ", ".join(f"{it['name']} x{it['need']}" for it in p["missing_fruit"])
        lines.append(f"TOTAL CATFRUIT/BEHEMOTH MISSING TO EVOLVE EVERYTHING ABOVE: {need}")
    return "\n".join(lines)
