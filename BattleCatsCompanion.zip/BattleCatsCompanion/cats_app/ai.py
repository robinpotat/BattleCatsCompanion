import json
import os
import re
import sqlite3
import subprocess
import threading
import time
import hashlib

import requests

import db
import evolve

APP_DIR = os.path.dirname(os.path.abspath(__file__))
OPCODE_EXE = os.path.join(APP_DIR, "opencode", "opencode.exe")


def _read_model():
    """Model id is in model.txt so it survives app updates; edit that file
    whenever opencode updates and this model is renamed."""
    try:
        with open(os.path.join(APP_DIR, "model.txt"), encoding="utf-8") as f:
            m = f.read().strip()
            if m and not m.startswith("#"):
                return m
    except Exception:
        pass
    return "opencode/big-pickle"


MODEL = _read_model()
TMP_DIR = os.path.join(APP_DIR, "tmp")
CACHE_DIR = os.path.join(TMP_DIR, "loadout_cache")
STAGE_CACHE_FILE = os.path.join(CACHE_DIR, "stages.json")
RESULT_CACHE_FILE = os.path.join(CACHE_DIR, "results.json")

MIRAH = "https://battlecats.miraheze.org"
FANDOM = "https://battle-cats.fandom.com"

# mygamatoto.com is a React frontend over the onestoppress.com API; the stage
# search page filters this all-stages dataset client-side. We mirror that here
# as a fallback for stages the wikis don't cover yet.
MG_STAGES_URL = "https://onestoppress.com/api/allstages"
MG_STAGES_FILE = os.path.join(CACHE_DIR, "mg_stages.json")
MG_STALE_SECONDS = 14 * 86400
MG_SITE = "https://mygamatoto.com"
MG_SEARCH_URL = MG_SITE + "/allstages/search-by-stage-name"
_MG_MEMO = None

# Towers are wiki-only (absent from onestoppress), so keep a query that names a
# tower from resolving to a DIFFERENT tower's floor page.
TOWERS = ("sweet jesus", "heavenly", "infernal", "gates of hell", "citadel")
MAX_STAGE_PAGES = 3

UA = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) BattleCatsLoadoutApp/1.0"}
SESSION = requests.Session()
SESSION.headers.update(UA)


def _api_get(base, params):
    params.setdefault("format", "json")
    params.setdefault("formatversion", "2")
    path = base + "/api.php" if "fandom" in base else base + "/w/api.php"
    r = SESSION.get(path, params=params, timeout=45)
    r.raise_for_status()
    return r.json()


def _page_title_candidate(stage_name):
    return "_".join(w[:1].upper() + w[1:] for w in stage_name.split())


EVENT_WORDS = ("event", "special", "colosseum", "labyrinth", "celebrat", "anniversary",
               "download", "year", "season", "round", "catcademy", "operators", "dojo")

CHAPTERS = {
    "eoc": "Empire of Cats",
    "itf": "Into the Future",
    "cotc": "Cats of the Cosmos",
    "sol": "Stories of Legend",
    "ul": "Uncanny Legends",
    "zl": "Zero Legends",
    "aku": "Aku Realm",
}


def _chapter_of(stage_name):
    """Return (abbr, full name) if the stage name names a story chapter."""
    low = stage_name.lower()
    for abbr, full in CHAPTERS.items():
        if abbr in low or full.lower() in low:
            return abbr, full
    return None, None


def _stage_name_part(stage_name):
    """Strip chapter tokens to get the bare stage name (title-cased)."""
    s = re.sub(r"\([^)]*chapter[^)]*\)", "", stage_name, flags=re.I)
    s = re.sub(r"\b(eoc|itf|cotc|sol|ul|zl|aku)\b", " ", s, flags=re.I)
    s = re.sub(r"\bchapter\s*\d+\b", " ", s, flags=re.I)
    words = [w for w in re.split(r"[^A-Za-z0-9]+", s) if w]
    if not words:
        return None
    return " ".join(w[:1].upper() + w[1:] for w in words)


def _title_candidates(stage_name):
    """Plausible exact wiki titles, highest score first."""
    out = []
    out.append((9000, _page_title_candidate(stage_name)))
    abbr, full = _chapter_of(stage_name)
    name = _stage_name_part(stage_name)
    if name:
        bare = "_".join(name.split())
        out.append((5000, bare))
        if abbr:
            out.append((10000, f"{bare}_({full.replace(' ', '_')})"))
            out.append((8000, f"{bare}_({abbr.upper()})"))
        elif re.search(r"chapter\s*\d+", stage_name, re.I):
            out.append((10000, f"{bare}_({CHAPTERS['eoc'].replace(' ', '_')})"))
    seen, uniq = set(), []
    for score, t in out:
        t = t.strip()
        if t and t not in seen:
            seen.add(t)
            uniq.append((score, t))
    return uniq


def _score_title(hit, stage_name):
    """Score a search result title; negative = reject."""
    low = hit.lower()
    score = 0
    shared = _tokenize(stage_name) & _tokenize(hit)
    score += len(shared) * 10
    abbr, full = _chapter_of(stage_name)
    if full:
        fl = full.lower()
        if fl in low:
            score += 300
        elif any(w in low for w in fl.split()):
            score += 60
    name = _stage_name_part(stage_name)
    if name and name.lower() in low:
        score += 80
    if any(w in low for w in EVENT_WORDS):
        score -= 1000
    return score


def _tokenize(s):
    return {w for w in re.split(r"[^A-Za-z0-9]+", s.lower()) if len(w) >= 2}


def search_wiki(stage_name):
    results = []
    for base in (FANDOM, MIRAH):
        try:
            data = _api_get(base, {"action": "opensearch", "search": stage_name, "limit": 5})
            results.extend((base, h) for h in data.get(1, []))
        except Exception:
            pass
    return results


def fulltext_search(stage_name):
    """Fulltext search fallback (opensearch misses some pages)."""
    results = []
    for base in (FANDOM, MIRAH):
        try:
            data = _api_get(base, {"action": "query", "list": "search",
                                   "srsearch": stage_name, "srlimit": 8})
            results.extend((base, h.get("title")) for h in data.get("query", {}).get("search", []))
        except Exception:
            pass
    return results


def fetch_wikitext(base, title):
    data = _api_get(base, {"action": "parse", "page": title, "prop": "wikitext", "redirects": "1"})
    return data["parse"]["wikitext"]


def strip_wikitext(text, limit=12000):
    text = re.sub(r"<ref[^>]*>.*?</ref>", "", text, flags=re.S)
    text = re.sub(r"<noinclude>.*?</noinclude>", "", text, flags=re.S)
    text = re.sub(r"<includeonly>.*?</includeonly>", "", text, flags=re.S)
    text = re.sub(r"</?[a-zA-Z][^>]*>", "", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    if len(text) > limit:
        text = text[:limit] + "\n...[truncated]"
    return text.strip()


def _cache_load(path, default):
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return default


def _cache_save(path, data):
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False)
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Tower-floor handling (wiki-only data; keep a named tower from resolving
# to another tower's floor page, and build exact "X Tower/Floor N" titles)
# ---------------------------------------------------------------------------


def _tower_name(stage_name):
    """Return the tower a query names, or 'heavenly' as a default when the
    query is a bare '... tower floor N'. None if not a tower query at all."""
    low = re.sub(r"\s+", " ", stage_name.strip().lower())
    for name in TOWERS:
        if name in low:
            return name
    if re.search(r"\btower\b", low) and re.search(r"floor\s*\d+", low):
        return "heavenly"
    return None


def _tower_title_ok(title, tower):
    """Reject a candidate title that belongs to a DIFFERENT tower than the
    one the query named (e.g. 'Sweet Jesus Tower Floor 3' must not resolve to
    'Infernal Tower/Floor 9')."""
    tl = title.lower().replace("_", " ")
    for name in TOWERS:
        if name in tl and "tower" in tl and name != tower:
            return False
    return True


def _tower_floor_candidates(stage_name):
    """Exact wiki titles for 'X Tower Floor N' / 'X Tower N' queries, so the
    lookup never depends on fulltext search ranking to find the right floor."""
    low = re.sub(r"\s+", " ", stage_name.strip().lower())
    m = re.search(r"(?:\bfloor\b[\s/]*)?(\d+)\s*$", low)
    name = _tower_name(stage_name)
    if not name or not m:
        return []
    base = name.title().replace(" ", "_")
    return [(20000, f"{base}_Tower/Floor_{m.group(1)}")]


# ---------------------------------------------------------------------------
# mygamatoto / onestoppress all-stages fallback
# ---------------------------------------------------------------------------


def _mg_load():
    """All-stages dataset (cached for 2 weeks, memoized per process). Never
    raises - returns [] if the cache is missing AND the download fails."""
    global _MG_MEMO
    if _MG_MEMO is not None:
        return _MG_MEMO
    data = []
    try:
        if os.path.exists(MG_STAGES_FILE):
            if time.time() - os.path.getmtime(MG_STAGES_FILE) <= MG_STALE_SECONDS:
                with open(MG_STAGES_FILE, encoding="utf-8") as f:
                    data = json.load(f).get("sampledata", [])
                _MG_MEMO = data
                return data
        r = SESSION.get(MG_STAGES_URL, timeout=90)
        r.raise_for_status()
        data = r.json().get("sampledata") or []
        os.makedirs(os.path.dirname(MG_STAGES_FILE), exist_ok=True)
        tmp = MG_STAGES_FILE + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump({"fetched_at": int(time.time()), "sampledata": data}, f, ensure_ascii=False)
        os.replace(tmp, MG_STAGES_FILE)
        _MG_MEMO = data
    except Exception:
        pass
    return data


def search_stages_mg(stage_name):
    """Best matching onestoppress stages (name substring + token scoring),
    highest score first. Never raises."""
    data = _mg_load()
    if not data:
        return []
    ql = re.sub(r"\s+", " ", stage_name.strip().lower())
    if not ql:
        return []
    tokens = [t for t in _tokenize(ql) if len(t) >= 3]
    out = []
    for s in data:
        name = (s.get("stage") or "").strip()
        if not name:
            continue
        nl = name.lower()
        if ql in nl:
            out.append(s)
            continue
        if tokens and sum(1 for t in tokens if t in nl) == len(tokens):
            out.append(s)

    def score(s):
        nl = (s.get("stage") or "").strip().lower()
        sc = 0
        if nl == ql:
            sc += 1000
        elif nl.startswith(ql):
            sc += 600
        elif ql in nl:
            sc += 300
        sc += 5 * sum(1 for t in tokens if t in nl)
        return sc

    out.sort(key=lambda s: (-score(s), s.get("stageid", 0)))
    return out[:12]


def _mg_stage_text(stage_name, stages):
    """Human-readable summary of the onestoppress matches for the AI prompt."""
    lines = [f"MYGAMATOTO stage data - \"{stage_name}\" matched {len(stages)} stage(s):"]
    for i, s in enumerate(stages[:5], 1):
        enemies = ", ".join(
            (e.get("enemy_name") or "?")
            + (f" x{e['enemy_multiplier']}" if e.get("enemy_multiplier") else "")
            for e in (s.get("enemies") or [])[:12]
        )
        lines.append(f"--- Match {i}: {s.get('stage')} [{s.get('category')} / {s.get('chapter')}] ---")
        lines.append(f"Enemies: {enemies}")
    return "\n".join(lines)


def _mg_duplicate_note(stage_name):
    """If several DIFFERENT event stages share this exact name (e.g. the two
    'Journey to Talent' trials), tell the AI - otherwise it can't know which
    one the player means. Only fires for same-category event stages, so common
    chapter names that repeat across chapters/outbreaks stay quiet."""
    ql = re.sub(r"\s+", " ", stage_name.strip().lower())
    if not ql:
        return ""
    exact = [s for s in search_stages_mg(stage_name)
             if (s.get("stage") or "").strip().lower() == ql]
    if len(exact) < 2:
        return ""
    cats = {s.get("category") for s in exact}
    if len(cats) != 1 or next(iter(cats)) not in (
            "Regular event stages", "Collab", "Enigma", "Legend Zero"):
        return ""
    lines = [f"NOTE: {len(exact)} DIFFERENT stages are called \"{stage_name}\" - "
             "confirm which one the player means before advising:"]
    for i, s in enumerate(exact, 1):
        enemies = ", ".join(e.get("enemy_name") or "?" for e in (s.get("enemies") or [])[:10])
        lines.append(f"  {i}. [{s.get('chapter')}] enemies: {enemies}")
    return "\n".join(lines)


def lookup_stage(stage_name):
    """Return dict with title, url, text, source. Never raises.

    Sources, in order: fandom/miraheze wikis (multiple matching pages are
    merged so same-name stages like the two 'Journey to Talent' trials are all
    shown), then the mygamatoto/onestoppress all-stages dataset, then 'none'.
    """
    cache_key = re.sub(r"\s+", " ", stage_name.strip().lower())
    cache = _cache_load(STAGE_CACHE_FILE, {})
    if cache_key in cache:
        return dict(cache[cache_key])

    candidates = list(_title_candidates(stage_name))
    candidates.extend(_tower_floor_candidates(stage_name))
    seen_titles = {t for _, t in candidates}
    for base, hit in search_wiki(stage_name) + fulltext_search(stage_name):
        if not hit or hit in seen_titles:
            continue
        seen_titles.add(hit)
        score = _score_title(hit, stage_name)
        if score > 0:
            candidates.append((score, hit))

    tower = _tower_name(stage_name)
    if tower:
        candidates = [c for c in candidates if _tower_title_ok(c[1], tower)]
    candidates.sort(key=lambda x: -x[0])

    pages = []
    for score, title in candidates:
        for base in (FANDOM, MIRAH):
            try:
                text = fetch_wikitext(base, title)
                if text:
                    pages.append({"base": base, "title": title, "text": text})
                    break
            except Exception:
                continue
        if len(pages) >= MAX_STAGE_PAGES:
            break

    if not pages:
        mg = search_stages_mg(stage_name)
        if mg:
            result = {
                "title": (mg[0].get("stage") or stage_name).strip(),
                "url": MG_SEARCH_URL,
                "text": _mg_stage_text(stage_name, mg),
                "source": "mygamatoto",
            }
        else:
            result = {"title": stage_name, "url": "", "text": "", "source": "none"}
    else:
        def _label(p, i):
            site = "miraheze" if p["base"] == MIRAH else "fandom"
            return f"=== PAGE {i}: {p['title'].replace('_', ' ')} ({site}) ==="

        if len(pages) == 1:
            text = strip_wikitext(pages[0]["text"])
        else:
            body = [_label(pages[0], 1), strip_wikitext(pages[0]["text"])]
            for i, p in enumerate(pages[1:], 2):
                body.append(_label(p, i))
                body.append(strip_wikitext(p["text"]))
            text = "\n\n".join(body)
        result = {
            "title": pages[0]["title"].replace("_", " "),
            "url": f"{pages[0]['base']}/wiki/{pages[0]['title']}",
            "text": text,
            "source": "miraheze" if pages[0]["base"] == MIRAH else "fandom",
        }
        note = _mg_duplicate_note(stage_name)
        if note:
            result["text"] = result["text"] + "\n\n" + note
    cache[cache_key] = result
    _cache_save(STAGE_CACHE_FILE, cache)
    return result


# ---------------------------------------------------------------------------
# Prompt building
# ---------------------------------------------------------------------------

KNOWLEDGE = """You are Big Pickle, a Battle Cats strategist. You know how the game actually works and build honest, winnable 10-unit loadouts.

CORE MECHANICS
- 10 slots per loadout exactly. Some slots can be combo fodder (combo cats with no real combat value), but every slot counts.
- Unit roles: meatshields (cheap, spammable walls), attackers (single-target boss-killer or area DPS), support/CC (slow/freeze/weaken/knockback), rushers (fast, die fast), snipers/outrangers, taunt/tank walls, ubers (powerful niche units).
- Cat Combo: when all its members are in the loadout, the whole team gets a buff (attack up, money up, starting wallet, resist, etc.).
- Worker Cat level = income. Economy matters: cheap meatshields keep money flowing so you can afford the boss-killer and wallet upgrades.
- Cat Cannon: Thunderbolt (stun), Waterblast (knockback/push), Holy Blast (kills Zombies and revives), Breaker Blast (breaks barriers/shields). Choosing the right cannon is part of beating the stage.
- Power-ups (battle items) are limited inventory, so only suggest ones the player actually has (check items.txt). Recommend one when it materially helps: Rich Cat for a brutal early economy, Cat CPU for heavy spam pressure, Sniper the Cat to stall an endless pusher, Treasure Radar when grinding a farm, Cat Jobs / Money Up for economy stages. A stage that benefits from a power-up uses it.
- Base HP and enemy base HP matter in timing/endless-pusher stages.

ENEMY TRAITS AND COUNTERS
- Red: damage dealers + status; use strong/resist vs Red, freeze/slow works.
- Floating: flies; anti-floating + strong units.
- Black: many rushers; knockback resist, strong vs black.
- Metal: Metal enemies only take damage from Critical Hits (or toxic). Freeze/slow/weaken and raw DPS are useless against them - each hit that is not a crit deals no damage, so bring reliable crit units (e.g. Jurassic Cat/Catasaurus, Crazed Moneko, Million-Dollar Cat, Marauder Cat, Backhoe Cat, Fish Cat) and a crit-combo if you have one. Never rely on non-crit DPS for a Metal enemy. NOTE: "Metal" trait cats (e.g. Metal Macho Cat, Metal Cat) are YOUR units that have the Metal trait - they take only 1 damage from every non-crit hit, making them ultra-durable meatshields (essentially immortal against non-crit enemies). They are NOT anti-Metal attackers - they are defensive tanks. Metal Macho Cat costs 600 and recharges in ~18s, so it's slow to deploy but extremely hard to kill.
- Wave attacks: some enemies attack with waves that sweep the whole field. ONLY a unit with immunity "Wave Blocker" (e.g. Octopus Cat / Kotatsu Cat, Hell Warden Emma) stops enemy waves for your team - a plain "immune: Wave" only protects that cat, and a "Resist Wave" talent only reduces the damage. If ANY enemy in stage.txt uses wave attacks, put a Wave Blocker in the loadout. Surge attacks (Boss Shockwave, Relic surges) work similarly: bring Surge immunity or Surge attackers for surge stages.
- Angel: often long range; anti-angel, shield breakers.
- Alien: a Starry Alien (the sparkly/cosmic kind, e.g. Star Peng) usually has a barrier, but a normal Alien may or may not - LOOK UP each enemy's description in stage.txt and use what it says. Never guess barrier status from the Alien trait alone.
- Zombie: revive on death unless a Z-Killer kills them; Holy Blast cannon kills them for good.
- Relic: curse (disables abilities) and surge; curse immunity / surge attackers, high HP.
- Aku: shield (immune until shield breaks); pierce or shield-break units.
- Traitless/White: can't be affected by trait-targeted abilities unless 'vs all'; use raw damage or Target: Traitless.
- Sage: take reduced damage from most attacks; need specific counters or curse.

STAGE FRAMEWORKS (match the enemy lineup to pick units)
- Slow boss / low KB count boss: bait & burst; interrupt wind-ups with cannon; KB-stunlock high-KB bosses; outrange or Long-Distance snipe; stall slow unsupported bosses to stack your DPS.
- Fast boss / pusher: CC before it reaches your stack; spam area-DPS to stagger high-KB enemies; only deploy rushers when the boss is locked down; keep meatshields up.
- Enemy spam: staggered meatshield timing (click at 70-90% cooldown), wallet maxing early, stall-to-stack, kill the DPS threats first, use Rich Cat/Sniper if allowed.
- Metal enemies: crit units ONLY, plus crit combos; cheese with a well-leveled crit unit if the cap is 2 enemies.
- Zombies: Holy Blast + Zombie Killers; don't let them reach your base to revive under it.
- Aku: shield break or pierce; raw DPS to finish after the shield drops.
- Crazed/Manic stages: heavy meatshield spam + ranged DPS that outranges the boss.
- Boss with long wind-up: Thunderbolt to cancel the wind-up repeatedly.

LOADOUT BUILDING RULES
- Exactly 10 units. 2-4 should be meatshields OR combo pieces that double as blockers; 1-2 money/cost combos if economy is tight; an attack or HP combo is almost always worth 2-3 slots.
- Good meatshields have LOW cost AND low Respawn time (the "Respawn" stat in roster.txt). The cheapest cat isn't always the best meatshield — a cat that costs 150 but respawns in 3s is often better than one that costs 75 but respawns in 10s. Prioritize cats with Respawn under 5 seconds for meatshield duty. Staggered meatshield timing (deploy one every 70-90% of its cooldown) keeps a constant wall up.
- Bring a clear boss-killer (single-target nuke or % damage or strong uber) and enough area damage to clear peons.
- For every key enemy, LOOK UP its description in stage.txt and judge its abilities from what the description actually says. If the description names a barrier, the enemy has one (bring a barrier breaker); if it does not, the enemy has none. NEVER decide an enemy's special abilities (barrier, shield, wave, surge, warp) from its trait or its name alone - not every Alien has a barrier, and not every enemy with "Cyclone" in its name has one either.
- If stage.txt explicitly says the stage has barriers: barrier breaker. If zombies: Z-killer + Holy Blast. If metal: crit. If Aku: pierce/shield-break. If waves: a Wave Blocker. If surge: surge counters.
- Never suggest a unit the player does not own.
- If the player owns an uber that hard-counters the stage's trait, it earns a slot.
- FORM SWITCHING: each cat can have multiple forms (Base, Evolved, True, Ultra). The roster shows which forms are unlocked via "forms: Base,Evolved,True". You may pick ANY unlocked form for the loadout - the best form for the job is not always the one the player currently has selected. True forms are almost always stronger than Base/Evolved. When a cat's True form is unlocked and the stage needs it, prefer the True form. The id is the same regardless of form - the app switches to whichever form you recommend.
- Read the attached stage.txt and roster.txt carefully before finalizing; do NOT use web search.
"""


_FORM_LABEL = {0: "Base", 1: "Evolved", 2: "True", 3: "Ultra"}


def _cat_line(c):
    parts = []
    crit = any("crit" in (a or "").lower() for a in (c.get("abilities") or []))
    if crit:
        parts.append("CRITICAL HIT unit")
    if c["abilities"]:
        parts.append("; ".join(c["abilities"][:3]))
    if c["immunities"]:
        parts.append("immune: " + ", ".join(c["immunities"]))
    if c["talents_spent"]:
        parts.append("talents: " + ", ".join(f"{x['name']} Lv{x['level']}" for x in c["talents_spent"]))
    if c["orbs"]:
        eq = [o["name"] for o in c["orbs"] if o["name"] != "(empty)"]
        if eq:
            parts.append("orbs: " + ", ".join(eq))
    stats = c.get("stats")
    if stats:
        parts.append(
            f"stats Lv{stats.get('level', '?')}: HP {stats.get('health') or 0:,} "
            f"ATK {stats.get('damage') or 0:,} DPS {stats.get('dps') or 0:,} "
            f"Rng {stats.get('range') or '?'} Cost {stats.get('cost') or 0:,} "
            f"TBA {stats.get('tba') or '?'}s Respawn {stats.get('spawn') or '?'}s"
        )
    unl = c.get("unl", c.get("cur", 0))
    if unl > 0:
        avail = [_FORM_LABEL.get(i, f"F{i}") for i in range(unl + 1)]
        parts.append("forms: " + ",".join(avail))
    desc = " | " + " || ".join(parts) if parts else ""
    return f"[{c['id']:3d}] {c['base_name']} ({c['cur_name']} {c['cur_label']}) {c['rarity']} Lv{c['level_base']}+{c['level_plus']}{' [CRIT]' if crit else ''}{desc}"


def build_roster_text(cats):
    order = {"Normal": 0, "Special": 1, "Rare": 2, "Super Rare": 3, "Uber Rare": 4, "Legend Rare": 5}
    cats = sorted(cats, key=lambda c: (order.get(c["rarity"], 9), c["id"]))
    return "\n".join(_cat_line(c) for c in cats)


def build_combos_text(combos):
    return "\n".join(
        f"- {c['name']} -> {c['effect']} {c['value']} | members: {c['members']}{' [Nyanko Rangers only]' if c['note'] else ''}"
        for c in combos
    )


def write_prompt_files(roster_text, combos_text, stage_info, items_text):
    os.makedirs(TMP_DIR, exist_ok=True)
    roster_p = os.path.join(TMP_DIR, "roster.txt")
    combos_p = os.path.join(TMP_DIR, "combos.txt")
    stage_p = os.path.join(TMP_DIR, "stage.txt")
    items_p = os.path.join(TMP_DIR, "items.txt")
    with open(roster_p, "w", encoding="utf-8") as f:
        f.write("PLAYER ROSTER (only these units exist for this player):\n" + roster_text)
    with open(combos_p, "w", encoding="utf-8") as f:
        f.write("AVAILABLE COMBOS:\n" + combos_text)
    with open(stage_p, "w", encoding="utf-8") as f:
        f.write(f"Stage requested: {stage_info['requested']}\n")
        f.write(f"Wiki page: {stage_info['title']}\n")
        f.write(f"Wiki: {stage_info['url']}\n")
        f.write("--- wiki page text ---\n")
        f.write(stage_info["text"] or "(no wiki text could be fetched)")
    with open(items_p, "w", encoding="utf-8") as f:
        f.write(items_text)
    return roster_p, combos_p, stage_p, items_p


def build_items_text(items):
    lines = ["PLAYER INVENTORY (counts are exact; power-ups are NOT infinite - only recommend one if the stage demands it):"]
    lines.append("Battle items (power-ups): "
                 + ", ".join(f"{it['name']} x{it['count']}" for it in items.get("battle_items", [])))
    cf = [f"{it['name']} x{it['count']}" for it in items.get("cat_fruit", []) if it["count"] > 0]
    lines.append("Cat fruit / behemoth stones: " + (", ".join(cf) if cf else "(none)"))
    return "\n".join(lines)


def build_message(stage_name, stage_info, cannons, banned="", required="", powerups=None, context=None):
    if stage_info.get("url") and stage_info.get("text"):
        stage_line = (
            f'The stage "{stage_name}" was matched to the wiki page "{stage_info["title"]}" '
            "(attached as stage.txt - read it for the enemy lineup). It contains the full enemy lineup "
            "for the stage, so do NOT use web search - trust the attached text. If the page is clearly a "
            "DIFFERENT stage than the one asked for, say so in reasoning and use your own knowledge of the stage."
        )
    elif stage_info.get("url"):
        stage_line = (
            f'The stage "{stage_name}" was matched to the wiki page "{stage_info["title"]}" '
            "(attached as stage.txt) but its text could not be fetched. Design from your own knowledge of the stage."
        )
    else:
        stage_line = (
            f'The stage "{stage_name}" could not be fetched from the wiki automatically. '
            "Design the loadout from your own knowledge of the stage - do NOT spend time web searching."
        )
    cannon_line = ", ".join(cannons) if cannons else "Standard"
    constraints = ""
    if banned:
        constraints += f"\nBANNED UNITS (the loadout must NOT contain any of these, even if they seem optimal): {banned}"
    if required:
        constraints += f"\nREQUIRED UNITS (the loadout MUST contain every one of these): {required}"
    if powerups:
        constraints += f"\nREQUESTED POWER-UPS (the player explicitly wants these applied - include EVERY one of them in the \"powerups\" list, even if you would not pick it yourself): {', '.join(powerups)}"
    if context:
        constraints += f"\nEXTRA CONTEXT (the player's own observation about what went wrong - use this to address the specific problem): {context}"
    return f"""{KNOWLEDGE}

ATTACHED FILES (read all four before answering):
- roster.txt: the player's owned roster with ids, forms, levels, abilities, talents, orbs, stats AND status immunities (e.g. "immune: Freeze" = the cat cannot be frozen). Use immunities to pick walls/tanks that ignore the stage's status-spamming enemies. Each cat line shows which forms are unlocked (e.g. "forms: Base,Evolved,True"). You may recommend ANY unlocked form - the app will use whichever form you pick. True forms are usually stronger; prefer them when unlocked and needed.
- combos.txt: combos the player can currently activate.
- stage.txt: {stage_line}
- items.txt: the player's cat fruit, behemoth stones, and battle item (power-up) counts, plus which true/ultra evolutions are affordable right now.

PLAYER'S CAT CANNONS (only these are unlocked): {cannon_line}
The "cannon" field in your JSON MUST recommend exactly one of these unlocked cannons. If the stage really wants a cannon the player does not own, pick the best unlocked alternative and say so in reasoning.
{constraints}

TASK: Build a winning loadout for the stage "{stage_name}". Decide the enemy lineup, pick the cannon and power-ups, then choose exactly 10 units from roster.txt.

RULE FOR SPEED AND ACCURACY: read the attached stage.txt and roster.txt carefully and answer directly from them. Do NOT use web search at all - everything you need is in the attached files. A loadout with the wrong ids, or missing a counter the player owns, is wrong.

MANDATORY FIRST STEP: before picking any cat, list the enemy traits present in stage.txt (e.g. "stage has: Red, Black") AND any deployment restrictions (e.g. "cost restriction: only cats above 1200 cost", "only Special cats allowed", "no continues"). Then for EACH of the 10 slots, confirm the cat: (1) counters a trait that is ACTUALLY in the stage, or fills a universal role (meatshield, combo, general DPS), AND (2) meets ALL deployment restrictions (cost, rarity, form). If a cat only counters a trait NOT in the stage, DO NOT include it. If a cat's Cost is below a minimum cost restriction, DO NOT include it. A crit unit is only needed if Metal enemies are listed. An anti-Black unit is only needed if Black enemies are listed. Anti-Red only if Red enemies are listed. And so on.

Respond with ONLY a JSON object in this exact shape (no markdown fences, no text around it):
{{
  "loadout": [
    {{"id": <exact roster id>, "role": "<meatshield/rusher/dps/cc/tank/sniper/combo/uber/etc>"}}
  ],
  "combos_used": ["<combo names active in this loadout>"],
  "cannon": "<one of the player's unlocked cannons>",
  "powerups": ["<power-ups to use for this stage - ONLY ones the player actually has in items.txt; empty list if none>"],
  "reasoning": "<2-4 sentences: enemy threat summary and why these units>"
}}

CRITICAL: every id MUST be a cat you can confirm in roster.txt - the app rejects ids not in the roster and auto-fills empty slots with the player's strongest cats. If you are not 100% certain a cat is in roster.txt, OMIT it (return fewer than 10 units) rather than guessing an id. Never re-use the same cat twice. Do not put "form" in loadout items. Only list power-ups the player actually has in items.txt, and honor any REQUESTED POWER-UPS exactly. Honor the BANNED and REQUIRED units exactly. If you must consult the wiki, do it now. Do not include any text outside the JSON object. In your "reasoning", ONLY mention cats that are in the loadout you just built - do not reference any other cat by name, even if the player owns it. NEVER mention a unit the player does not own (no Manic/awakened cats, no Legend Rares, no cats absent from roster.txt). If the roster lacks a good counter, say so in words (e.g. "you have no barrier-breaker") without naming an unowned cat as if they had it or should get it. DOUBLE-CHECK: read stage.txt carefully and list only the traits that are ACTUALLY mentioned for enemies on that specific stage - do NOT assume traits from enemy names or guess."""


# ---------------------------------------------------------------------------
# Big Pickle runner + parsing
# ---------------------------------------------------------------------------

def _cleanup_last_session():
    """Delete the most recent opencode session created by this app.

    opencode stores every ``opencode run`` call in its global SQLite database
    at ``~/.local/share/opencode/opencode.db``.  Each session, its messages
    and parts accumulate indefinitely (hundreds of MB over time).  Because
    the app never needs to resume a session, we wipe the last one right after
    ``run_bigpickle`` finishes so the database doesn't grow forever.
    """
    try:
        db_path = os.path.join(os.path.expanduser("~"), ".local",
                               "share", "opencode", "opencode.db")
        if not os.path.exists(db_path):
            return
        dir_pattern = APP_DIR.replace("\\", "/")
        conn = sqlite3.connect(db_path, timeout=5)
        try:
            conn.execute("PRAGMA journal_mode=WAL")
            row = conn.execute(
                "SELECT id FROM session WHERE directory = ? ORDER BY time_created DESC LIMIT 1",
                (dir_pattern,),
            ).fetchone()
            if not row:
                return
            sid = row[0]
            msg_ids = [r[0] for r in conn.execute(
                "SELECT id FROM message WHERE session_id = ?", (sid,)
            ).fetchall()]
            if msg_ids:
                ph = ",".join(["?"] * len(msg_ids))
                conn.execute(f"DELETE FROM part WHERE message_id IN ({ph})", msg_ids)
                conn.execute("DELETE FROM message WHERE session_id = ?", (sid,))
            conn.execute("DELETE FROM session WHERE id = ?", (sid,))
            conn.commit()
        finally:
            conn.close()
    except Exception:
        pass


def cleanup_all_sessions():
    """Delete every leftover opencode session created by this app.

    Called once at startup to clean up any sessions that accumulated before
    per-call cleanup was added, or that were left behind by a crash.
    """
    try:
        db_path = os.path.join(os.path.expanduser("~"), ".local",
                               "share", "opencode", "opencode.db")
        if not os.path.exists(db_path):
            return
        dir_pattern = APP_DIR.replace("\\", "/")
        conn = sqlite3.connect(db_path, timeout=5)
        try:
            conn.execute("PRAGMA journal_mode=WAL")
            sids = [r[0] for r in conn.execute(
                "SELECT id FROM session WHERE directory = ?",
                (dir_pattern,),
            ).fetchall()]
            if not sids:
                return
            ph = ",".join(["?"] * len(sids))
            conn.execute(f"DELETE FROM part WHERE message_id IN "
                         f"(SELECT id FROM message WHERE session_id IN ({ph}))", sids)
            conn.execute(f"DELETE FROM message WHERE session_id IN ({ph})", sids)
            conn.execute(f"DELETE FROM session WHERE id IN ({ph})", sids)
            conn.commit()
            conn.execute("VACUUM")
        finally:
            conn.close()
    except Exception:
        pass


def run_bigpickle(prompt, files):
    cmd = [OPCODE_EXE, "run", prompt, "--model", MODEL, "--format", "json", "--dir", APP_DIR]
    for f in files:
        cmd += ["--file", f]
    flags = 0
    if os.name == "nt":
        flags |= subprocess.CREATE_NO_WINDOW
    proc = subprocess.Popen(
        cmd,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        encoding="utf-8",
        errors="replace",
        cwd=APP_DIR,
        creationflags=flags,
    )
    text_parts = []
    raw_lines = []
    total_tokens = 0
    for line in proc.stdout:
        line = line.strip()
        if not line:
            continue
        raw_lines.append(line)
        if line.startswith("{"):
            try:
                ev = json.loads(line)
            except Exception:
                continue
            t = ev.get("type")
            part = ev.get("part", {})
            if t == "text" and isinstance(part, dict) and part.get("type") == "text" and part.get("text"):
                text_parts.append(part["text"])
            if t == "step_finish":
                tk = part.get("tokens") or {}
                total_tokens = tk.get("input", 0) + tk.get("output", 0)
    proc.wait(timeout=1200)
    _cleanup_last_session()
    dropped = total_tokens == 0 and proc.returncode == 0
    return "".join(text_parts), "\n".join(raw_lines), proc.returncode, dropped


def extract_json(text):
    start = text.find("{")
    end = text.rfind("}")
    if start != -1 and end > start:
        try:
            return json.loads(text[start:end + 1])
        except Exception:
            pass
    m = re.search(r'```(?:json)?\s*(\{.*?\})\s*```', text, flags=re.S)
    if m:
        try:
            return json.loads(m.group(1))
        except Exception:
            pass
    return None


def _loadout_fingerprint(stage_name, cats, cannons, items_raw, banned=None, required=None, powerups=None, context=None):
    """Stable key for the loadout cache: stage + roster + cannons + inventory + constraints."""
    roster = "|".join(f"{c['id']}:{c.get('cur', 0)}:{c['level_base']}+{c['level_plus']}"
                      for c in sorted(cats, key=lambda c: c["id"]))
    banned_s = ",".join(str(x) for x in sorted(banned or []))
    required_s = ",".join(str(x) for x in sorted(required or []))
    powerups_s = ",".join(sorted(str(x) for x in (powerups or [])))
    context_s = (context or "").strip().lower()
    return hashlib.sha1(
        f"{stage_name.strip().lower()}||{roster}||{','.join(sorted(cannons))}||{items_raw or ''}"
        f"||b:{banned_s}||r:{required_s}||p:{powerups_s}||ctx:{context_s}".encode("utf-8")
    ).hexdigest()


def _slot_from(c, role):
    return {
        "id": c["id"],
        "name": c["base_name"],
        "form": c["cur_name"],
        "form_label": c["cur_label"],
        "role": role,
        "rarity": c["rarity"],
        "level": f"Lv{c['level_base']}+{c['level_plus']}",
        "dps": (c.get("stats") or {}).get("dps"),
        "abilities": c["abilities"][:4],
        "immunities": c["immunities"],
        "talents": c["talents_spent"],
        "orbs": c["orbs"],
    }


def _find_drop_slot(loadout):
    """Return the index to replace when force-adding a unit: the last auto-fill
    slot if any, otherwise the last slot."""
    drop_idx = None
    for i in range(len(loadout) - 1, -1, -1):
        if loadout[i].get("role") == "auto-fill":
            drop_idx = i
            break
    if drop_idx is None and len(loadout) > 0:
        drop_idx = len(loadout) - 1
    return drop_idx


def enforce_loadout_rules(loadout, cats, stage_text, log=None):
    """Post-process an AI loadout so it always covers wave, metal and barrier stages.

    Runs after the AI has picked its team and after auto-fill. If the stage text
    mentions wave attacks / metal / barriers but the loadout lacks the required
    unit type, replace a (preferably auto-fill) slot with the best owned fit.
    """
    if log is None:
        log = lambda msg: None
    wave_text = (stage_text or "").lower()

    wave_stage = any(kw in wave_text for kw in ("wave attack", "wave shield", "waves", "mini-wave", "wave blocker"))
    if wave_stage and not any("Wave Blocker" in (u.get("immunities") or []) for u in loadout if u.get("id")):
        wb = next((c for c in cats if c["id"] == 33), None) or next(
            (c for c in cats if "Wave Blocker" in c["immunities"]), None)
        used_ids = {u["id"] for u in loadout if u.get("id")}
        if wb and wb["id"] not in used_ids:
            drop_idx = _find_drop_slot(loadout)
            if drop_idx is not None:
                was_auto = loadout[drop_idx].get("role") == "auto-fill"
                dropped_name = loadout[drop_idx].get("name") or f"slot #{drop_idx + 1}"
                loadout[drop_idx] = _slot_from(wb, "wave-blocker")
                log(f"Stage has wave attacks - added Wave Blocker {wb['base_name']} [{wb['id']}] "
                    f"in place of an {'auto-fill' if was_auto else 'AI'} slot ({dropped_name}).")

    metal_stage = any(kw in wave_text for kw in ("metal",))
    if metal_stage and not any(
        any("crit" in (a or "").lower() for a in (u.get("abilities") or []))
        for u in loadout if u.get("id")
    ):
        crit_cat = next((c for c in cats if any("crit" in (a or "").lower() for a in c["abilities"])), None)
        used_ids = {u["id"] for u in loadout if u.get("id")}
        if crit_cat and crit_cat["id"] not in used_ids:
            drop_idx = _find_drop_slot(loadout)
            if drop_idx is not None:
                was_auto = loadout[drop_idx].get("role") == "auto-fill"
                dropped_name = loadout[drop_idx].get("name") or f"slot #{drop_idx + 1}"
                loadout[drop_idx] = _slot_from(crit_cat, "crit-bringer")
                log(f"Stage has Metal enemies - added crit unit {crit_cat['base_name']} [{crit_cat['id']}] "
                    f"in place of an {'auto-fill' if was_auto else 'AI'} slot ({dropped_name}).")

    barrier_stage = any(kw in wave_text for kw in (
        "barrier break", "barrier shield", "has a barrier", "with a barrier", "barriers"))
    if barrier_stage and not any(
        any("barrier break" in (a or "").lower() for a in (u.get("abilities") or []))
        for u in loadout if u.get("id")
    ):
        bb = next((c for c in cats if any("barrier break" in (a or "").lower() for a in c["abilities"])), None)
        used_ids = {u["id"] for u in loadout if u.get("id")}
        if bb and bb["id"] not in used_ids:
            drop_idx = _find_drop_slot(loadout)
            if drop_idx is not None:
                was_auto = loadout[drop_idx].get("role") == "auto-fill"
                dropped_name = loadout[drop_idx].get("name") or f"slot #{drop_idx + 1}"
                loadout[drop_idx] = _slot_from(bb, "barrier-breaker")
                log(f"Stage has barrier enemies - added Barrier Breaker {bb['base_name']} [{bb['id']}] "
                    f"in place of an {'auto-fill' if was_auto else 'AI'} slot ({dropped_name}).")


def _enforce_cost_restriction(loadout, stage_text, cats, cats_by_id, log=None):
    """If the stage has a minimum cost restriction, swap out any cat below it."""
    if log is None:
        log = lambda msg: None
    min_cost = _extract_cost_restriction(stage_text)
    if min_cost is None:
        return
    used_ids = {u["id"] for u in loadout if u.get("id")}
    for i, slot in enumerate(loadout):
        if not slot.get("id"):
            continue
        c = cats_by_id.get(slot["id"])
        if not c:
            continue
        stats = c.get("stats") or {}
        cost = stats.get("cost") or 0
        if cost < min_cost:
            # Find a replacement that costs >= min_cost, sorted by DPS
            replacement = None
            for rc in sorted(cats, key=lambda x: (x.get("stats") or {}).get("dps") or 0, reverse=True):
                if rc["id"] in used_ids:
                    continue
                rc_stats = rc.get("stats") or {}
                if (rc_stats.get("cost") or 0) >= min_cost:
                    replacement = rc
                    break
            if replacement:
                loadout[i] = _slot_from(replacement, "cost-fix")
                used_ids.add(replacement["id"])
                used_ids.discard(slot["id"])
                log(f"Stage requires cats above {min_cost} cost - swapped out "
                    f"{c['base_name']} (cost {cost}) for {replacement['base_name']} "
                    f"(cost {(replacement.get('stats') or {}).get('cost', '?')}).")
            else:
                log(f"WARNING: {c['base_name']} costs {cost} but stage requires {min_cost}+ "
                    f"and no owned cat meets the restriction.")


def _enforce_trait_counters(loadout, stage_text, cats, cats_by_id, log=None):
    """Swap out cats whose ONLY purpose is countering a trait not in the stage."""
    if log is None:
        log = lambda msg: None
    stage_traits = _extract_stage_traits(stage_text)
    if not stage_traits:
        return
    trait_counter_keywords = {
        "Red": ["strong vs red", "resist red", "freeze red", "slow red", "knockback red",
                "massive dmg vs red", "insane dmg vs red"],
        "Black": ["strong vs black", "resist black", "freeze black", "slow black", "knockback black",
                  "massive dmg vs black", "insane dmg vs black"],
        "Floating": ["strong vs floating", "resist floating", "freeze floating", "slow floating",
                     "knockback floating", "massive dmg vs floating", "insane dmg vs floating"],
        "Metal": ["crit"],
        "Angel": ["strong vs angel", "resist angel", "freeze angel", "slow angel", "knockback angel",
                  "massive dmg vs angel", "insane dmg vs angel"],
        "Alien": ["strong vs alien", "resist alien", "freeze alien", "slow alien", "knockback alien",
                  "massive dmg vs alien", "insane dmg vs alien"],
        "Zombie": ["zombie killer"],
        "Relic": ["strong vs relic", "resist relic"],
        "Aku": ["shield pierc"],
    }
    used_ids = {u["id"] for u in loadout if u.get("id")}
    for i, slot in enumerate(loadout):
        if not slot.get("id"):
            continue
        c = cats_by_id.get(slot["id"])
        if not c:
            continue
        abilities = [a.lower() for a in (c.get("abilities") or [])]
        talents = [t.get("name", "").lower() for t in (c.get("talents_spent") or [])]
        all_abilities = abilities + talents
        # Find which unmatched trait this cat counters
        unmatched_trait = None
        for trait, counter_kws in trait_counter_keywords.items():
            if trait not in stage_traits:
                trait_lower = trait.lower()
                has_counter = any(
                    any(kw in ab and trait_lower in ab for kw in counter_kws)
                    for ab in all_abilities
                )
                if has_counter:
                    unmatched_trait = trait
                    break
        if not unmatched_trait:
            continue
        # Only swap if this cat's primary value is the wrong-trait counter
        # (i.e. it doesn't also have a useful universal role like area attack + high DPS)
        stats = c.get("stats") or {}
        dps = stats.get("dps") or 0
        has_area = any("area" in a.lower() for a in all_abilities)
        # If DPS is low or it's single-target with no other utility, replace it
        if dps < 2000 and not has_area:
            # Prefer a cat that counters a trait actually in the stage
            def _stage_trait_match(rc):
                rc_abilities = [a.lower() for a in (rc.get("abilities") or [])]
                for st in stage_traits:
                    st_lower = st.lower()
                    if any(st_lower in a for a in rc_abilities):
                        return True
                return False
            replacement = None
            for rc in sorted(cats, key=lambda x: (x.get("stats") or {}).get("dps") or 0, reverse=True):
                if rc["id"] in used_ids:
                    continue
                if _stage_trait_match(rc):
                    replacement = rc
                    break
            if not replacement:
                # Fall back to highest-DPS cat if no trait-specific match
                for rc in sorted(cats, key=lambda x: (x.get("stats") or {}).get("dps") or 0, reverse=True):
                    if rc["id"] in used_ids:
                        continue
                    replacement = rc
                    break
            if replacement:
                loadout[i] = _slot_from(replacement, "trait-fix")
                used_ids.add(replacement["id"])
                used_ids.discard(slot["id"])
                log(f"Swapped out {c['base_name']} (counters {unmatched_trait} but stage has no {unmatched_trait}) "
                    f"for {replacement['base_name']}.")
        else:
            log(f"WARNING: {c['base_name']} counters {unmatched_trait} but the stage has no {unmatched_trait} enemies "
                f"(kept because it has useful general DPS/utility).")


def _clean_reasoning(text, loadout, cats_by_id):
    """Remove mentions of cats not in the loadout from reasoning text.

    The LLM sometimes name-drops ideal units the player doesn't own or that
    aren't in the selected loadout.  This strips those mentions so the Why
    section only talks about cats the player actually has in the loadout.
    """
    if not text:
        return text
    loadout_names = {c.get("name", "").lower() for c in loadout if c.get("id")}
    # Also collect any loadout cat name that contains a shorter name as substring
    # so "Fish Cat" isn't stripped from inside "Crazed Fish Cat".
    loadout_substrings = set()
    for ln in loadout_names:
        loadout_substrings.add(ln)
    sorted_cats = sorted(cats_by_id.values(),
                         key=lambda c: len(c["base_name"]), reverse=True)
    for c in sorted_cats:
        name = c["base_name"]
        if len(name) < 4:
            continue
        if name.lower() in loadout_names:
            continue
        # Skip if this name is a substring of any loadout cat name
        if any(name.lower() in ln for ln in loadout_substrings):
            continue
        pattern = r'\b' + re.escape(name) + r'\b'
        if re.search(pattern, text, re.I):
            # Just remove the cat name — don't replace with "an anti-X cat"
            # which creates nonsensical sentences
            text = re.sub(pattern, "a cat", text, flags=re.I)
    return text


def _extract_stage_traits(stage_text):
    """Extract which enemy traits are mentioned in the stage text."""
    low = (stage_text or "").lower()
    trait_keywords = {
        "Red": ["red"],
        "Black": ["black"],
        "Floating": ["floating"],
        "Metal": ["metal"],
        "Angel": ["angel"],
        "Alien": ["alien"],
        "Zombie": ["zombie"],
        "Relic": ["relic"],
        "Aku": ["aku"],
        "Traitless": ["traitless", "white"],
    }
    found = set()
    for trait, keywords in trait_keywords.items():
        if any(kw in low for kw in keywords):
            found.add(trait)
    return found


def _extract_cost_restriction(stage_text):
    """Try to parse a minimum cost restriction from the stage text.

    Common wiki formats:
      "Cost: Only deploy cats that cost 1200 or more"
      "Only cats above 1200 cost allowed"
      "Minimum cost: 1500"
      "Restrictions: 1200+ cost only"
    Returns the minimum cost as an int, or None if no restriction found.
    """
    low = (stage_text or "").lower()
    patterns = [
        r'(?:above|over|more than|at least|minimum)\s+(\d[\d,]*)\s*(?:cost|price)',
        r'(?:cost|price)\s*(?:restriction|only|limit).*?(\d[\d,]*)\s*\+',
        r'(?:minimum|min)\s*(?:cost|price)\s*[:=]?\s*(\d[\d,]*)',
        r'(\d[\d,]*)\s*\+\s*(?:cost|price)',
        r'only.*?(\d[\d,]*)\s*(?:or more|and above|higher)',
        r'(?:above|over|more than)\s+(\d[\d,]*)\s*(?:cost|price)',
        r'(?:only|must).*?(?:cost|price).*?(\d[\d,]*)',
    ]
    for pat in patterns:
        m = re.search(pat, low)
        if m:
            val = int(m.group(1).replace(",", ""))
            if val > 0:
                return val
    return None


def _validate_loadout(loadout, stage_text, cats_by_id, log=None):
    """Post-check: warn if the loadout hard-counters a trait not in the stage,
    or violates a cost restriction.

    Returns a list of warning strings (empty if everything looks fine).
    """
    if log is None:
        log = lambda msg: None
    warnings = []
    stage_traits = _extract_stage_traits(stage_text)
    min_cost = _extract_cost_restriction(stage_text)

    # Check cost restrictions
    if min_cost is not None:
        for slot in loadout:
            if not slot.get("id"):
                continue
            c = cats_by_id.get(slot["id"])
            if not c:
                continue
            stats = c.get("stats") or {}
            cost = stats.get("cost") or 0
            if cost < min_cost:
                name = c.get("base_name", f"#{slot['id']}")
                warnings.append(
                    f"{name} costs {cost} but the stage requires cats above {min_cost}"
                )

    # Map trait-targeting ability keywords to the traits they counter
    # Abilities now include trait targets (e.g. "Freeze 40% (4.0s) vs Alien")
    if not stage_traits and min_cost is None:
        return warnings
    trait_counter_keywords = {
        "Red": ["strong", "resist", "freeze", "slow", "knockback"],
        "Black": ["strong", "resist", "freeze", "slow", "knockback"],
        "Floating": ["strong", "resist", "freeze", "slow", "knockback"],
        "Metal": ["strong", "crit"],
        "Angel": ["strong", "resist", "freeze", "slow", "knockback"],
        "Alien": ["strong", "resist", "freeze", "slow", "knockback"],
        "Zombie": ["zombie killer"],
        "Relic": ["strong", "resist"],
        "Aku": ["shield pierc"],
    }

    for slot in loadout:
        if not slot.get("id"):
            continue
        c = cats_by_id.get(slot["id"])
        if not c:
            continue
        abilities = [a.lower() for a in (c.get("abilities") or [])]
        talents = [t.get("name", "").lower() for t in (c.get("talents_spent") or [])]
        all_abilities = abilities + talents

        for trait, counter_kws in trait_counter_keywords.items():
            if trait not in stage_traits:
                trait_lower = trait.lower()
                has_counter = any(
                    any(kw in ab and trait_lower in ab for kw in counter_kws)
                    for ab in all_abilities
                )
                if has_counter:
                    name = c.get("base_name", f"#{slot['id']}")
                    warnings.append(
                        f"{name} counters {trait} but the stage has no {trait} enemies"
                    )

    for w in warnings:
        log(f"WARNING: {w}")
    return warnings


class LoadoutRunner:
    def __init__(self):
        self.lock = threading.Lock()
        self.running = False
        self.done = False
        self.error = None
        self.status = ""
        self.log_lines = []
        self.result = None

    def _log(self, line):
        with self.lock:
            self.log_lines.append(line)

    def _set_status(self, text):
        with self.lock:
            self.status = text

    def snapshot(self):
        with self.lock:
            return {
                "running": self.running,
                "done": self.done,
                "error": self.error,
                "status": self.status,
                "log": list(self.log_lines),
                "result": self.result,
            }

    def start(self, stage_name, cats, combos, cannons, banned=None, required=None, force=False, powerups=None, context=None):
        if self.running:
            return False
        with self.lock:
            self.running = True
            self.done = False
            self.error = None
            self.status = ""
            self.log_lines = []
            self.result = None
        threading.Thread(target=self._run, args=(stage_name, cats, combos, cannons, banned, required, force, powerups, context), daemon=True).start()
        return True

    def _run(self, stage_name, cats, combos, cannons, banned=None, required=None, force=False, powerups=None, context=None):
        log = self._log
        t0 = time.time()

        def lap(msg):
            log(f"  [{time.time() - t0:6.1f}s] {msg}")

        try:
            items_raw = db.get_meta("items")
            fp = _loadout_fingerprint(stage_name, cats, cannons, items_raw, banned, required, powerups, context)
            results = _cache_load(RESULT_CACHE_FILE, {})
            if not force and fp in results:
                cached = results[fp]
                filled = sum(1 for u in (cached.get("loadout") or []) if u.get("id") is not None)
                self._set_status("Cached")
                log(f"Same stage + roster + constraints as a previous run - loading cached loadout "
                    f"({fp[:8]}, {filled}/10 slots filled).")
                log("Tip: this is the result from an earlier successful run, not a new answer. "
                    "Use 'Regenerate' (bypass cache) for a fresh build.")
                with self.lock:
                    self.result = dict(cached)
                    self.result["cached"] = True
                    self.done = True
                    self.running = False
                return
            if force:
                log("Bypassing cache - building a fresh loadout.")

            self._set_status("Looking up stage")
            log(f"Looking up stage '{stage_name}' on the wiki...")
            stage_info = lookup_stage(stage_name)
            lap("stage lookup done")
            stage_info["requested"] = stage_name
            if stage_info.get("url"):
                log(f"Found: {stage_info['title']} ({stage_info['source']}) - {stage_info['url']}")
            else:
                log("No wiki page auto-found (the wiki can be unreachable from some networks); "
                    "big-pickle will reason from its own knowledge of the stage.")

            roster_text = build_roster_text(cats)
            combos_text = build_combos_text(combos)
            items_text = build_items_text(json.loads(items_raw)) if items_raw else \
                "(no inventory data - run Detect to get item counts)"
            items_text += "\n\n" + evolve.plan_text()
            roster_p, combos_p, stage_p, items_p = write_prompt_files(
                roster_text, combos_text, stage_info, items_text)
            by_id = {c["id"]: c for c in cats}
            banned_names = ", ".join(f"[{i}] {by_id[i]['base_name']}" for i in (banned or []) if i in by_id)
            required_names = ", ".join(f"[{i}] {by_id[i]['base_name']}" for i in (required or []) if i in by_id)
            if banned_names:
                log(f"Constraints: banned {banned_names}")
            if required_names:
                log(f"Constraints: required {required_names}")
            if powerups:
                log(f"Constraints: requested power-ups: {', '.join(powerups)}")
            prompt = build_message(stage_name, stage_info, cannons, banned=banned_names, required=required_names, powerups=powerups, context=context)
            lap("context built")
            self._set_status("Asking AI (can take a few minutes)")

            text, raw, exitcode, dropped = run_bigpickle(prompt, [roster_p, combos_p, stage_p, items_p])
            lap("AI reply received")
            self._set_status("Parsing loadout")
            log("Got a reply; parsing loadout JSON...")

            delay = 5
            data = extract_json(text) or (extract_json(raw) if raw else None)
            for attempt in range(4):
                if data:
                    break
                reason = "server dropped request (0 tokens)" if dropped else f"no JSON (exit {exitcode})"
                log(f"{reason}; retry {attempt + 1}/4 in {delay}s...")
                self._set_status(f"Asking AI (retry {attempt + 1}/4)")
                time.sleep(delay)
                text, raw, exitcode, dropped = run_bigpickle(prompt, [roster_p, combos_p, stage_p, items_p])
                data = extract_json(text) or (extract_json(raw) if raw else None)
                lap(f"AI retry {attempt + 1} received")
                delay = min(delay * 2, 60)
            if not data:
                self._log("RAW REPLY (could not parse JSON):\n" + (text[:3000] or raw[:3000]))
                self._log("CLI exit code: %s" % exitcode)
                raise ValueError("big-pickle did not return a valid JSON loadout.")

            by_id = {c["id"]: c for c in cats}

            def _loadout_from(data):
                out = []
                for item in (data.get("loadout", []) if data else []) or []:
                    cid = item.get("id")
                    if not isinstance(cid, int) or cid not in by_id:
                        log(f"  skipped invalid slot: id={cid!r}")
                        continue
                    c = by_id[cid]
                    out.append({
                        "id": cid,
                        "name": c["base_name"],
                        "form": c["cur_name"],
                        "form_label": c["cur_label"],
                        "role": item.get("role") or "",
                        "rarity": c["rarity"],
                        "level": f"Lv{c['level_base']}+{c['level_plus']}",
                        "dps": (c.get("stats") or {}).get("dps"),
                        "abilities": c["abilities"][:4],
                        "immunities": c["immunities"],
                        "talents": c["talents_spent"],
                        "orbs": c["orbs"],
                    })
                return out

            loadout = _loadout_from(data)
            if not any(u["id"] is not None for u in loadout):
                log("No valid cat ids in the reply; retrying once...")
                self._set_status("Asking AI (retry)")
                text, raw, exitcode, _ = run_bigpickle(prompt, [roster_p, combos_p, stage_p, items_p])
                data = extract_json(text) or (extract_json(raw) if raw else None)
                loadout = _loadout_from(data)
                lap("AI retry received")
                if not any(u["id"] is not None for u in loadout):
                    raise ValueError("big-pickle returned a loadout with no valid cat ids.")

            while len(loadout) < 10:
                used = {u["id"] for u in loadout if u["id"] is not None}
                def _dps(c):
                    return (c.get("stats") or {}).get("dps") or 0
                auto_filled = []
                for c in sorted(cats, key=_dps, reverse=True):
                    if c["id"] in used or len(loadout) >= 10:
                        continue
                    loadout.append({
                        "id": c["id"],
                        "name": c["base_name"],
                        "form": c["cur_name"],
                        "form_label": c["cur_label"],
                        "role": "auto-fill",
                        "rarity": c["rarity"],
                        "level": f"Lv{c['level_base']}+{c['level_plus']}",
                        "dps": _dps(c),
                        "abilities": c["abilities"][:4],
                        "immunities": c["immunities"],
                        "talents": c["talents_spent"],
                        "orbs": c["orbs"],
                    })
                    auto_filled.append(c["id"])
                    used.add(c["id"])
                if auto_filled:
                    log("AI did not fill every slot with valid owned ids - auto-filled the rest with the "
                        f"player's strongest owned cats: {', '.join(str(i) for i in auto_filled)}")
                if len(loadout) >= 10:
                    break
            while len(loadout) < 10:
                loadout.append({"id": None, "name": "", "form": "", "form_label": "", "role": "",
                                "rarity": "", "level": "", "dps": None,
                                "abilities": [], "immunities": [], "talents": [], "orbs": []})

            wave_text = (stage_info.get("text") or "").lower()
            enforce_loadout_rules(loadout, cats, wave_text, log=log)
            _enforce_cost_restriction(loadout, stage_info.get("text", ""), cats, by_id, log=log)
            _enforce_trait_counters(loadout, stage_info.get("text", ""), cats, by_id, log=log)

            reasoning = data.get("reasoning", "")
            reasoning = _clean_reasoning(reasoning, loadout, by_id)
            warnings = _validate_loadout(loadout, stage_info.get("text", ""), by_id, log=log)

            forced_powerups = [str(p) for p in (powerups or [])]
            merged_powerups = forced_powerups + [str(p) for p in (data.get("powerups", []) or [])]
            seen_powerups = set()
            final_powerups = []
            for p in merged_powerups:
                if p and p not in seen_powerups:
                    seen_powerups.add(p)
                    final_powerups.append(p)

            result = {
                "stage": stage_name,
                "stage_title": stage_info["title"],
                "stage_url": stage_info["url"],
                "stage_source": stage_info["source"],
                "cannons_owned": cannons,
                "loadout": loadout,
                "combos_used": data.get("combos_used", []) or [],
                "cannon": data.get("cannon", ""),
                "powerups": final_powerups,
                "reasoning": reasoning,
                "warnings": warnings,
                "cached": False,
            }
            log(f"Loadout ready: {len([u for u in loadout if u['id'] is not None])} of 10 slots filled.")
            lap("loadout complete")
            results[fp] = result
            _cache_save(RESULT_CACHE_FILE, results)
            with self.lock:
                self.result = result
                self.done = True
                self.running = False
        except Exception as e:
            import traceback
            log("ERROR: " + str(e))
            for l in traceback.format_exc().splitlines():
                log(l)
            with self.lock:
                self.error = str(e)
                self.done = True
                self.running = False


# ---------------------------------------------------------------------------
# Evolve advice (big-pickle recommends what to evolve next)
# ---------------------------------------------------------------------------

def write_evolve_files(evolve_text, roster_text, items_text):
    os.makedirs(TMP_DIR, exist_ok=True)
    evolve_p = os.path.join(TMP_DIR, "evolve.txt")
    roster_p = os.path.join(TMP_DIR, "roster.txt")
    items_p = os.path.join(TMP_DIR, "items.txt")
    with open(evolve_p, "w", encoding="utf-8") as f:
        f.write("EVOLVE PLANNER (from your save):\n" + evolve_text)
    with open(roster_p, "w", encoding="utf-8") as f:
        f.write("PLAYER ROSTER:\n" + roster_text)
    with open(items_p, "w", encoding="utf-8") as f:
        f.write(items_text)
    return evolve_p, roster_p, items_p


def build_evolve_advice_message():
    return """You are Big Pickle, a Battle Cats strategist. You know true/ultra evolution costs and how much each evolution changes a cat.

The player's save was parsed. Attached:
- evolve.txt: which evolutions are affordable RIGHT NOW (READY) and which are close (ALMOST, with the blocker).
- roster.txt: the player's owned cats.
- items.txt: their cat fruit, behemoth stones and XP.

TASK: Recommend what to evolve next. Be VERY terse: no paragraphs, no repeated costs, no essays. Treat XP and catfruit as shared resources; only mention a conflict if it actually matters. Favour evolutions that meaningfully change how useful a cat is.

Reply with ONLY a JSON object (no markdown fences, no text outside it):
{"pick": "Cat Name -> New Form", "priority": ["Cat -> Form", ...up to 3 more], "reasoning": "one short sentence, max 15 words", "save": "one short phrase (what to farm/save for) or empty string"}

Example reply:
{"pick": "Sonic Cat -> Sonic Cat CC", "priority": ["Jurassic Cat -> Jurassic Cat CC"], "reasoning": "Sonic is free now; Jurassic needs 500k XP.", "save": "farm catfruit stages"}
"""


def _first_sentence(text, limit=200):
    """Trim rambling advice to a single short sentence."""
    text = (text or "").strip().replace("\n", " ")
    if not text:
        return ""
    for sep in (". ", "! ", "? "):
        idx = text.find(sep)
        if 0 < idx <= limit:
            return text[:idx + 1]
    return text[:limit]


class AdviceRunner:
    def __init__(self):
        self.lock = threading.Lock()
        self.running = False
        self.done = False
        self.error = None
        self.status = ""
        self.log_lines = []
        self.result = None

    def _log(self, line):
        with self.lock:
            self.log_lines.append(line)

    def _set_status(self, text):
        with self.lock:
            self.status = text

    def snapshot(self):
        with self.lock:
            return {
                "running": self.running,
                "done": self.done,
                "error": self.error,
                "status": self.status,
                "log": list(self.log_lines),
                "result": self.result,
            }

    def start(self):
        if self.running:
            return False
        with self.lock:
            self.running = True
            self.done = False
            self.error = None
            self.status = ""
            self.log_lines = []
            self.result = None
        threading.Thread(target=self._run, daemon=True).start()
        return True

    def _run(self):
        log = self._log
        try:
            self._set_status("Building evolve plan")
            log("Reading the evolve planner...")
            plan = evolve.plan()
            plan_text = evolve.plan_detail_text()

            cats = db.all_cats()
            roster_text = build_roster_text(cats)
            items_raw = db.get_meta("items")
            items_text = build_items_text(json.loads(items_raw)) if items_raw else \
                "(no inventory data - run Detect to get item counts)"
            items_text += "\n\n" + evolve.plan_text()

            evolve_p, roster_p, items_p = write_evolve_files(plan_text, roster_text, items_text)
            prompt = build_evolve_advice_message()
            self._set_status("Asking big-pickle")
            log("Asking big-pickle for a recommendation...")

            text, raw, exitcode, dropped = run_bigpickle(prompt, [evolve_p, roster_p, items_p])
            self._set_status("Parsing advice")

            delay = 5
            data = extract_json(text) or (extract_json(raw) if raw else None)
            for attempt in range(4):
                if data:
                    break
                reason = "server dropped request (0 tokens)" if dropped else f"no JSON (exit {exitcode})"
                log(f"{reason}; retry {attempt + 1}/4 in {delay}s...")
                self._set_status(f"Asking big-pickle (retry {attempt + 1}/4)")
                time.sleep(delay)
                text, raw, exitcode, dropped = run_bigpickle(prompt, [evolve_p, roster_p, items_p])
                data = extract_json(text) or (extract_json(raw) if raw else None)
                delay = min(delay * 2, 60)
            if not data:
                self._log("RAW REPLY (could not parse JSON):\n" + (text[:2000] or raw[:2000]))
                self._log("CLI exit code: %s" % exitcode)
                raise ValueError("big-pickle did not return a valid JSON reply.")

            ready = plan.get("ready") or []
            pick = (data.get("pick") or "").strip()
            if not pick and ready:
                pick = f"{ready[0]['name']} -> {ready[0]['form_name']}"

            result = {
                "pick": pick,
                "reasoning": _first_sentence(data.get("reasoning", "")),
                "priority": data.get("priority", []) or [],
                "save": data.get("save", ""),
            }
            log(f"Advice ready: pick={result['pick'] or '(none)'}")
            with self.lock:
                self.result = result
                self.done = True
                self.running = False
        except Exception as e:
            import traceback
            log("ERROR: " + str(e))
            for l in traceback.format_exc().splitlines():
                log(l)
            with self.lock:
                self.error = str(e)
                self.done = True
                self.running = False


# ---------------------------------------------------------------------------
# Gacha seed advice (big-pickle plans what to roll next)
# ---------------------------------------------------------------------------

def _rarity_tag(rar):
    return {
        "normal": "Normal", "special": "Special", "rare": "Rare", "supa": "Super",
        "supa_fest": "Super", "uber": "UBER", "uber_fest": "UBER",
        "legend": "LEGEND", "exclusive": "EXCLUSIVE", "found": "Found",
    }.get(rar, rar or "?")


def build_seed_context(result, owned_ids=None, owned_names=None):
    """Human-readable summary of the tracked seed for the AI prompt."""
    owned_ids = owned_ids or set()
    owned_names = {n.lower() for n in (owned_names or [])}
    res = result["resources"]
    lines = [
        "SEED CONTEXT (live tracks from bc.godfat.org)",
        f"Seed: {result['seed']}  (fetched {result['date']})",
        "Position 1 = the NEXT roll for your current save seed. Rolls advance sequentially; "
        "rolling on track A also advances track B (track B is what you get if you switch sides mid-track). "
        "An 11-pull grants the guaranteed cat at that position when the banner has one.",
        "",
        "RESOURCES:",
        f"- rare tickets: {res.get('rare_tickets', 0)}",
        f"- platinum tickets: {res.get('platinum_tickets', 0)}",
        f"- legend tickets: {res.get('legend_tickets', 0)}",
        f"- normal tickets: {res.get('normal_tickets', 0)}",
        f"- cat food: {res.get('cat_food', 0)}",
        "",
        f"CURRENT BANNER: {result.get('current_label') or result.get('current_banner')}",
        "",
    ]
    for b in result.get("banners", []):
        mark = " [CURRENT]" if b.get("is_current") else ""
        lines.append(f"=== {b['id']} | {b['label']} {b['date']}{mark} ===")
        for letter in ("A", "B"):
            lines.append(f"Track {letter}:")
            tr = b["tracks"].get(letter, [])
            for e in tr[:30]:
                star = "*" if e.get("next") else " "
                gar = " [guaranteed: " + e["guaranteed"]["name"] + "]" if e.get("guaranteed") else ""
                lines.append(f"  {star}{e['pos']:>3} {_rarity_tag(e['rarity']):9} {e['name'] or '?'}{gar}")
            def _owned(e):
                app_id = None
                if e.get("id"):
                    try:
                        app_id = int(e["id"]) - 1
                    except ValueError:
                        pass
                return (app_id in owned_ids) or (e.get("name") and e["name"].lower() in owned_names)
            new_hits = {}
            for e in tr:
                if e["rarity"] in ("uber", "uber_fest", "legend", "exclusive") and not _owned(e):
                    kind = "legend" if e["rarity"] == "legend" else ("exclusive" if e["rarity"] == "exclusive" else "uber")
                    new_hits.setdefault(kind, e)
            for kind, lab in (("uber", "first NEW Uber"), ("legend", "first NEW Legend"),
                              ("exclusive", "first NEW Exclusive")):
                v = new_hits.get(kind)
                if v:
                    lines.append(f"  >> {lab} (not owned): #{v['pos']} {v['name']} ({_rarity_tag(v['rarity'])})")
                else:
                    lines.append(f"  >> {lab} (not owned): none in first {len(tr)}")
            h = b["highlights"].get(letter, {})
            for kind, lab in (("next_uber", "first Uber overall"), ("next_legend", "first Legend overall")):
                v = h.get(kind)
                if v:
                    lines.append(f"  >> {lab}: #{v['pos']} {v['name']} ({_rarity_tag(v['rarity'])})")
            if len(tr) > 30:
                lines.append(f"  ... (positions 1-{len(tr)} shown; full 100 positions tracked)")
            lines.append("")
    up = result.get("upcoming") or []
    if up:
        lines.append("UPCOMING CAPSULE EVENTS (track not pre-fetched):")
        for e in up:
            lines.append(f"- {e['label']}")
        lines.append("")
    return "\n".join(lines)


def write_seed_files(context_text, roster_text):
    os.makedirs(TMP_DIR, exist_ok=True)
    ctx_p = os.path.join(TMP_DIR, "seed_context.txt")
    roster_p = os.path.join(TMP_DIR, "roster.txt")
    with open(ctx_p, "w", encoding="utf-8") as f:
        f.write(context_text)
    with open(roster_p, "w", encoding="utf-8") as f:
        f.write("PLAYER ROSTER (only these cats exist for this player; never suggest rolling for one they already own):\n"
                + roster_text)
    return ctx_p, roster_p


def load_last_advice():
    """Last generated gacha plan (persisted so it survives an app restart)."""
    try:
        with open(os.path.join(TMP_DIR, "seed_advice_result.json"), encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return None


def build_seed_advice_message():
    return """You are Big Pickle, a Battle Cats gacha strategist. You understand the seed-based gacha: the track is fixed by the seed, position 1 is the next roll, and rolling advances the track.

Attached:
- seed_context.txt: the player's exact gacha seed, resources (rare/platinum/legend tickets, cat food), the current capsule banner, live tracks for the current banner plus the permanent Platinum and Legend capsules (first 30 positions each side, with the first NEW (not yet owned) Uber/Legend/Exclusive computed across all 100 positions), and the list of upcoming capsule events.
- roster.txt: the cats the player already owns.

The player wants to know what to roll for next: the fastest path to their next Uber Rare or Legend Rare, whether their platinum/legend ticket should be used NOW (and what it would give), and whether to pull on the current banner, wait for an upcoming banner, or spend a ticket instead. An 11-pull is 1500 cat food; a single is 150.

Rules:
- Never recommend rolling for a cat the player already owns.
- Base "rolls needed" on the position number (position 1 = next roll, so a unit at #7 is 7 rolls away if you roll straight down the track).
- Account for track switching (A vs B) only if it clearly improves the outcome.
- Recommend a single clear action, not a menu of options.

Reply with ONLY a JSON object (no markdown fences, no text outside it):
{"action": "<one clear action: e.g. Roll current banner / Use platinum ticket / Use legend ticket / Wait for <banner> / Save tickets>", "next_uber": "<position + track + name, or 'none in first 100'>", "next_legend": "<position + track + name, or 'none in first 100'>", "banner": "<which banner to roll on, or why not>", "steps": ["<step 1>", "<step 2>", ... max 4], "reasoning": "<1-2 sentences, max 25 words>"}

Example reply:
{"action": "Roll the current banner", "next_uber": "7A Kamukura (7 rolls)", "next_legend": "none in first 100", "banner": "current Vornado banner", "steps": ["Roll 7 singles on track A", "You get Kamukura", "Then stop - next Uber is 35B"], "reasoning": "Kamukura in 7 rolls is the fastest Uber available."}
"""


class SeedAdviceRunner:
    def __init__(self):
        self.lock = threading.Lock()
        self.running = False
        self.done = False
        self.error = None
        self.status = ""
        self.log_lines = []
        self.result = None

    def _log(self, line):
        with self.lock:
            self.log_lines.append(line)

    def _set_status(self, text):
        with self.lock:
            self.status = text

    def snapshot(self):
        with self.lock:
            return {
                "running": self.running,
                "done": self.done,
                "error": self.error,
                "status": self.status,
                "log": list(self.log_lines),
                "result": self.result,
            }

    def start(self):
        if self.running:
            return False
        with self.lock:
            self.running = True
            self.done = False
            self.error = None
            self.status = ""
            self.log_lines = []
            self.result = None
        threading.Thread(target=self._run, daemon=True).start()
        return True

    def _run(self):
        log = self._log
        try:
            self._set_status("Reading seed track")
            import seed_track
            result = seed_track.load_last_result()
            if not result:
                raise ValueError("No seed track yet - click 'Track seed' first.")

            cats = db.all_cats()
            roster_text = build_roster_text(cats)
            owned_ids = {c["id"] for c in cats}
            owned_names = {c["base_name"] for c in cats}
            context_text = build_seed_context(result, owned_ids, owned_names)
            ctx_p, roster_p = write_seed_files(context_text, roster_text)
            prompt = build_seed_advice_message()
            self._set_status("Asking big-pickle")
            log("Asking big-pickle for a gacha plan...")

            text, raw, exitcode, dropped = run_bigpickle(prompt, [ctx_p, roster_p])
            self._set_status("Parsing advice")

            delay = 5
            data = extract_json(text) or (extract_json(raw) if raw else None)
            for attempt in range(4):
                if data:
                    break
                reason = "server dropped request (0 tokens)" if dropped else f"no JSON (exit {exitcode})"
                log(f"{reason}; retry {attempt + 1}/4 in {delay}s...")
                self._set_status(f"Asking big-pickle (retry {attempt + 1}/4)")
                time.sleep(delay)
                text, raw, exitcode, dropped = run_bigpickle(prompt, [ctx_p, roster_p])
                data = extract_json(text) or (extract_json(raw) if raw else None)
                delay = min(delay * 2, 60)
            if not data:
                self._log("RAW REPLY (could not parse JSON):\n" + (text[:2000] or raw[:2000]))
                self._log("CLI exit code: %s" % exitcode)
                raise ValueError("big-pickle did not return a valid JSON reply.")

            result = {
                "action": data.get("action", ""),
                "next_uber": data.get("next_uber", ""),
                "next_legend": data.get("next_legend", ""),
                "banner": data.get("banner", ""),
                "steps": data.get("steps", []) or [],
                "reasoning": _first_sentence(data.get("reasoning", ""), 260),
            }
            try:
                with open(os.path.join(TMP_DIR, "seed_advice_result.json"), "w", encoding="utf-8") as f:
                    json.dump(result, f, ensure_ascii=False)
            except Exception:
                pass
            log("Plan ready: " + (result["action"] or "(no action)"))
            with self.lock:
                self.result = result
                self.done = True
                self.running = False
        except Exception as e:
            import traceback
            log("ERROR: " + str(e))
            for l in traceback.format_exc().splitlines():
                log(l)
            with self.lock:
                self.error = str(e)
                self.done = True
                self.running = False


# ---------------------------------------------------------------------------
# Banner calendar advice (big-pickle plans around the wiki event schedule)
# ---------------------------------------------------------------------------

def build_banner_advice_message():
    return """You are Big Pickle, a Battle Cats gacha planner. You plan rolling around the current and upcoming capsule banners and special events.

Attached:
- banner_schedule.txt: the wiki's current/upcoming capsule banners (with dates and days left) and live special events/stages.
- seed_context.txt: the player's tracked seed (only present if they have tracked it) with the next high-rarity cats on each track.
- roster.txt: the cats the player already owns.

The player wants a clear answer: roll now or wait, and on which banner? Consider each banner's theme (which enemy traits its featured ubers specialize in) against the player's roster gaps and the stage events that are live (e.g. if a stage event needs Aliens, a banner with anti-Alien ubers becomes more valuable). Never recommend rolling for a cat they already own. 11-pull = 1500 cat food, single = 150.

Reply with ONLY a JSON object (no markdown fences, no text outside it):
{"verdict": "<one clear action, e.g. Roll <banner> now / Wait for <banner> / Save cat food / Spend tickets>", "banner": "<best banner name and its dates>", "why": "<1-2 sentences on why this banner is the best pick for THIS player>", "steps": ["<step 1>", "<step 2>", ... max 3], "reasoning": "<very short summary, max 20 words>"}

Example reply:
{"verdict": "Roll 'Tales of the Nekoluga' now", "banner": "Tales of the Nekoluga (08-21 ~ 08-24)", "why": "You lack long-ranged attackers and this banner's ubers are long-range; track B gives you a new Legend in 4 rolls.", "steps": ["Do 4 singles on track B", "Pick up the Legend at #4", "Stop after that"], "reasoning": "Fastest new high-rarity, fills a roster gap."}
"""


def write_banner_files(schedule_text, seed_text, roster_text):
    os.makedirs(TMP_DIR, exist_ok=True)
    sched_p = os.path.join(TMP_DIR, "banner_schedule.txt")
    roster_p = os.path.join(TMP_DIR, "roster.txt")
    with open(sched_p, "w", encoding="utf-8") as f:
        f.write(schedule_text)
        if seed_text:
            f.write("\n\n" + seed_text)
    with open(roster_p, "w", encoding="utf-8") as f:
        f.write("PLAYER ROSTER (only these cats exist for this player):\n" + roster_text)
    return sched_p, roster_p


class BannerPlanRunner:
    def __init__(self):
        self.lock = threading.Lock()
        self.running = False
        self.done = False
        self.error = None
        self.status = ""
        self.log_lines = []
        self.result = None

    def _log(self, line):
        with self.lock:
            self.log_lines.append(line)

    def _set_status(self, text):
        with self.lock:
            self.status = text

    def snapshot(self):
        with self.lock:
            return {
                "running": self.running,
                "done": self.done,
                "error": self.error,
                "status": self.status,
                "log": list(self.log_lines),
                "result": self.result,
            }

    def start(self):
        if self.running:
            return False
        with self.lock:
            self.running = True
            self.done = False
            self.error = None
            self.status = ""
            self.log_lines = []
            self.result = None
        threading.Thread(target=self._run, daemon=True).start()
        return True

    def _run(self):
        log = self._log
        try:
            import banners
            import seed_track
            self._set_status("Fetching event schedule")
            log("Fetching the wiki event schedule...")
            sched = banners.get_schedule()
            log(f"Schedule: {len([e for e in sched['gacha'] if e['status'] == 'current'])} live banners, "
                f"{len([e for e in sched['gacha'] if e['status'] == 'upcoming'])} upcoming")

            seed_text = ""
            track = seed_track.load_last_result()
            if track:
                self._set_status("Reading seed track")
                log("Found a saved seed track - including it in the plan.")
                owned_ids = {c["id"] for c in db.all_cats()}
                owned_names = {c["base_name"] for c in db.all_cats()}
                seed_text = build_seed_context(track, owned_ids, owned_names)

            cats = db.all_cats()
            roster_text = build_roster_text(cats)
            sched_p, roster_p = write_banner_files(banners.schedule_text(), seed_text, roster_text)
            prompt = build_banner_advice_message()
            self._set_status("Asking big-pickle")
            log("Asking big-pickle for a roll plan...")

            text, raw, exitcode, dropped = run_bigpickle(prompt, [sched_p, roster_p])
            self._set_status("Parsing advice")

            delay = 5
            data = extract_json(text) or (extract_json(raw) if raw else None)
            for attempt in range(4):
                if data:
                    break
                reason = "server dropped request (0 tokens)" if dropped else f"no JSON (exit {exitcode})"
                log(f"{reason}; retry {attempt + 1}/4 in {delay}s...")
                self._set_status(f"Asking big-pickle (retry {attempt + 1}/4)")
                time.sleep(delay)
                text, raw, exitcode, dropped = run_bigpickle(prompt, [sched_p, roster_p])
                data = extract_json(text) or (extract_json(raw) if raw else None)
                delay = min(delay * 2, 60)
            if not data:
                self._log("RAW REPLY (could not parse JSON):\n" + (text[:2000] or raw[:2000]))
                self._log("CLI exit code: %s" % exitcode)
                raise ValueError("big-pickle did not return a valid JSON reply.")

            result = {
                "verdict": data.get("verdict", ""),
                "banner": data.get("banner", ""),
                "why": _first_sentence(data.get("why", ""), 320),
                "steps": data.get("steps", []) or [],
                "reasoning": _first_sentence(data.get("reasoning", ""), 220),
            }
            log("Plan ready: " + (result["verdict"] or "(no verdict)"))
            with self.lock:
                self.result = result
                self.done = True
                self.running = False
        except Exception as e:
            import traceback
            log("ERROR: " + str(e))
            for l in traceback.format_exc().splitlines():
                log(l)
            with self.lock:
                self.error = str(e)
                self.done = True
                self.running = False


# ---------------------------------------------------------------------------
# Stage beat-check (big-pickle says whether your roster can win a stage)
# ---------------------------------------------------------------------------

def build_beat_message(has_loadout=False):
    loadout_section = ""
    if has_loadout:
        loadout_section = """
- loadout.txt: the 10-unit loadout the AI just built for this stage, with each unit's name, id, and role. Your best_plan should reference THESE specific units by name (e.g. "Your Seafarer Cat will freeze the Aliens while Crazed Bahamut provides DPS"). Do NOT suggest units that aren't in the loadout."""
    return f"""You are Big Pickle, a Battle Cats strategist. You judge whether a player's roster can beat a specific stage.

Attached:
- stage.txt: the requested stage, the wiki page found for it, and the wiki page text (enemies, enemy levels, gimmicks, energy, base HP, restrictions).
- roster.txt: the player's owned cats with forms, levels, abilities, immunities, talents and DPS stats.{loadout_section}

Be honest and concrete. Consider: the enemies' traits vs the player's anti-trait options, whether they have a unit that outranges each key enemy, meatshield quality, status-immunity needs, the level curve of the stage (an endgame stage at high enemy levels will defeat under-leveled rosters regardless of composition), and any restrictions (no continues, locked units, boss bar timers).

For every key enemy, look up its description in stage.txt and judge its abilities from what the description actually says. Never decide an enemy's special abilities (barrier, shield, wave, surge, warp) from its trait or its name alone - not every Alien has a barrier (a Starry Alien usually does, a normal one may not), and not every enemy with "Cyclone" in its name has one either. NEVER mention a unit the player does not own (no Manic/awakened cats, no Legend Rares, no cats absent from roster.txt) - if the roster lacks a counter, say so in words without naming an unowned cat.

Reply with ONLY a JSON object (no markdown fences, no text outside it):
{{"verdict": "<likely win | close call | likely lose>", "difficulty": <1-10>, "threats": ["<main threats, max 3>"], "needs": ["<what's missing or needed to win, max 3>"], "best_plan": "<1-2 sentences on how the player should beat it, referencing the actual loadout units by name>", "recommended_levels": "<level advice, e.g. 'level your attacker to 40+'>", "reasoning": "<very short summary, max 20 words>"}}

Example reply:
{{"verdict": "close call", "difficulty": 7, "threats": ["Bore at high level", "constant Doge spam", "short stage"], "needs": ["a strong Red attacker", "a level 40+ area attacker"], "best_plan": "Stall the Doges with cheap walls and burn the Bore down with your anti-Red ubers.", "recommended_levels": "Take your anti-Red attacker to level 40+", "reasoning": "You have the units but they are under-leveled for the enemy levels here."}}
"""


def write_beat_files(stage_info, roster_text):
    beat_dir = os.path.join(TMP_DIR, "beat")
    os.makedirs(beat_dir, exist_ok=True)
    stage_p = os.path.join(beat_dir, "stage.txt")
    roster_p = os.path.join(beat_dir, "roster.txt")
    with open(stage_p, "w", encoding="utf-8") as f:
        f.write(f"Stage requested: {stage_info.get('requested', '')}\n")
        f.write(f"Wiki page: {stage_info.get('title', '')}\n")
        f.write(f"Wiki: {stage_info.get('url', '')}\n")
        f.write("--- wiki page text ---\n")
        f.write(stage_info.get("text") or "(no wiki text could be fetched)")
    with open(roster_p, "w", encoding="utf-8") as f:
        f.write("PLAYER ROSTER (only these units exist for this player):\n" + roster_text)
    return stage_p, roster_p


class BeatCheckRunner:
    def __init__(self):
        self.lock = threading.Lock()
        self.running = False
        self.done = False
        self.error = None
        self.status = ""
        self.log_lines = []
        self.result = None

    def _log(self, line):
        with self.lock:
            self.log_lines.append(line)

    def _set_status(self, text):
        with self.lock:
            self.status = text

    def snapshot(self):
        with self.lock:
            return {
                "running": self.running,
                "done": self.done,
                "error": self.error,
                "status": self.status,
                "log": list(self.log_lines),
                "result": self.result,
            }

    def start(self, stage_name, loadout=None):
        if self.running:
            return False
        with self.lock:
            self.stage_name = stage_name
            self.loadout = loadout
            self.running = True
            self.done = False
            self.error = None
            self.status = ""
            self.log_lines = []
            self.result = None
        threading.Thread(target=self._run, daemon=True).start()
        return True

    def _run(self):
        log = self._log
        stage_name = self.stage_name
        loadout = getattr(self, "loadout", None)
        try:
            self._set_status("Looking up stage")
            log(f"Looking up stage '{stage_name}' on the wiki...")
            stage_info = lookup_stage(stage_name)
            stage_info["requested"] = stage_name
            if stage_info.get("url"):
                log(f"Found: {stage_info['title']} ({stage_info['source']})")
            else:
                log("No wiki page auto-found; big-pickle will judge from its own knowledge.")

            cats = db.all_cats()
            cats_by_id = {c["id"]: c for c in cats}
            roster_text = build_roster_text(cats)

            # Build loadout text if provided
            loadout_text = ""
            if loadout:
                lines = []
                for i, slot in enumerate(loadout, 1):
                    if not slot.get("id"):
                        continue
                    c = cats_by_id.get(slot["id"])
                    if c:
                        role = slot.get("role", "")
                        lines.append(f"Slot {i}: [{c['id']}] {c['base_name']} ({c['cur_name']}) — {role}")
                loadout_text = "\n".join(lines)

            stage_p, roster_p = write_beat_files(stage_info, roster_text)
            loadout_p = None
            if loadout_text:
                beat_dir = os.path.join(TMP_DIR, "beat")
                loadout_p = os.path.join(beat_dir, "loadout.txt")
                with open(loadout_p, "w", encoding="utf-8") as f:
                    f.write(f"SELECTED LOADOUT (10 units for this stage):\n{loadout_text}\n")

            prompt = build_beat_message(has_loadout=bool(loadout_text))
            self._set_status("Asking big-pickle")
            log("Asking big-pickle whether you can beat it...")

            attachments = [stage_p, roster_p]
            if loadout_p:
                attachments.append(loadout_p)
            text, raw, exitcode, dropped = run_bigpickle(prompt, attachments)
            self._set_status("Parsing verdict")

            delay = 5
            data = extract_json(text) or (extract_json(raw) if raw else None)
            for attempt in range(4):
                if data:
                    break
                reason = "server dropped request (0 tokens)" if dropped else f"no JSON (exit {exitcode})"
                log(f"{reason}; retry {attempt + 1}/4 in {delay}s...")
                self._set_status(f"Asking big-pickle (retry {attempt + 1}/4)")
                time.sleep(delay)
                text, raw, exitcode, dropped = run_bigpickle(prompt, attachments)
                data = extract_json(text) or (extract_json(raw) if raw else None)
                delay = min(delay * 2, 60)
            if not data:
                self._log("RAW REPLY (could not parse JSON):\n" + (text[:2000] or raw[:2000]))
                self._log("CLI exit code: %s" % exitcode)
                raise ValueError("big-pickle did not return a valid JSON reply.")

            result = {
                "stage": stage_name,
                "stage_title": stage_info.get("title", ""),
                "stage_url": stage_info.get("url", ""),
                "verdict": data.get("verdict", ""),
                "difficulty": data.get("difficulty"),
                "threats": data.get("threats", []) or [],
                "needs": data.get("needs", []) or [],
                "best_plan": _first_sentence(data.get("best_plan", ""), 320),
                "recommended_levels": _first_sentence(data.get("recommended_levels", ""), 200),
                "reasoning": _first_sentence(data.get("reasoning", ""), 220),
            }
            log("Verdict: " + (result["verdict"] or "(no verdict)"))
            with self.lock:
                self.result = result
                self.done = True
                self.running = False
        except Exception as e:
            import traceback
            log("ERROR: " + str(e))
            for l in traceback.format_exc().splitlines():
                log(l)
            with self.lock:
                self.error = str(e)
                self.done = True
                self.running = False

