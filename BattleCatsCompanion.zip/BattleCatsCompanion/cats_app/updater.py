"""Self-update support.

How to publish a new version (for the app author):
  1. Build the zip (the whole package folder, as you do now).
  2. Upload it to a GitHub repo (files up to ~100 MB work with raw links).
  3. Upload a version.json next to it, e.g.:
       { "version": "0.11.1", "changelog": ["Fixed X", "Added Y"],
         "zip_url": "https://raw.githubusercontent.com/USER/REPO/main/BattleCatsCompanion.zip" }
  4. Change REPO below to your user/repo.
Anyone who runs the app then gets a "Check for updates" button in the Detect tab.

The updater NEVER overwrites: .venv, data.db (your roster), cache (downloaded data),
tmp, __pycache__, version.txt or update_log.txt.
"""

import json
import os
import re
import shutil
import threading
import time
import zipfile

APP_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_DIR = os.path.dirname(APP_DIR)
VERSION_FILE = os.path.join(APP_DIR, "version.txt")
UPDATE_LOG = os.path.join(APP_DIR, "update_log.txt")

# Set to "<user>/<repo>" once you publish on GitHub (see header comment).
REPO = "robinpotat/BattleCatsCompanion"
# jsDelivr auto-purges its cache when a commit is pushed, so the manifest stays
# fresh right after a release; raw.githubusercontent.com is the fallback.
MANIFEST_URLS = [
    f"https://cdn.jsdelivr.net/gh/{REPO}@main/version.json",
    f"https://raw.githubusercontent.com/{REPO}/main/version.json",
]

# Top-level entries inside the update zip that are skipped when applying.
KEEP = {".venv", "data.db", "cache", "tmp", "__pycache__", ".opencode",
        "version.txt", "update_log.txt", "model.txt",
        "cats_report.json", "cats_all.txt", "cats_changes.txt"}


def _ver_key(v):
    """Turn a version string like '0.11.23' into an orderable tuple of ints."""
    nums = re.findall(r"\d+", str(v))
    return tuple(int(n) for n in nums) or (0,)


def local_version():
    try:
        with open(VERSION_FILE, encoding="utf-8") as f:
            return f.read().strip() or "0.0.0"
    except Exception:
        return "0.0.0"


def read_update_log(limit=200):
    try:
        with open(UPDATE_LOG, encoding="utf-8") as f:
            lines = [l.rstrip() for l in f if l.strip()]
        return lines[-limit:]
    except Exception:
        return []


def check_for_update(timeout=20):
    """Fetch version.json and compare. Returns a dict (never raises)."""
    if "YOUR_USERNAME" in REPO:
        return {"error": "Updater is not configured yet (edit REPO in updater.py)."}
    try:
        import requests
        cands = []
        for url in MANIFEST_URLS:
            try:
                r = requests.get(f"{url}?ts={int(time.time())}", timeout=timeout)
                if r.status_code == 200:
                    m = json.loads(r.text)
                    if m.get("version"):
                        cands.append(m)
            except Exception:
                continue
    except Exception as e:
        return {"error": f"Could not reach the update server: {e}"}
    if not cands:
        return {"error": "Could not reach the update server (all manifest mirrors failed)."}
    m = max(cands, key=lambda x: _ver_key(x.get("version", "0")))
    latest = str(m.get("version", "")).strip()
    changelog = m.get("changelog") or []
    if not latest:
        return {"error": "Bad version.json (no version field)."}
    local = local_version()
    return {
        "current": local,
        "latest": latest,
        "update_available": _ver_key(latest) > _ver_key(local),
        "downgrade_available": _ver_key(latest) < _ver_key(local),
        "changelog": changelog if isinstance(changelog, list) else [],
        "zip_url": m.get("zip_url") or "",
        "zip_name": m.get("zip_name") or "BattleCatsCompanion.zip",
    }


class UpdateRunner:
    def __init__(self):
        self.lock = threading.Lock()
        self.running = False
        self.done = False
        self.error = None
        self.log_lines = []
        self.result = None

    def _log(self, line):
        with self.lock:
            self.log_lines.append(line)

    def snapshot(self):
        with self.lock:
            return {"running": self.running, "done": self.done, "error": self.error,
                    "log": list(self.log_lines), "result": self.result}

    def start(self, zip_url, latest_version, changelog):
        if self.running:
            return False
        with self.lock:
            self.running = True
            self.done = False
            self.error = None
            self.result = None
            self.log_lines = []
        threading.Thread(target=self._run, args=(zip_url, latest_version, changelog), daemon=True).start()
        return True

    def _run(self, zip_url, latest_version, changelog):
        log = self._log
        try:
            if _ver_key(latest_version) <= _ver_key(local_version()):
                raise ValueError(
                    f"Refusing to install v{latest_version} over the installed v{local_version()} "
                    f"because the update is not newer.")
            log(f"Downloading {zip_url} ...")
            import requests
            tmp = os.path.join(APP_DIR, "tmp", "update_download")
            os.makedirs(tmp, exist_ok=True)
            zpath = os.path.join(tmp, "update.zip")
            with requests.get(zip_url, stream=True, timeout=120) as r:
                r.raise_for_status()
                with open(zpath, "wb") as f:
                    shutil.copyfileobj(r.raw, f)
            log(f"Downloaded {os.path.getsize(zpath) / 1024 / 1024:.1f} MB. Extracting ...")
            extract_dir = os.path.join(tmp, "extract")
            shutil.rmtree(extract_dir, ignore_errors=True)
            with zipfile.ZipFile(zpath) as z:
                z.extractall(extract_dir)
            top = _top_level(extract_dir)
            extracted_v = _extracted_version(top)
            if extracted_v is not None:
                if _ver_key(extracted_v) < _ver_key(latest_version):
                    raise ValueError(
                        f"The downloaded zip contains v{extracted_v}, but this update promised "
                        f"v{latest_version} - a mirror may have served a stale zip. "
                        f"Nothing was installed; try again in a few minutes.")
                log(f"Zip verified: contains v{extracted_v}.")
            else:
                log("Warning: could not read the zip's version.txt to verify it.")
            log("Installing files (your roster/cache/venv are kept) ...")
            copied = _copy_tree(top, PROJECT_DIR, log)
            log(f"Installed {copied} files.")
            with open(VERSION_FILE, "w", encoding="utf-8") as f:
                f.write(latest_version + "\n")
            _append_update_log(latest_version, changelog)
            shutil.rmtree(tmp, ignore_errors=True)
            with self.lock:
                self.result = {"version": latest_version, "files": copied}
                self.done = True
                self.running = False
        except Exception as e:
            log("ERROR: " + str(e))
            with self.lock:
                self.error = str(e)
                self.done = True
                self.running = False


def _top_level(extract_dir):
    entries = [os.path.join(extract_dir, e) for e in os.listdir(extract_dir)]
    dirs = [e for e in entries if os.path.isdir(e)]
    if len(dirs) == 1 and not any(os.path.isfile(e) for e in entries):
        return dirs[0]
    return extract_dir


def _extracted_version(top):
    for candidate in (os.path.join(top, "cats_app", "version.txt"),
                      os.path.join(top, "version.txt")):
        try:
            with open(candidate, encoding="utf-8") as f:
                v = f.read().strip()
                if v:
                    return v
        except Exception:
            continue
    return None


def _copy_tree(src, dst, log):
    count = 0
    for root, dirs, files in os.walk(src):
        rel = os.path.relpath(root, src).replace("\\", "/")
        if rel != ".":
            parts = rel.split("/")
            if any(p in KEEP for p in parts):
                dirs[:] = []
                continue
        dest_dir = os.path.join(dst, *rel.split("/")) if rel != "." else dst
        os.makedirs(dest_dir, exist_ok=True)
        for fn in files:
            relparts = (rel + "/" + fn if rel != "." else fn).split("/")
            if any(p in KEEP for p in relparts):
                continue
            shutil.copy2(os.path.join(root, fn), os.path.join(dest_dir, fn))
            count += 1
    return count


def _append_update_log(version, changelog):
    try:
        with open(UPDATE_LOG, "a", encoding="utf-8") as f:
            f.write(f"\n===== {time.strftime('%Y-%m-%d %H:%M:%S')}  updated to v{version} =====\n")
            for line in changelog or []:
                text = str(line)
                if text.strip().startswith(version):
                    f.write("  - " + text + "\n")
            f.write("  (other entries omitted - see full changelog on GitHub)\n")
    except Exception:
        pass
    _trim_update_log(10)


def _trim_update_log(max_entries=10):
    """Keep only the most recent version blocks in update_log.txt."""
    try:
        with open(UPDATE_LOG, "r", encoding="utf-8") as f:
            lines = f.readlines()
    except Exception:
        return
    blocks = []
    cur = []
    for line in lines:
        if line.strip().startswith("=====") and cur:
            blocks.append(cur)
            cur = [line]
        else:
            cur.append(line)
    if cur:
        blocks.append(cur)
    if len(blocks) <= max_entries:
        return
    keep = blocks[-max_entries:]
    with open(UPDATE_LOG, "w", encoding="utf-8") as f:
        for block in keep:
            f.writelines(block)
