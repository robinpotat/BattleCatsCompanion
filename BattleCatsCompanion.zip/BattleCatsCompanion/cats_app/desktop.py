import ctypes
import os
import socket
import threading
import time
import urllib.request

import webview

import db
import stats
from app import app

APP_DIR = os.path.dirname(os.path.abspath(__file__))
ICON_PATH = os.path.join(APP_DIR, "assets", "icon.ico")
APP_ID = "BattleCatsCompanion.Desktop.1"
PORT = 8765
URL = f"http://127.0.0.1:{PORT}"

WM_SETICON = 0x0080
ICON_SMALL = 0
ICON_BIG = 1
IMAGE_ICON = 1
LR_LOADFROMFILE = 0x00000010
LR_DEFAULTSIZE = 0x00000040


def _set_app_id():
    try:
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(APP_ID)
    except Exception:
        pass


def _port_open(host, port):
    with socket.socket() as s:
        s.settimeout(0.4)
        return s.connect_ex((host, port)) == 0


def _port_owner(host, port):
    """PID of the process listening on host:port, or None."""
    import subprocess
    try:
        out = subprocess.run(["netstat", "-ano", "-p", "tcp"],
                             capture_output=True, text=True, timeout=5).stdout or ""
        for line in out.splitlines():
            if f"{host}:{port}" not in line:
                continue
            parts = line.split()
            if len(parts) >= 5 and parts[-1].isdigit():
                return int(parts[-1])
    except Exception:
        pass
    return None


def _server_ready(timeout):
    """Wait until THIS process's server answers HTTP on the app port.

    Checking the port alone is not enough: during a restart the *old* server can
    still satisfy it, so the window would open and then hit a dead server (black
    window). We require an HTTP 200 AND that the listening socket belongs to our
    own process.
    """
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            with urllib.request.urlopen(URL, timeout=1) as r:
                if r.status == 200 and _port_owner("127.0.0.1", PORT) == os.getpid():
                    return True
        except Exception:
            pass
        time.sleep(0.2)
    return False


def _is_our_instance_pid(pid):
    """Best-effort: is PID a python running this app's desktop.py?
    If the command line can't be read, assume it is ours rather than kill a
    possibly-healthy instance."""
    if pid is None or pid <= 0 or pid == os.getpid():
        return False
    import subprocess
    try:
        out = subprocess.run(
            ["powershell", "-NoProfile", "-NonInteractive", "-Command",
             f"(Get-CimInstance Win32_Process -Filter 'ProcessId={pid}').CommandLine"],
            capture_output=True, text=True, timeout=5).stdout or ""
    except Exception:
        out = ""
    if out.strip():
        return "desktop.py" in out
    return True


def _port_state():
    """Classify whatever is listening on the app port.
    Returns 'duplicate' (a healthy copy of this app), 'stale' (another process
    or a wedged holder), or None (port free / not yet bound)."""
    if not _port_open("127.0.0.1", PORT):
        return None
    for _ in range(10):
        try:
            with urllib.request.urlopen(URL, timeout=0.5) as r:
                if r.status == 200:
                    owner = _port_owner("127.0.0.1", PORT)
                    if owner is not None and owner != os.getpid() and _is_our_instance_pid(owner):
                        return "duplicate"
                    return "stale"
        except Exception:
            time.sleep(0.3)
    return "stale"


def _kill_port_holder():
    """Force-kill whatever process currently holds the app port."""
    import subprocess
    owner = _port_owner("127.0.0.1", PORT)
    if owner and owner != os.getpid():
        try:
            subprocess.run(["taskkill", "/F", "/PID", str(owner)],
                           capture_output=True, timeout=5)
        except Exception:
            pass


def _log_crash(msg):
    try:
        with open(os.path.join(APP_DIR, "desktop_crash.log"), "a") as f:
            f.write(f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] {msg}\n")
    except Exception:
        pass


def _warm_cache():
    try:
        stats.ensure_cache()
    except Exception:
        pass


def run_server():
    try:
        state = _port_state()
        if state == "duplicate" and not os.environ.get("BCC_RESTART"):
            # A healthy copy of this app is already running. Activate its window
            # and exit instead of fighting over the port (fighting is what made
            # rapid double-clicks look like the app 'not opening').
            try:
                urllib.request.urlopen(URL + "/api/activate", timeout=3)
            except Exception:
                pass
            os._exit(0)
        if state in ("stale", "duplicate"):
            # A foreign process holds the port, or the old instance is shutting
            # down after a restart. Give it a moment, then force-kill if stuck.
            deadline = time.time() + 8
            while time.time() < deadline and _port_open("127.0.0.1", PORT):
                time.sleep(0.5)
            if _port_open("127.0.0.1", PORT):
                _kill_port_holder()
                time.sleep(1)
        db.init_db()
        # Cache warm-up can hit the network for a long time; it must not delay
        # binding the server, or the window would never open.
        threading.Thread(target=_warm_cache, daemon=True).start()
        for _ in range(15):
            try:
                app.run(host="127.0.0.1", port=PORT, threaded=True,
                        debug=False, use_reloader=False)
                return
            except OSError:
                time.sleep(1)
        _log_crash("could not bind port 8765 after 15 tries")
    except Exception:
        import traceback
        try:
            with open(os.path.join(APP_DIR, "desktop_crash.log"), "a") as f:
                traceback.print_exc(file=f)
        except Exception:
            pass


def _apply_icon(window):
    try:
        hwnd = window.native.Handle.ToInt32()
    except Exception:
        return
    hicon = ctypes.windll.user32.LoadImageW(
        0, ICON_PATH, IMAGE_ICON, 0, 0, LR_LOADFROMFILE | LR_DEFAULTSIZE)
    if hicon:
        ctypes.windll.user32.SendMessageW(hwnd, WM_SETICON, ICON_BIG, hicon)
        ctypes.windll.user32.SendMessageW(hwnd, WM_SETICON, ICON_SMALL, hicon)


def _wait_and_icon(window):
    deadline = time.time() + 60
    while time.time() < deadline:
        try:
            if getattr(window, "native", None) is not None:
                _apply_icon(window)
                return
        except Exception:
            pass
        time.sleep(0.2)


WINDOW_TITLE = "Battle Cats Companion"

HWND_TOPMOST = -1
HWND_NOTOPMOST = -2
SWP_NOSIZE = 0x0001
SWP_NOMOVE = 0x0002
SWP_NOACTIVATE = 0x0010


def _bring_to_front(window=None):
    """Make sure the window is visible and on top of other apps (e.g. a wedged
    WebView2 init left it hidden, or it sits behind a fullscreen browser).

    Pure Win32 on purpose: this can be called from the Flask request thread
    (a duplicate launch hitting /api/activate), so it must never make
    cross-thread .NET/WinForms calls that could deadlock the server.
    """
    deadline = time.time() + 60
    while time.time() < deadline:
        try:
            hwnd = ctypes.windll.user32.FindWindowW(None, WINDOW_TITLE)
            if hwnd:
                if ctypes.windll.user32.IsIconic(hwnd):
                    ctypes.windll.user32.ShowWindow(hwnd, 9)      # SW_RESTORE
                elif not ctypes.windll.user32.IsWindowVisible(hwnd):
                    ctypes.windll.user32.ShowWindow(hwnd, 5)      # SW_SHOW
                ctypes.windll.user32.SetWindowPos(
                    hwnd, HWND_TOPMOST, 0, 0, 0, 0,
                    SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE)
                ctypes.windll.user32.SetWindowPos(
                    hwnd, HWND_NOTOPMOST, 0, 0, 0, 0,
                    SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE)
                ctypes.windll.user32.SetForegroundWindow(hwnd)
                return
            time.sleep(0.2)
        except Exception:
            time.sleep(0.2)


if __name__ == "__main__":
    _set_app_id()
    threading.Thread(target=run_server, daemon=True).start()
    if not _server_ready(60):
        _log_crash("server did not start; skipping window to avoid a blank screen")
        os._exit(1)
    if os.environ.get("BCC_DEBUG"):
        webview.settings['REMOTE_DEBUGGING_PORT'] = 9223
    window = webview.create_window(
        WINDOW_TITLE,
        URL,
        width=1280,
        height=860,
        min_size=(920, 640),
        background_color="#10131a",
    )
    import app as app_module
    app_module.activate_hook = _bring_to_front
    threading.Thread(target=_wait_and_icon, args=(window,), daemon=True).start()
    threading.Thread(target=_bring_to_front, args=(window,), daemon=True).start()
    webview.start()
