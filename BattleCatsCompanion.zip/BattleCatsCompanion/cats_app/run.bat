@echo off
cd /d "%~dp0"

rem 1) Prefer the venv created by Setup.bat
if exist ".venv\Scripts\pythonw.exe" (
  start "" /B ".venv\Scripts\pythonw.exe" desktop.py
  exit /b
)

rem 2) pythonw directly on PATH
set "PYW="
for /f "delims=" %%i in ('where pythonw 2^>nul') do if not defined PYW set "PYW=%%i"

rem 3) pythonw derived from the py launcher (works even without PATH)
if not defined PYW for /f "delims=" %%i in ('py -3 -c "import sys,os;print(os.path.join(os.path.dirname(sys.executable),'pythonw.exe'))" 2^>nul') do if not defined PYW set "PYW=%%i"

if defined PYW (
  start "" /B "%PYW%" desktop.py
  exit /b
)

echo.
echo [ERROR] Could not find Python.
echo Run Setup.bat once first (it installs Python if needed and prepares this folder).
echo If you already ran Setup.bat, it may have failed - re-run it and read the messages.
echo.
pause
