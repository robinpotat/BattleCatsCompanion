"""Saved loadout presets - a named loadout you can reload without regenerating."""

import json
import os
import time

APP_DIR = os.path.dirname(os.path.abspath(__file__))
PRESETS_FILE = os.path.join(APP_DIR, "tmp", "presets.json")


def _load():
    try:
        with open(PRESETS_FILE, encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, list) else []
    except Exception:
        return []


def _save(data):
    os.makedirs(os.path.dirname(PRESETS_FILE), exist_ok=True)
    with open(PRESETS_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)


def list_presets():
    return _load()


def save_preset(name, result):
    presets = _load()
    presets = [p for p in presets if p.get("name", "").lower() != name.lower()]
    presets.insert(0, {
        "name": name,
        "saved_at": time.strftime("%Y-%m-%d %H:%M"),
        "result": result,
    })
    _save(presets)
    return {"saved": name, "count": len(presets)}


def delete_preset(name):
    presets = [p for p in _load() if p.get("name", "").lower() != name.lower()]
    _save(presets)
    return {"deleted": name, "count": len(presets)}
