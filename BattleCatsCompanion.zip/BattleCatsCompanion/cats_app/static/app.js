const $ = (s) => document.querySelector(s);

// ---------- tabs ----------
let activeTab = "detect";
function positionTabInd() {
  const ind = $("#tab-ind");
  const btn = $(".tab.active");
  if (!ind || !btn) return;
  ind.style.left = btn.offsetLeft + "px";
  ind.style.width = btn.offsetWidth + "px";
}
function activateTab(name) {
  if (!name) return;
  activeTab = name;
  document.querySelectorAll(".tab").forEach((x) => x.classList.toggle("active", x.dataset.tab === name));
  document.querySelectorAll(".panel").forEach((x) => x.classList.toggle("active", x.id === "tab-" + name));
  positionTabInd();
}
document.querySelectorAll(".tab").forEach((t) => {
  t.addEventListener("click", () => activateTab(t.dataset.tab));
});
document.querySelectorAll(".qa").forEach((b) => {
  b.addEventListener("click", () => activateTab(b.dataset.go));
});
$("#tabs").addEventListener("keydown", (e) => {
  if (e.key !== "ArrowRight" && e.key !== "ArrowLeft") return;
  const tabs = [...document.querySelectorAll(".tab")];
  const i = tabs.indexOf(document.activeElement);
  if (i < 0) return;
  e.preventDefault();
  const ni = (i + (e.key === "ArrowRight" ? 1 : tabs.length - 1)) % tabs.length;
  tabs[ni].focus();
  activateTab(tabs[ni].dataset.tab);
});
window.addEventListener("resize", positionTabInd);

// ---------- helpers ----------
function esc(s) {
  return String(s ?? "").replace(/[&<>"']/g, (c) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;",
  }[c]));
}

// ---------- enemy name linking ----------
let _enemyTitles = null;
async function _loadEnemyTitles() {
  if (_enemyTitles) return _enemyTitles;
  try {
    const r = await api("/api/enemies/all");
    _enemyTitles = (r.titles || []).sort((a, b) => b.length - a.length);
  } catch { _enemyTitles = []; }
  return _enemyTitles;
}
function linkifyEnemies(text) {
  if (!text || !_enemyTitles || !_enemyTitles.length) return esc(text || "");
  let safe = esc(text);
  for (const name of _enemyTitles) {
    const escName = esc(name);
    const re = new RegExp("\\b(" + escName.replace(/[.*+?^${}()|[\]\\]/g, "\\$&") + ")\\b", "gi");
    safe = safe.replace(re, (m) => "\x00ENEMYLINK:" + btoa(unescape(encodeURIComponent(m))) + "\x01");
  }
  return safe.replace(/\x00ENEMYLINK:([A-Za-z0-9+/=]+)\x01/g, (_, b64) => {
    const name = decodeURIComponent(escape(atob(b64)));
    return '<a href="#" class="enemy-link" data-enemy="' + esc(name) + '">' + esc(name) + '</a>';
  });
}
function goToEnemy(name) {
  activateTab("enemies");
  const q = $("#enemy-q");
  q.value = name;
  searchEnemies(name);
}

function animateNum(el, to, money) {
  const store = (window.__statVals = window.__statVals || {});
  const cur = store[el.id] != null ? store[el.id] : to;
  store[el.id] = to;
  if (cur === to) {
    el.textContent = money ? Number(to).toLocaleString() : String(to);
    return;
  }
  const t0 = performance.now();
  const dur = 500;
  (function tick(t) {
    const k = Math.min((t - t0) / dur, 1);
    const v = Math.round(cur + (to - cur) * (1 - Math.pow(1 - k, 3)));
    el.textContent = money ? Number(v).toLocaleString() : String(v);
    if (k < 1) requestAnimationFrame(tick);
  })(t0);
}
async function api(url, opts) {
  const r = await fetch(url, opts);
  return r.json();
}
function rarityCls(r) {
  return "rarity-" + r.replace(/\s+/g, "\\ ");
}

function appendLog(el, lines, seenKey) {
  let seen = window[seenKey] || 0;
  for (let i = seen; i < lines.length; i++) {
    const div = document.createElement("div");
    div.textContent = lines[i];
    if (/error|warning|failed/i.test(lines[i])) div.classList.add("err");
    el.appendChild(div);
  }
  window[seenKey] = lines.length;
  el.scrollTop = el.scrollHeight;
}

// ---------- state ----------
async function refreshState() {
  const st = await api("/api/state");
  animateNum($("#stat-cats"), st.cats_owned || 0, false);
  animateNum($("#stat-combos"), st.combos || 0, false);
  if (st.catfood != null) animateNum($("#stat-catfood"), st.catfood, true);
  else $("#stat-catfood").textContent = "-";
  if (st.np != null) animateNum($("#stat-np"), st.np, true);
  else $("#stat-np").textContent = "-";
  $("#stat-last").textContent = st.last_detect || "-";
  $("#header-meta").textContent = st.db_populated
    ? `v${st.data_version} · ${st.cats_owned} cats · 🪙 ${st.catfood != null ? Number(st.catfood).toLocaleString() : "-"} · NP ${st.np != null ? Number(st.np).toLocaleString() : "-"} · last detect ${st.last_detect || "-"}`
    : "no data yet — hit Detect";
  const banner = $("#stale-banner");
  if (st.db_populated && st.save_version && st.data_version && st.save_version !== st.data_version) {
    banner.hidden = false;
    banner.innerHTML = `⚠️ Your save is <b>v${esc(st.save_version)}</b> but the roster data is <b>v${esc(st.data_version)}</b>. New or changed cats may be missing or wrong — press <b>Detect save</b> to fetch data for v${esc(st.save_version)}.`;
  } else {
    banner.hidden = true;
  }
  if (st.db_populated) {
    loadRoster();
    loadCombos();
    loadTalents();
    loadItems();
    loadEvolve();
  }
  refreshPresets();
  loadBanners();
  loadSeedSaved();
}

// ---------- detect ----------
async function startDetect() {
  $("#btn-detect").disabled = true;
  $("#btn-detect-quick").disabled = true;
  $("#detect-log").innerHTML = "";
  $("#detect-result").innerHTML = "";
  window.detectSeen = 0;
  await api("/api/detect", { method: "POST" });
  pollDetect();
}

async function pollDetect() {
  const s = await api("/api/detect/status");
  appendLog($("#detect-log"), s.log, "detectSeen");
  if (s.running) {
    setTimeout(pollDetect, 900);
    return;
  }
  $("#btn-detect").disabled = false;
  $("#btn-detect-quick").disabled = false;
  if (s.error) {
    $("#detect-result").innerHTML = `<h3 style="color:#ff6b6b">Detect failed</h3><p>${esc(s.error)}</p>`;
  } else if (s.result) {
    const r = s.result;
    let html = `<h3>✅ Detect complete</h3><p>Stored <b>${r.cats}</b> cats, <b>${r.combos}</b> combos, <b>${r.orbs}</b> orb types. 🪙 ${Number(r.catfood || 0).toLocaleString()} cat food · NP ${Number(r.np || 0).toLocaleString()}.</p>`;
    if (r.rarity) {
      html += `<div class="sub">Rarity: ${Object.entries(r.rarity).map(([k, v]) => `${esc(k)} ${v}`).join(" · ")}</div>`;
    }
    if (r.changes && r.changes.length) {
      html += `<div class="list">` + changesHtml(r.changes) + `</div>`;
    } else {
      html += `<p class="meta">No changes since the last run.</p>`;
    }
    $("#detect-result").innerHTML = html;
  }
loadSeed();
loadUpdateLog();
refreshState();
}

function changesHtml(lines) {
  return lines.map((l) => {
    let html = "";
    let last = 0;
    const re = /\[(\d+)\]\s*([^\]\[]*)/g;
    let m;
    while ((m = re.exec(l))) {
      html += esc(l.slice(last, m.index));
      const id = m[1];
      const name = m[2].trim();
      if (name && ALL_CATS.some((x) => String(x.id) === id)) {
        html += `<button class="link-cat" data-id="${id}">[${id}] ${esc(name)}</button>`;
      } else {
        html += esc(m[0]);
      }
      last = re.lastIndex;
    }
    html += esc(l.slice(last));
    return `<div class="entry">${html}</div>`;
  }).join("");
}

async function goToCat(id) {
  activateTab("roster");
  if (!ALL_CATS.length) await loadRoster();
  $("#roster-q").value = "";
  $("#roster-rarity").value = "";
  $("#roster-filter").value = "";
  renderRoster();
  const c = ALL_CATS.find((x) => String(x.id) === String(id));
  if (!c) return;
  document.querySelectorAll("#roster-table tbody tr").forEach((tr) => tr.classList.remove("hl"));
  renderCatDetail(c, true);
  const tr = document.querySelector(`#roster-table tbody tr[data-id="${c.id}"]`);
  if (tr) {
    tr.classList.add("hl");
    tr.scrollIntoView({ behavior: "smooth", block: "center" });
  }
}
$("#detect-result").addEventListener("click", (e) => {
  const btn = e.target.closest(".link-cat");
  if (btn) goToCat(btn.dataset.id);
});

$("#btn-detect").addEventListener("click", startDetect);
$("#btn-detect-quick").addEventListener("click", () => {
  activateTab("detect");
  startDetect();
});

// ---------- roster ----------
let ALL_CATS = [];
let SORT = { key: null, dir: 1 }; // dir: 1 = asc, -1 = desc
const FORM_LABELS = { 0: "Base", 1: "Evolved", 2: "True", 3: "Ultra" };
let FORM_SEL = {};
try { FORM_SEL = JSON.parse(localStorage.getItem("formSel") || "{}") || {}; } catch (e) {}

function availForms(c) {
  const s = c.stats || {};
  const forms = s.forms || null;
  if (!forms) return null;
  const lvl = c.level_base || 0;
  const normal = c.rarity === "Normal";
  const out = [0];
  if (lvl >= 10) out.push(1);
  if (forms["2"] != null) {
    const unlocked = normal || c.cur >= 2 || c.unl >= 2;
    const lvlOk = normal ? lvl >= 20 : lvl >= 30;
    if (unlocked && lvlOk) out.push(2);
  }
  if (forms["3"] != null && lvl >= 60 && (c.cur >= 3 || c.unl >= 3)) out.push(3);
  if (!out.includes(c.cur)) out.push(c.cur);
  return out.sort((a, b) => a - b);
}

function selFormIdx(c) {
  const s = c.stats || {};
  const forms = s.forms || null;
  const avail = availForms(c);
  let f = FORM_SEL[c.id] != null ? FORM_SEL[c.id] : (s.form != null ? s.form : c.cur);
  if (forms && forms[f] == null) f = s.form != null ? s.form : c.cur;
  if (avail && !avail.includes(f)) f = c.cur;
  if (avail && !avail.includes(f)) f = 0;
  return f;
}

function selStats(c) {
  const s = c.stats || {};
  return (s.forms && s.forms[selFormIdx(c)]) || s;
}

let banSelected = new Set();
let requireSelected = new Set();
let powerupChecked = new Set();

function renderCatSelect(sel, query, selectedSet) {
  const q = query.trim().toLowerCase();
  const opts = ALL_CATS
    .filter((c) => !q || catSearchText(c).toLowerCase().includes(q))
    .map((c) => `<option value="${c.id}"${selectedSet.has(c.id) ? " selected" : ""}>[${c.id}] ${esc(c.base_name)} (${esc(c.cur_name)})</option>`)
    .join("");
  sel.innerHTML = opts || `<option value="" disabled>No matches</option>`;
}

async function loadPowerupPicker() {
  const box = $("#powerup-picker");
  if (!box) return;
  let items = { battle_items: [] };
  try {
    items = await api("/api/items");
  } catch (e) { /* keep empty */ }
  const list = (items.battle_items || []).filter((i) => (i.count || 0) > 0);
  if (!list.length) {
    box.innerHTML = `<div class="sub">Detect your save first to see your power-ups</div>`;
    return;
  }
  box.innerHTML = list.map((i) =>
    `<label class="pp-item"><input type="checkbox" value="${esc(i.name)}"> ${esc(i.name)} <span class="meta">x${i.count}</span></label>`
  ).join("");
  box.querySelectorAll("input").forEach((cb) => {
    cb.addEventListener("change", () => {
      if (cb.checked) powerupChecked.add(cb.value);
      else powerupChecked.delete(cb.value);
    });
  });
}

async function loadRoster() {
  ALL_CATS = await api("/api/cats");
  populateRosterFilter();
  renderCatSelect($("#loadout-ban"), $("#ban-search").value, banSelected);
  renderCatSelect($("#loadout-require"), $("#require-search").value, requireSelected);
  loadPowerupPicker();
  renderRoster();
}
$("#ban-search").addEventListener("input", () => renderCatSelect($("#loadout-ban"), $("#ban-search").value, banSelected));
$("#require-search").addEventListener("input", () => renderCatSelect($("#loadout-require"), $("#require-search").value, requireSelected));
$("#loadout-ban").addEventListener("change", () => { banSelected = new Set([...$("#loadout-ban").selectedOptions].map((o) => +o.value)); });
$("#loadout-require").addEventListener("change", () => { requireSelected = new Set([...$("#loadout-require").selectedOptions].map((o) => +o.value)); });

function abilityParts(a) {
  // "Barrier Break 100%" -> {name:"Barrier Break", value:"100%"}
  // "Freeze 30% (2.0s)"  -> {name:"Freeze", value:"30%, 2.0s"}
  // "Long Distance 170~470" -> {name:"Long Distance", value:"170~470"}
  // "2x Money" -> {name:"2x Money", value:""}
  const s = String(a || "").trim();
  const m = s.match(/^(.*?)(?=\s*\(|\s[-\d])/);
  const name = (m ? m[1] : s).trim();
  let value = s.slice(name.length).trim();
  if (value) {
    if (value.startsWith("(") && value.endsWith(")")) value = value.slice(1, -1).trim();
    else value = value.replace(/\s*\(\s*/g, ", ").replace(/\s*\)/g, "");
  }
  return { name, value };
}

function abilityLabel(a) {
  const p = abilityParts(a);
  return p.value ? p.name + " (" + p.value + ")" : p.name;
}

function abilityBase(a) {
  return abilityParts(a).name;
}

function clipLabel(a, max = 2) {
  const s = String(a || "");
  const i = s.indexOf(" vs ");
  if (i < 0) return s;
  const head = s.slice(0, i + 4);
  const parts = s.slice(i + 4).split(/\s*,\s*|\s+and\s+/).filter(Boolean);
  if (parts.length <= max) return s;
  return head + parts.slice(0, max).join(", ") + " +" + (parts.length - max) + " more";
}

function filterAbilityParts(a) {
  const s = String(a || "").trim();
  const i = s.indexOf(" vs ");
  if (i > 0) {
    const targets = s.slice(i + 4).split(/\s*,\s*|\s+and\s+/).filter(Boolean);
    if (targets.length) return { base: s.slice(0, i).trim(), targets };
  }
  const p = abilityParts(a);
  return { base: p.name, targets: [] };
}

function filterOptionKey(f) {
  return f.base + (f.targets.length ? " vs " + f.targets.join(", ") : "");
}

let FILTER_COMBOS = new Map();

function catSearchText(c) {
  const parts = [c.base_name, c.cur_name, c.cur_label, c.rarity, ...(c.traits || [])];
  const s = c.stats || {};
  if (s.forms) {
    for (const f of Object.values(s.forms)) {
      if (f.form_name) parts.push(f.form_name);
      if (f.form_label) parts.push(f.form_label);
    }
  }
  (c.abilities || []).forEach((a) => parts.push(abilityBase(a)));
  (c.immunities || []).forEach((i) => parts.push(i));
  (c.talents_spent || []).forEach((t) => parts.push(t.name));
  (c.orbs || []).forEach((o) => parts.push(o.name));
  return parts.filter(Boolean).join(" ").toLowerCase();
}

function populateRosterFilter() {
  const sel = $("#roster-filter");
  sel.innerHTML = '<option value="">Trait / ability...</option>';
  FILTER_COMBOS = new Map();
  const traits = new Set();
  for (const c of ALL_CATS) {
    for (const a of (c.abilities || [])) {
      const f = filterAbilityParts(a);
      FILTER_COMBOS.set(filterOptionKey(f), f);
    }
    for (const t of (c.traits || [])) traits.add(t);
  }
  const ogT = document.createElement("optgroup");
  ogT.label = "Traits";
  [...traits].sort().forEach((t) => {
    const opt = document.createElement("option");
    opt.value = "tr:" + t;
    opt.textContent = t;
    ogT.appendChild(opt);
  });
  sel.appendChild(ogT);
  const ogA = document.createElement("optgroup");
  ogA.label = "Abilities";
  [...FILTER_COMBOS.values()]
    .sort((x, y) => filterOptionKey(x).localeCompare(filterOptionKey(y)))
    .forEach((f) => {
      const opt = document.createElement("option");
      const full = filterOptionKey(f);
      opt.value = "ab:" + full;
      opt.textContent = clipLabel(full);
      ogA.appendChild(opt);
    });
  sel.appendChild(ogA);
  sel.dataset.ready = "1";
}

function sortVal(c, key) {
  if (key === "level") return c.level_base + c.level_plus;
  const s = selStats(c);
  if (key === "dps") return s.dps || -1;
  if (key === "atk") return s.damage || -1;
  if (key === "hp") return s.health || -1;
  if (key === "range") return s.range != null ? s.range : -1;
  return 0;
}

function sortRows(rows) {
  if (!SORT.key) return rows;
  const key = SORT.key;
  return rows.slice().sort((a, b) => {
    const va = sortVal(a, key);
    const vb = sortVal(b, key);
    if (va === vb) return a.base_name.localeCompare(b.base_name);
    return (va - vb) * SORT.dir;
  });
}

function renderRoster() {
  const q = ($("#roster-q").value || "").toLowerCase();
  const rarity = $("#roster-rarity").value;
  const filt = $("#roster-filter").value;
  let rows = ALL_CATS.filter((c) => {
    if (rarity && c.rarity !== rarity) return false;
    if (q && !catSearchText(c).includes(q)) return false;
    if (filt.startsWith("ab:")) {
      const want = FILTER_COMBOS.get(filt.slice(3));
      if (!want) return false;
      const ok = (c.abilities || []).some((a) => {
        const f = filterAbilityParts(a);
        return f.base === want.base && f.targets.join("|") === want.targets.join("|");
      });
      if (!ok) return false;
    } else if (filt.startsWith("tr:")) {
      if (!(c.traits || []).includes(filt.slice(3))) return false;
    }
    return true;
  });
  rows = sortRows(rows);
  $("#roster-count").textContent = `${rows.length} cats`;
  document.querySelectorAll("#roster-table th[data-sort]").forEach((th) => {
    const lbl = th.dataset.label || th.dataset.sort.toUpperCase();
    th.classList.toggle("sorted", th.dataset.sort === SORT.key);
    th.textContent = th.dataset.sort === SORT.key
      ? lbl + (SORT.dir === 1 ? " ▲" : " ▼")
      : lbl + " ↕";
  });
  const tb = $("#roster-table tbody");
  tb.innerHTML = rows.map((c) => {
    const ab = (c.abilities || []).slice(0, 4).map((a) => clipLabel(abilityLabel(a))).join("; ");
    const im = (c.immunities || []).map(esc).join(", ");
    const t = (c.talents_spent || []).map((x) => `${esc(x.name)} ${x.level}/${x.max}`).join(", ");
    const o = (c.orbs || []).filter((x) => x.name !== "(empty)").map((x) => esc(x.name)).join(", ");
    const s = c.stats || {};
    const forms = s.forms || null;
    const avail = availForms(c);
    const fIdx = selFormIdx(c);
    const sel = selStats(c);
    const fmt = (n) => (n == null ? "-" : Number(n).toLocaleString());
    const st = sel.dps
      ? `<td title="HP ${fmt(sel.health)} · ATK ${fmt(sel.damage)} · cost ${fmt(sel.cost)} · rng ${sel.range} · speed ${sel.speed} · KB ${sel.kb}">${fmt(sel.dps)}</td>`
      : `<td class="meta">-</td>`;
    let formCell;
    if (forms && avail && avail.length > 1) {
      const opts = avail.map((k) => {
        const f = forms[k];
        const lbl = FORM_LABELS[k] || f.form_label || "F" + k;
        return `<option value="${k}"${String(k) === String(fIdx) ? " selected" : ""}>${esc(lbl)} · ${esc(f.form_name)}</option>`;
      }).join("");
      formCell = `<select class="form-sel" data-id="${c.id}">${opts}</select>`;
    } else {
      formCell = `${esc(c.cur_name)} (${esc(c.cur_label)})`;
    }
    return `<tr data-id="${c.id}">
      <td>${c.id}</td>
      <td class="${rarityCls(c.rarity)}"><b>${esc(c.base_name)}</b></td>
      <td>${esc(c.rarity)}</td>
      <td>Lv${c.level_base}+${c.level_plus}</td>
      ${st}
      <td>${fmt(sel.damage)}</td>
      <td>${fmt(sel.health)}</td>
      <td>${sel.range != null ? sel.range : "-"}</td>
      <td>${formCell}</td>
      <td>${ab || "-"}</td>
      <td>${im || "-"}</td>
      <td>${t || "-"}</td>
      <td>${o || "-"}</td>
    </tr>`;
  }).join("");
}
$("#roster-q").addEventListener("input", renderRoster);
$("#roster-rarity").addEventListener("change", renderRoster);
$("#roster-filter").addEventListener("change", renderRoster);
$("#roster-table tbody").addEventListener("change", (e) => {
  const sel = e.target.closest(".form-sel");
  if (!sel) return;
  FORM_SEL[+sel.dataset.id] = +sel.value;
  try { localStorage.setItem("formSel", JSON.stringify(FORM_SEL)); } catch (err) {}
  renderRoster();
});
document.querySelectorAll("#roster-table th[data-sort]").forEach((th) => {
  th.addEventListener("click", () => {
    const key = th.dataset.sort;
    if (SORT.key === key) {
      SORT.dir = -SORT.dir;
    } else {
      SORT.key = key;
      SORT.dir = 1;
    }
    renderRoster();
  });
});

// ---------- cat detail ----------
function renderCatDetail(c, skipScroll) {
  const s = c.stats || {};
  const forms = s.forms || {};
  const fIdx = selFormIdx(c);
  const fmt = (n) => (n == null ? "-" : Number(n).toLocaleString());
  const cards = Object.entries(forms).map(([k, f]) => {
    const cur = String(k) === String(fIdx);
    const formName = esc(f.form_name || "Form " + k);
    const formLbl = esc(FORM_LABELS[k] || f.form_label || "F" + k);
    return `<div class="form-card${cur ? " current" : ""}">
      <h4>${cur ? '<span class="cur-mark">● </span>' : ""}${formName} <span class="tag">${formLbl}</span></h4>
      <div class="row"><span>HP <b>${fmt(f.health)}</b></span><span>ATK <b>${fmt(f.damage)}</b></span><span>DPS <b>${fmt(f.dps)}</b></span></div>
      <div class="row"><span>Range <b>${f.range != null ? f.range : "-"}</b></span><span>Speed <b>${f.speed != null ? f.speed : "-"}</b></span><span>KB <b>${f.kb != null ? f.kb : "-"}</b></span><span>Cost <b>${fmt(f.cost)}</b></span></div>
    </div>`;
  }).join("");
  const talents = (c.talents_spent || []).map((t) => `<span class="tag">${esc(t.name)} ${t.level}/${t.max}</span>`).join(" ") || "none";
  const orbs = (c.orbs || []).filter((o) => o.name !== "(empty)").map((o) => `<span class="tag">⚪ ${esc(o.name)}</span>`).join(" ") || "none";
  const detail = $("#cat-detail");
  detail.innerHTML = `
    <button class="close" title="close">✕</button>
    <h3 class="${rarityCls(c.rarity)}">${esc(c.base_name)} <span class="tag">${esc(c.rarity)}</span></h3>
    <div class="row"><span>Level <b>${c.level_base}+${c.level_plus}</b></span><span>Now: <b>${esc(c.cur_name)}</b> (${esc(c.cur_label)})</span></div>
    ${cards ? `<div class="form-grid">${cards}</div>` : `<div class="sub">No stat data available.</div>`}
    <div class="row" style="margin-top:12px"><span>Targets: <b>${esc((c.traits || []).join(", ") || "none")}</b></span></div>
    <div class="row"><span>Abilities: <b>${esc((c.abilities || []).map(abilityLabel).join("; ") || "none")}</b></span></div>
    <div class="row"><span>Immune: <b>${esc((c.immunities || []).join(", ") || "none")}</b></span></div>
    <div class="row"><span>Talents: </span>${talents}</div>
    <div class="row"><span>Orbs: </span>${orbs}</div>`;
  detail.hidden = false;
  if (!skipScroll) detail.scrollIntoView({ behavior: "smooth", block: "nearest" });
}
$("#cat-detail").addEventListener("click", (e) => {
  if (e.target.classList.contains("close")) $("#cat-detail").hidden = true;
});
$("#roster-table tbody").addEventListener("click", (e) => {
  if (e.target.closest("select")) return;
  const tr = e.target.closest("tr");
  if (!tr || tr.dataset.id == null) return;
  const c = ALL_CATS.find((x) => String(x.id) === tr.dataset.id);
  if (c) renderCatDetail(c);
});

// ---------- combos ----------
let ALL_COMBOS = [];
async function loadCombos() {
  ALL_COMBOS = await api("/api/combos");
  renderCombos();
}
function renderCombos() {
  const q = ($("#combo-q").value || "").toLowerCase();
  const rows = ALL_COMBOS.filter((c) => !q || (c.name + " " + c.members).toLowerCase().includes(q));
  $("#combo-count").textContent = `${rows.length} combos`;
  $("#combo-table tbody").innerHTML = rows.map((c) =>
    `<tr><td><b>${esc(c.name)}</b></td><td>${esc(c.effect)}</td><td>${esc(c.value)}</td><td>${esc(c.members)}${c.note ? ` <span class="meta">${esc(c.note)}</span>` : ""}</td></tr>`
  ).join("");
}
$("#combo-q").addEventListener("input", renderCombos);

// ---------- talents & orbs ----------
async function loadTalents() {
  const [talents, orbs] = await Promise.all([api("/api/talents"), api("/api/orbs")]);
  $("#talents-list").innerHTML = talents.length
    ? talents.map((c) =>
        `<div class="entry"><b class="${rarityCls(c.rarity)}">${esc(c.base_name)}</b> — ` +
        c.talents_spent.map((x) => `${esc(x.name)} <span class="tag">${x.level}/${x.max}</span>`).join(", ") +
        `</div>`).join("")
    : `<div class="entry meta">none yet</div>`;

  $("#orbs-equipped").innerHTML = orbs.equipped.length
    ? orbs.equipped.map((c) =>
        `<div class="entry"><b class="${rarityCls(c.rarity)}">${esc(c.base_name)}</b> — ` +
        c.orbs.filter((o) => o.name !== "(empty)").map((o) => `slot ${o.slot}: <span class="tag">${esc(o.name)}</span>`).join(", ") +
        `</div>`).join("")
    : `<div class="entry meta">none equipped</div>`;

  $("#orbs-inventory").innerHTML = orbs.inventory.length
    ? orbs.inventory.map((o) => `<div class="entry">${esc(o.orb_name)} <span class="tag">x${o.count}</span></div>`).join("")
    : `<div class="entry meta">no orbs in inventory</div>`;
}

// ---------- items ----------
async function loadItems() {
  const it = await api("/api/items");
  renderItems(it);
}
function itemCell(it) {
  return `<div class="entry${it.count ? "" : " zero"}">${esc(it.name)} <span class="tag">x${it.count}</span></div>`;
}
function renderItems(it) {
  const fruit = it.cat_fruit || [];
  const battle = it.battle_items || [];
  const eyes = it.catseyes || [];
  $("#items-catseyes").innerHTML = eyes.length
    ? eyes.map(itemCell).join("")
    : `<div class="entry meta">no data — run Detect first</div>`;
  $("#items-fruit").innerHTML = fruit.length
    ? fruit.map(itemCell).join("")
    : `<div class="entry meta">no data — run Detect first</div>`;
  $("#items-battle").innerHTML = battle.length
    ? battle.map(itemCell).join("")
    : `<div class="entry meta">no data — run Detect first</div>`;
}

// ---------- evolve ----------
async function loadEvolve() {
  const p = await api("/api/evolve");
  renderEvolve(p);
}
function itemsCell(items, missing) {
  if (!items || !items.length) return `<span class="meta">no items</span>`;
  return items.map((it) => {
    const ok = !missing || it.have >= it.count;
    const cls = ok ? "" : " tag-missing";
    return `<span class="tag${cls}">${esc(it.name)} ${it.have}/${it.count}</span>`;
  }).join("");
}
function evolveEntry(e, ready) {
  const blk = (e.blockers || []).length
    ? `<div class="sub">${e.blockers.map(esc).join(" · ")}</div>` : "";
  const farm = (e.missing || []).length
    ? `<div class="sub">🌾 Farm: ${e.missing.map((m) => `<a href="${esc(m.url)}" target="_blank" rel="noopener" title="Stages that drop ${esc(m.name)}">${esc(m.name)} (${m.have}/${m.count})</a>`).join(" · ")}</div>`
    : "";
  const xp = e.need_xp ? `<span class="tag">${Number(e.need_xp).toLocaleString()} XP</span>` : "";
  const lvl = e.need_level != null ? `<span class="tag">Lv${e.need_level}+</span>` : "";
  return `<div class="entry">
    <b class="${rarityCls(e.rarity)}">${esc(e.name)}</b>
    <span class="meta">${esc(e.level)}</span> →
    <b>${esc(e.form_name)}</b> <span class="tag">${esc(e.form_label)}</span>
    ${xp}${lvl}
    <div>${itemsCell(e.items, !ready)}</div>
    ${farm}
    ${blk}
  </div>`;
}
function renderEvolve(p) {
  animateNum($("#evolve-xp"), Number(p.xp || 0), true);
  animateNum($("#evolve-ready"), p.ready_count || 0, false);
  animateNum($("#evolve-almost"), p.almost_count || 0, false);
  const farmEl = $("#evolve-farm");
  const farm = (p.missing_fruit || []).filter((f) => f.need > 0);
  if (farm.length) {
    farmEl.hidden = false;
    farmEl.innerHTML = `<div class="entry">🌾 To clear the "almost ready" list, farm: ${farm.map((f) => `<span class="tag">${esc(f.name)} ×${f.need}</span>`).join(" ")}</div>`;
  } else {
    farmEl.hidden = true;
  }
  $("#evolve-ready-list").innerHTML = p.ready.length
    ? p.ready.map((e) => evolveEntry(e, true)).join("")
    : `<div class="entry meta">nothing affordable right now — farm catfruit or level up.</div>`;
  $("#evolve-almost-list").innerHTML = p.almost.length
    ? p.almost.map((e) => evolveEntry(e, false)).join("")
    : `<div class="entry meta">every remaining evolution is already affordable.</div>`;
}

// ---------- evolve advice ----------
let evolveAdviceTimer = null;
function stopAdvice() {
  if (evolveAdviceTimer) { clearInterval(evolveAdviceTimer); evolveAdviceTimer = null; }
}
async function startEvolveAdvice() {
  $("#btn-evolve-advice").disabled = true;
  stopStatus();
  animateStatus($("#evolve-advice-status"), "Getting AI recommendation");
  $("#evolve-advice").innerHTML = "";
  const res = await api("/api/evolve/advice", { method: "POST" });
  if (res.error) {
    stopStatus();
    $("#evolve-advice-status").textContent = "";
    $("#evolve-advice").innerHTML = `<div class="entry err">${esc(res.error)}</div>`;
    $("#btn-evolve-advice").disabled = false;
    return;
  }
  evolveAdviceTimer = setInterval(pollEvolveAdvice, 900);
}
async function pollEvolveAdvice() {
  const s = await api("/api/evolve/advice/status");
  if (s.running) {
    if (s.status) animateStatus($("#evolve-advice-status"), s.status);
    return;
  }
  stopAdvice();
  stopStatus();
  $("#btn-evolve-advice").disabled = false;
  if (s.error) {
    $("#evolve-advice-status").textContent = "Failed";
    $("#evolve-advice").innerHTML = `<div class="entry err">AI had an issue: ${esc(s.error)}</div>`;
    return;
  }
  $("#evolve-advice-status").textContent = "Done";
  renderAdvice(s.result);
}
function renderAdvice(r) {
  const pick = r.pick
    ? `<div class="advice-pick">⭐ Recommended: <b>${esc(r.pick)}</b></div>`
    : `<div class="advice-pick meta">Nothing affordable right now.</div>`;
  const priority = r.priority && r.priority.length
    ? `<div class="sub">Then: ${r.priority.map(esc).join(" · ")}</div>` : "";
  const note = r.reasoning ? `<span class="advice-note">${esc(r.reasoning)}</span>` : "";
  const save = r.save ? `<span class="tag tag-good">${esc(r.save)}</span>` : "";
  $("#evolve-advice").innerHTML = `<div class="entry">${pick}${priority}<div class="advice-foot">${note}${save}</div></div>`;
}
$("#btn-evolve-advice").addEventListener("click", startEvolveAdvice);

// ---------- loadout ----------
let dotsTimer = null;
function stopStatus() {
  if (dotsTimer) { clearInterval(dotsTimer); dotsTimer = null; }
}
function animateStatus(el, base) {
  stopStatus();
  let n = 0;
  dotsTimer = setInterval(() => {
    n = (n + 1) % 4;
    el.textContent = base + ".".repeat(n);
  }, 400);
}

let loadoutRunning = false;
let beatRunning = false;
function reenableLoadout() {
  if (!loadoutRunning && !beatRunning) {
    $("#btn-loadout").disabled = false;
    $("#btn-loadout-force").disabled = false;
    if (!$("#loadout-status").textContent.includes("Failed")) {
      $("#loadout-status").textContent = "Done";
    }
  }
}

async function startLoadout(force) {
  const stage = $("#stage-input").value.trim();
  if (!stage) { $("#stage-input").focus(); return; }
  const banned = [...banSelected];
  const required = [...requireSelected];
  const powerups = [...powerupChecked];
  const context = ($("#loadout-context").value || "").trim();
  loadoutRunning = true;
  beatRunning = true;
  $("#btn-loadout").disabled = true;
  $("#btn-loadout-force").disabled = true;
  $("#loadout-log").innerHTML = "";
  $("#beat-result").innerHTML = "";
  $("#loadout-result").innerHTML = "";
  $("#loadout-status").textContent = "";
  stopStatus();
  animateStatus($("#loadout-status"), "searching");
  window.loadoutSeen = 0;
  window.beatSeen = 0;
  const res = await api("/api/loadout", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ stage, banned, required, powerups, context, force: !!force }) });
  if (res.error) {
    loadoutRunning = false;
    beatRunning = false;
    stopStatus();
    $("#loadout-status").textContent = res.error;
    reenableLoadout();
    return;
  }
  if (res.started === false) {
    loadoutRunning = false;
    beatRunning = false;
    stopStatus();
    $("#loadout-status").textContent = "Still running from last request — wait for it to finish first.";
    reenableLoadout();
    return;
  }
  pollLoadout();
}

async function pollLoadout() {
  const s = await api("/api/loadout/status");
  appendLog($("#loadout-log"), s.log, "loadoutSeen");
  if (s.running) {
    if (s.status) animateStatus($("#loadout-status"), s.status);
    setTimeout(pollLoadout, 900);
    return;
  }
  loadoutRunning = false;
  stopStatus();
  if (s.error) {
    $("#loadout-status").textContent = "Failed";
    $("#loadout-result").innerHTML = `<h3 style="color:#ff6b6b">Loadout failed</h3>`;
    reenableLoadout();
  } else {
    renderLoadout(s.result);
    // Start beat check now that loadout is ready, passing the loadout units
    const stage = $("#stage-input").value.trim();
    const loadoutData = (s.result && s.result.loadout) || [];
    const beatRes = await api("/api/beat", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ stage, loadout: loadoutData }) });
    if (beatRes.error) {
      beatRunning = false;
      appendLog($("#loadout-log"), ["Beat check skipped: " + beatRes.error], "beatSeen");
      reenableLoadout();
    } else {
      pollBeat();
    }
  }
}

async function pollBeat() {
  const s = await api("/api/beat/status");
  appendLog($("#loadout-log"), s.log, "beatSeen");
  if (s.running) {
    if (s.status) animateStatus($("#loadout-status"), s.status);
    setTimeout(pollBeat, 900);
    return;
  }
  beatRunning = false;
  stopStatus();
  if (s.error) {
    $("#loadout-status").textContent = "Beat check failed";
  } else if (s.result) {
    const r = s.result;
    const color = r.verdict === "likely win" ? "#7CFC00" : r.verdict === "close call" ? "#ffd166" : "#ff6b6b";
    $("#beat-result").innerHTML = `
      <div class="entry beat-check"><h3 style="color:${color}">${esc(r.verdict || "?")} <span class="tag">difficulty ${r.difficulty != null ? r.difficulty : "?"}/10</span></h3>
      ${r.stage_url ? `<div class="sub"><a href="${esc(r.stage_url)}" target="_blank">${esc(r.stage_title)}</a></div>` : ""}
      ${r.threats && r.threats.length ? `<div class="sub">Main threats: ${r.threats.map(esc).join(" · ")}</div>` : ""}
      ${r.needs && r.needs.length ? `<div class="sub">Needed: ${r.needs.map(esc).join(" · ")}</div>` : ""}
      ${r.best_plan ? `<p>${esc(r.best_plan)}</p>` : ""}
      ${r.recommended_levels ? `<div class="sub">${esc(r.recommended_levels)}</div>` : ""}
      ${r.reasoning ? `<div class="meta">${esc(r.reasoning)}</div>` : ""}
      </div>`;
  }
  reenableLoadout();
}

function renderLoadout(r) {
  _loadEnemyTitles();
  window.lastLoadoutResult = r;
  if (!r) {
    $("#loadout-result").innerHTML = `<h3 style="color:#ff6b6b">No loadout result</h3>`;
    return;
  }
  const chips = [];
  if (r.cached) chips.push(`<span class="chip" style="color:#ffd166">♻️ Cached result (earlier run)</span>`);
  chips.push(`<span class="chip">Loadout: <b>${(r.loadout || []).filter((u) => u.id != null).length}/10 slots filled</b></span>`);
  chips.push(`<span class="chip">Stage: <b>${esc(r.stage)}</b></span>`);
  if (r.stage_url) {
    chips.push(`<span class="chip">Wiki page: <a href="${esc(r.stage_url)}" target="_blank">${esc(r.stage_title)}</a></span>`);
  } else {
    chips.push(`<span class="chip">Wiki page: <b>none auto-found</b></span>`);
  }
  const comboNames = (r.combos_used || []);
  if (comboNames.length) {
    chips.push(`<span class="chip combo-chip" data-combo="${esc(comboNames[0])}" onclick="window._toggleComboChip(this)">Combos: <b>${esc(comboNames.join(", "))}</b></span>`);
  } else {
    chips.push(`<span class="chip">Combos: <b>none</b></span>`);
  }
  chips.push(`<span class="chip">Your cannons: <b>${esc((r.cannons_owned || []).join(", ") || "Standard")}</b></span>`);
  if (r.cannon) chips.push(`<span class="chip">Cannon: <b>${esc(r.cannon)}</b></span>`);
  if (r.powerups && r.powerups.length) chips.push(`<span class="chip" style="border-color:var(--good)">Power-ups: <b>${esc(r.powerups.join(", "))}</b></span>`);

  const list = r.loadout && r.loadout.length ? r.loadout : [];
  const slots = list.map((u, i) => {
    if (u.id == null) return `<div class="slot empty"><div class="slotnum">slot ${i + 1}</div><h4>—</h4><div class="sub">empty</div></div>`;
    const ab = (u.abilities || []).slice(0, 4).map(abilityLabel).join(" · ");
    const im = (u.immunities || []).map(esc).join(", ");
    const t = (u.talents || []).map((x) => `<span class="tag">${esc(x.name)} ${x.level}/${x.max}</span>`).join("");
    const o = (u.orbs || []).filter((x) => x.name !== "(empty)").map((x) => `<span class="tag">⚪ ${esc(x.name)}</span>`).join("");
    const dpsTxt = u.dps != null ? ` · ${Number(u.dps).toLocaleString()} dps` : "";
    return `<div class="slot">
      <div class="slotnum">slot ${i + 1}</div>
      <h4 class="${rarityCls(u.rarity)}">${esc(u.form)} <span class="tag">${esc(u.form_label)}</span></h4>
      <div class="role">${esc(u.role || "?")} · ${esc(u.rarity)}</div>
      <div class="sub">${esc(u.name)} · ${esc(u.level)}${dpsTxt}</div>
      <div class="ab">${ab || "-"}</div>
      <div class="sub">${im ? "Immune: " + im : ""}</div>
      <div>${t}${o}</div>
    </div>`;
  }).join("") || `<div class="slot empty"><h4>—</h4><div class="sub">no loadout returned</div></div>`;

  const warnings = (r.warnings || []).map(w => `<div class="warning">⚠ ${esc(w)}</div>`).join("");

  $("#loadout-result").innerHTML = `
    <h3>Loadout for "${esc(r.stage)}"</h3>
    ${warnings ? `<div class="loadout-warnings">${warnings}</div>` : ""}
    <div class="loadout-meta">${chips.join("")}</div>
    <div class="grid10">${slots}</div>
    <div class="reasoning"><b>Why:</b> ${linkifyEnemies(r.reasoning) || "no reasoning given"}</div>`;
}

let presetList = [];
async function refreshPresets() {
  presetList = await api("/api/presets");
  $("#preset-select").innerHTML = `<option value="">— presets (${presetList.length}) —</option>` +
    presetList.map((p) => `<option value="${esc(p.name)}">${esc(p.name)} · ${esc(p.result.stage || "")}</option>`).join("");
}
$("#btn-preset-save").addEventListener("click", async () => {
  if (!window.lastLoadoutResult) { alert("Generate a loadout first, then save it."); return; }
  const name = prompt("Preset name:", window.lastLoadoutResult.stage || "");
  if (!name) return;
  const r = await api("/api/presets/save", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ name, result: window.lastLoadoutResult }) });
  if (r.error) { alert(r.error); return; }
  await refreshPresets();
});
$("#btn-preset-load").addEventListener("click", () => {
  const name = $("#preset-select").value;
  const p = presetList.find((x) => x.name === name);
  if (!p) return;
  renderLoadout(p.result);
});
$("#btn-preset-delete").addEventListener("click", async () => {
  const name = $("#preset-select").value;
  if (!name) return;
  if (!confirm(`Delete preset "${name}"?`)) return;
  await api("/api/presets/delete", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ name }) });
  await refreshPresets();
});

// ---------- enemies ----------
function debounce(fn, ms) { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; }

async function searchEnemies(q) {
  const r = await api("/api/enemies?q=" + encodeURIComponent(q));
  const list = $("#enemy-list");
  if (r.error) { list.innerHTML = `<div class="entry">${esc(r.error)}</div>`; return; }
  if (!r.titles || !r.titles.length) { list.innerHTML = `<div class="entry">No enemies found.</div>`; return; }
  const exact = r.titles.find((t) => t.toLowerCase() === q.toLowerCase());
  if (exact) { list.innerHTML = ""; loadEnemy(exact); return; }
  list.innerHTML = r.titles.map((t) => `<button class="btn enemy-btn" data-title="${esc(t)}">${esc(t)}</button>`).join("");
  list.querySelectorAll(".enemy-btn").forEach((b) => b.addEventListener("click", () => loadEnemy(b.dataset.title)));
  if (r.titles.length === 1) loadEnemy(r.titles[0]);
}

async function loadEnemy(title) {
  $("#enemy-detail").innerHTML = `<div class="meta">Loading ${esc(title)}...</div>`;
  const d = await api("/api/enemies/detail?title=" + encodeURIComponent(title));
  if (d.error) { $("#enemy-detail").innerHTML = `<div class="entry">${esc(d.error)}</div>`; return; }
  const img = d.image ? `<img class="enemy-img" src="https://battlecats.miraheze.org/wiki/Special:FilePath/${encodeURIComponent(d.image)}" alt="">` : "";
  const traits = (d.traits || []).map((t) => `<span class="tag trait-tag">${esc(t)}</span>`).join("");
  const types = (d.types || []).map((t) => `<span class="tag type-tag">${esc(t)}</span>`).join("");
  const isMetal = (d.traits || []).some((t) => /metal/i.test(t));
  const metalNote = isMetal
    ? `<div class="metal-note">⚠ Metal enemy: it only takes damage from <b>Critical Hits</b> (or toxic). Raw DPS, freeze/slow/weaken are useless here — the counters below are your crit units.</div>`
    : "";
  const infoLines = [];
  if (d.info && d.info["first appearance"]) infoLines.push(`First appears: <b>${esc(d.info["first appearance"])}</b>`);
  if (d.info && d.info["money drop"]) infoLines.push(`Money drop: <b>${esc(d.info["money drop"])}</b>`);
  const counters = (d.counters || []).map((c) =>
    `<button class="slot counter-slot" data-id="${c.id}"><h4 class="${rarityCls(c.rarity)}">${esc(c.form)} <span class="tag">${esc(c.rarity)}</span></h4>
     <div class="sub">${esc(c.name)} · Lv${c.level} · targets ${esc((c.traits || []).join(", ") || "none")}</div>
     <div class="ab">${esc((c.abilities || []).slice(0, 3).map((a) => clipLabel(abilityLabel(a))).join(" · ") || "-")}</div></button>`).join("");
  $("#enemy-detail").innerHTML = `
    <div class="entry">${img}
      <h3>${esc(d.title)}</h3>
      <div style="margin:4px 0">${traits}</div>
      ${types ? `<div style="margin:4px 0">Type: ${types}</div>` : ""}
      ${metalNote}
      ${infoLines.length ? `<div class="meta">${infoLines.join("<br>")}</div>` : ""}
      ${d.intro ? `<p>${esc(d.intro)}</p>` : ""}
      ${d.variants && d.variants.length ? `<div class="sub">Variants: ${d.variants.map(esc).join(", ")}</div>` : ""}
    </div>
    <h3 style="margin-top:12px">Your best counters <span class="meta" style="font-size:.7em">(click to open in roster)</span></h3>
    <div class="grid10">${counters || `<div class="entry">No owned cats line up with its traits - your highest-DPS cats would be the fallback.</div>`}</div>`;
}

$("#enemy-detail").addEventListener("click", (e) => {
  const slot = e.target.closest(".counter-slot");
  if (slot) goToCat(slot.dataset.id);
});
$("#loadout-result").addEventListener("click", (e) => {
  const link = e.target.closest(".enemy-link");
  if (link) { e.preventDefault(); goToEnemy(link.dataset.enemy); }
});

$("#enemy-q").addEventListener("input", debounce(() => {
  const q = $("#enemy-q").value.trim();
  if (q.length >= 2) searchEnemies(q); else $("#enemy-list").innerHTML = "";
}, 400));
$("#btn-enemy-clear").addEventListener("click", () => {
  $("#enemy-q").value = ""; $("#enemy-list").innerHTML = ""; $("#enemy-detail").innerHTML = "";
});

// ---------- banners ----------
async function loadBanners() {
  const r = await api("/api/banners");
  if (r.error) { $("#banner-gacha").innerHTML = `<div class="entry">${esc(r.error)}</div>`; return; }
  $("#banner-fetched").textContent = r.fetched ? `Updated ${r.fetched}` : "";
  const gacha = (r.gacha || []).map((e) => {
    const status = e.status === "current"
      ? `<span class="tag" style="color:#7CFC00">● live${e.days_left != null && e.days_left > 0 ? ` · ${e.days_left}d left` : ""}</span>`
      : e.status === "upcoming" ? `<span class="tag">upcoming</span>` : `<span class="tag" style="opacity:.5">past</span>`;
    return `<div class="entry"><b>${esc(e.name)}</b> <span class="meta">${esc(e.start)} ~ ${esc(e.end)}</span> ${status}</div>`;
  }).join("") || `<div class="entry">No gacha events parsed.</div>`;
  $("#banner-gacha").innerHTML = gacha;
  const evs = (r.events || []).filter((e) => e.status !== "past").map((e) =>
    `<div class="entry"><b>${esc(e.name)}</b> <span class="meta">${esc(e.start)} ~ ${esc(e.end)}</span></div>`).join("")
    || `<div class="entry">No live special events.</div>`;
  $("#banner-events").innerHTML = evs;
}

async function refreshBanners() {
  const btn = $("#btn-banner-refresh");
  const done = btn.textContent;
  btn.disabled = true;
  btn.textContent = "Refreshing...";
  $("#banner-fetched").textContent = "Fetching latest schedule...";
  try {
    const r = await api("/api/banners/refresh", { method: "POST" });
    if (r.error) { $("#banner-gacha").innerHTML = `<div class="entry">${esc(r.error)}</div>`; return; }
    await loadBanners();
  } finally {
    btn.disabled = false;
    btn.textContent = done;
  }
}

let bannerPlanSeen = 0;
async function startBannerPlan() {
  $("#btn-banner-plan").disabled = true;
  $("#banner-plan-log").innerHTML = "";
  $("#banner-plan-result").innerHTML = "";
  $("#banner-plan-status").textContent = "";
  bannerPlanSeen = 0;
  const r = await api("/api/banners/advice", { method: "POST" });
  if (r.error) { $("#banner-plan-status").textContent = r.error; $("#btn-banner-plan").disabled = false; return; }
  pollBannerPlan();
}
async function pollBannerPlan() {
  const s = await api("/api/banners/advice/status");
  appendLog($("#banner-plan-log"), s.log, "bannerPlanSeen");
  if (s.running) {
    if (s.status) animateStatus($("#banner-plan-status"), s.status);
    setTimeout(pollBannerPlan, 900);
    return;
  }
  stopStatus();
  $("#btn-banner-plan").disabled = false;
  if (s.error) { $("#banner-plan-status").textContent = "Failed"; return; }
  if (s.result) {
    const r = s.result;
    $("#banner-plan-status").textContent = "Done";
    $("#banner-plan-result").innerHTML = `
      <div class="entry"><h3>🤖 ${esc(r.verdict)}</h3>
      ${r.banner ? `<div class="sub">Banner: <b>${esc(r.banner)}</b></div>` : ""}
      ${r.why ? `<p>${esc(r.why)}</p>` : ""}
      ${r.steps && r.steps.length ? `<div class="sub">Steps:</div><ol style="margin:4px 0 4px 20px">${r.steps.map((x) => `<li>${esc(x)}</li>`).join("")}</ol>` : ""}
      ${r.reasoning ? `<div class="meta">${esc(r.reasoning)}</div>` : ""}
      </div>`;
  }
}
$("#btn-banner-plan").addEventListener("click", startBannerPlan);
$("#btn-banner-refresh").addEventListener("click", refreshBanners);
setInterval(() => { loadBanners(); }, 15 * 60 * 1000);

$("#btn-loadout").addEventListener("click", () => startLoadout(false));
$("#btn-loadout-force").addEventListener("click", () => startLoadout(true));
$("#stage-input").addEventListener("keydown", (e) => { if (e.key === "Enter") startLoadout(false); });
_loadEnemyTitles();

// ---------- updates ----------
let pendingUpdate = null;
async function checkUpdate() {
  const st = $("#update-status");
  st.textContent = "Checking…";
  const res = await api("/api/update/check");
  $("#btn-apply-update").disabled = true;
  pendingUpdate = null;
  if (res.error) {
    st.textContent = "";
    $("#update-box").innerHTML = `<div class="entry err">${esc(res.error)}</div>`;
    return;
  }
  st.textContent = `you're on v${res.current}`;
  if (res.update_available) {
    pendingUpdate = res;
    $("#btn-apply-update").disabled = false;
    const log = (res.changelog || []).map((l) => `<div class="sub">• ${esc(l)}</div>`).join("");
    $("#update-box").innerHTML = `<div class="entry"><b>Update available: v${esc(res.latest)}</b>${log}</div>`;
  } else if (res.downgrade_available) {
    $("#update-box").innerHTML = `<div class="entry">You're running <b>v${esc(res.current)}</b> - newer than the published <b>v${esc(res.latest)}</b>, so there's nothing to update to.</div>`;
  } else {
    $("#update-box").innerHTML = `<div class="entry">You're up to date.</div>`;
  }
}
async function applyUpdate() {
  if (!pendingUpdate) return;
  $("#btn-apply-update").disabled = true;
  $("#btn-check-update").disabled = true;
  $("#update-status").innerHTML = 'Downloading &amp; installing<span class="dots"><span></span><span></span><span></span></span>';
  await api("/api/update/apply", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ zip_url: pendingUpdate.zip_url, version: pendingUpdate.latest, changelog: pendingUpdate.changelog }),
  });
  pollUpdate();
}
async function pollUpdate() {
  const s = await api("/api/update/status");
  if (s.running) { setTimeout(pollUpdate, 1200); return; }
  $("#btn-check-update").disabled = false;
  if (s.error) {
    $("#update-status").textContent = "Failed";
    $("#update-box").innerHTML = `<div class="entry err">Update failed: ${esc(s.error)}</div>`;
    return;
  }
  $("#update-status").textContent = "Done";
  $("#update-box").innerHTML = `<div class="entry"><b>Updated to v${esc(s.result.version)}</b> - click restart to finish.</div>
    <button id="btn-restart-app" class="btn btn-primary">Restart now</button>`;
  $("#btn-restart-app").addEventListener("click", restartApp);
  loadUpdateLog();
}
async function restartApp() {
  $("#update-status").innerHTML = 'Restarting<span class="dots"><span></span><span></span><span></span></span>';
  try { await fetch("/api/restart", { method: "POST" }); } catch (e) {}
}
async function loadUpdateLog() {
  const res = await api("/api/update/log");
  loadUpdateLogAccordion(res.log || []);
}
$("#btn-check-update").addEventListener("click", checkUpdate);
$("#btn-apply-update").addEventListener("click", applyUpdate);

// ---------- seed tracker ----------
function loadSeed() {
  try {
    $("#seed-input").value = localStorage.getItem("bcSeed") || "";
    $("#seed-rolls").value = localStorage.getItem("bcRolls") || "";
    const s = localStorage.getItem("bcSeed");
    $("#seed-saved").textContent = s ? `Seed saved: ${s}` : "";
  } catch (e) {}
}
$("#btn-seed-save").addEventListener("click", () => {
  const v = $("#seed-input").value.trim();
  try { localStorage.setItem("bcSeed", v); } catch (e) {}
  $("#seed-saved").textContent = v ? `Seed saved: ${v}` : "Seed cleared";
});
$("#btn-rolls-save").addEventListener("click", () => {
  try { localStorage.setItem("bcRolls", $("#seed-rolls").value); } catch (e) {}
  $("#seed-saved").textContent = "Rolls saved on this PC";
});
$("#btn-rolls-copy").addEventListener("click", async () => {
  try {
    await navigator.clipboard.writeText($("#seed-rolls").value);
    $("#seed-saved").textContent = "Copied — paste it into bc-seek";
  } catch (e) {
    $("#seed-saved").textContent = "Could not copy automatically";
  }
});

// ---------- seed tracker (automatic) ----------
function rarityShort(r) {
  return { "normal": "Normal", "special": "Special", "uber": "Uber", "uber_fest": "Uber",
           "legend": "Legend", "exclusive": "Exclusive", "supa_fest": "Super",
           "supa": "Super", "rare": "Rare", "found": "Found" }[r] || (r || "?");
}
let seedTrackTimer = null;
function stopSeedTrack() {
  if (seedTrackTimer) { clearInterval(seedTrackTimer); seedTrackTimer = null; }
}
async function startSeedTrack() {
  $("#btn-seed-track").disabled = true;
  stopSeedAdvice();
  stopStatus();
  $("#seed-track-status").textContent = "";
  $("#seed-track-log").innerHTML = "";
  $("#seed-track-result").innerHTML = "";
  $("#seed-advice").innerHTML = "";
  window.seedSeen = 0;
  await api("/api/seed/track", { method: "POST" });
  pollSeedTrack();
}
async function pollSeedTrack() {
  const s = await api("/api/seed/track/status");
  appendLog($("#seed-track-log"), s.log, "seedSeen");
  if (s.running) { setTimeout(pollSeedTrack, 900); return; }
  $("#btn-seed-track").disabled = false;
  if (s.error) {
    $("#seed-track-result").innerHTML = `<h3 style="color:#ff6b6b">Seed tracking failed</h3><p>${esc(s.error)}</p>`;
    return;
  }
  renderSeedTrack(s.result);
}
function seedHlRow(letter, h) {
  const parts = [];
  if (h.next_uber) parts.push(`Uber #${h.next_uber.pos} <b class="seed-r uber">${esc(h.next_uber.name)}</b>`);
  if (h.next_legend) parts.push(`Legend #${h.next_legend.pos} <b class="seed-r legend">${esc(h.next_legend.name)}</b>`);
  if (h.next_exclusive) parts.push(`Exclusive #${h.next_exclusive.pos} <b class="seed-r exclusive">${esc(h.next_exclusive.name)}</b>`);
  if (!parts.length) parts.push("no high-rarity in first 100");
  return `<div class="sub"><b>Track ${letter}:</b> ${parts.join(" · ")}</div>`;
}
function seedTbl(track, label) {
  const rows = track.slice(0, 11).map((e) => `<tr class="${e.next ? "next" : ""}">
    <td>${e.pos}</td>
    <td class="seed-r ${e.rarity || ""}">${esc(rarityShort(e.rarity))}</td>
    <td>${esc(e.name || "?")}${e.guaranteed ? ` <span class="tag tag-good">gar: ${esc(e.guaranteed.name)}</span>` : ""}${e.next ? ` <span class="tag">NEXT</span>` : ""}</td>
  </tr>`).join("");
  const caption = label === "B"
    ? `<div class="seed-col-label"><b>Track B</b> — alternate path<br><span class="hint">what you get if a guaranteed 11-pull switches sides mid-track</span></div>`
    : `<div class="seed-col-label"><b>Track A</b> — your next rolls<br><span class="hint">position 1 is the very next single roll</span></div>`;
  return `${caption}<table class="seed-tbl"><thead><tr><th>#</th><th>Rarity</th><th>Cat</th></tr></thead><tbody>${rows}</tbody></table>`;
}
function renderSeedTrack(r, autoAdvice = true) {
  const res = r.resources || {};
  const chips = [
    `<span class="chip">Seed: <b>${r.seed}</b></span>`,
    `<span class="chip">Rare tickets: <b>${res.rare_tickets ?? 0}</b></span>`,
    `<span class="chip">Platinum: <b>${res.platinum_tickets ?? 0}</b></span>`,
    `<span class="chip">Legend: <b>${res.legend_tickets ?? 0}</b></span>`,
    `<span class="chip">Cat food: <b>${Number(res.cat_food ?? 0).toLocaleString()}</b></span>`,
    `<span class="chip">NP: <b>${Number(res.np ?? 0).toLocaleString()}</b></span>`,
  ];
  const banners = (r.banners || []).map((b) => `
    <div class="entry seed-banner">
      <div class="seed-banner-title">${b.is_current ? "⭐ " : ""}${esc(b.label)} ${b.date ? `<span class="meta">${esc(b.date)}</span>` : ""}</div>
      <div class="seed-banner-flex">
        ${seedHlRow("A", b.highlights.A)}${seedHlRow("B", b.highlights.B)}
      </div>
      <div class="seed-banner-flex">
        <div class="seed-col">${seedTbl(b.tracks.A, "A")}</div>
        <div class="seed-col">${seedTbl(b.tracks.B, "B")}</div>
      </div>
    </div>`).join("");
  const cur = (r.banners || []).find((b) => b.is_current) || (r.banners || [])[0];
  let counters = "";
  if (cur) {
    const hA = (cur.highlights || {}).A || {};
    const pieces = [];
    if (hA.next_uber) pieces.push(`Next Uber in <b>${hA.next_uber.pos} pull${hA.next_uber.pos === 1 ? "" : "s"}</b>`);
    if (hA.next_legend) pieces.push(`Legend in <b>${hA.next_legend.pos} pulls</b>`);
    const guar = (cur.tracks && cur.tracks.A || []).find((e) => e.guaranteed);
    if (guar) pieces.push(`Guaranteed at <b>#${guar.pos}</b>`);
    const rt = Number(res.rare_tickets ?? 0);
    if (rt > 0 && guar && hA.next_uber && guar.pos < hA.next_uber.pos) {
      pieces.push(`⚠️ You have <b>${rt}</b> rare ticket${rt === 1 ? "" : "s"} but an Uber comes sooner via the guaranteed pull - consider saving them`);
    }
    counters = pieces.length ? `<div class="seed-plan-grid">${pieces.map((x) => `<div class="seed-plan-box">${x}</div>`).join("")}</div>` : "";
  }
  $("#seed-track-result").innerHTML = `
    <h3>✅ Seed tracked</h3>
    <p class="hint">Position 1 = your next roll (seed read from the save). First 11 rolls per side shown (one full 11-pull); the AI plan looks at all 100.</p>
    <div class="loadout-meta">${chips.join("")}</div>
    ${counters}
    ${banners}`;
  if (autoAdvice) startSeedAdvice();
}
// AI plan (auto-runs after every track)
let seedAdviceTimer = null;
function stopSeedAdvice() {
  if (seedAdviceTimer) { clearInterval(seedAdviceTimer); seedAdviceTimer = null; }
}
async function loadSeedSaved() {
  try {
    const r = await api("/api/seed/saved");
    if (r && r.track) {
      renderSeedTrack(r.track, false);
      if (r.advice) renderSeedAdvice(r.advice);
    }
  } catch (e) {}
}
async function startSeedAdvice() {
  $("#seed-advice").innerHTML = "";
  animateStatus($("#seed-track-status"), "asking big-pickle");
  const res = await api("/api/seed/advice", { method: "POST" });
  if (res.error) {
    stopStatus();
    $("#seed-track-status").textContent = "";
    $("#seed-advice").innerHTML = `<div class="entry err">${esc(res.error)}</div>`;
    return;
  }
  seedAdviceTimer = setInterval(pollSeedAdvice, 900);
}
async function pollSeedAdvice() {
  const s = await api("/api/seed/advice/status");
  if (s.running) {
    if (s.status) animateStatus($("#seed-track-status"), s.status);
    return;
  }
  stopSeedAdvice();
  stopStatus();
  $("#seed-track-status").textContent = "";
  if (s.error) {
    $("#seed-advice").innerHTML = `<div class="entry err">AI had an issue: ${esc(s.error)}</div>`;
    return;
  }
  const r = s.result;
  if (!r) {
    $("#seed-advice").innerHTML = `<div class="entry err">The AI gave an empty reply - press Track seed + AI plan again.</div>`;
    return;
  }
  renderSeedAdvice(r);
}
function renderSeedAdvice(r) {
  const steps = (r.steps || []).length ? (r.steps || []).map((x) => `<div class="sub">• ${esc(x)}</div>`).join("") : "";
  $("#seed-advice").innerHTML = `
    <h3>🤖 Gacha plan</h3>
    <div class="entry">
      <div class="advice-pick">⭐ ${esc(r.action || "No recommendation")}</div>
      <div class="seed-plan-grid">
        <div class="seed-plan-box"><div class="sub">Next Uber</div><b class="seed-r uber">${esc(r.next_uber || "—")}</b></div>
        <div class="seed-plan-box"><div class="sub">Next Legend</div><b class="seed-r legend">${esc(r.next_legend || "—")}</b></div>
        <div class="seed-plan-box"><div class="sub">Banner</div><b>${esc(r.banner || "—")}</b></div>
      </div>
      ${steps}
      <div class="advice-foot"><span class="advice-note">${esc(r.reasoning || "")}</span></div>
    </div>`;
}
$("#btn-seed-track").addEventListener("click", startSeedTrack);

// ---------- title bar window controls ----------
(function initTitlebar() {
  const isElectron = typeof window.pywebview !== "undefined";
  if (!isElectron) return;
  $("#tb-min")?.addEventListener("click", () => { try { window.pywebview.api.minimize_window(); } catch {} });
  $("#tb-max")?.addEventListener("click", () => { try { window.pywebview.api.toggle_maximize(); } catch {} });
  $("#tb-close")?.addEventListener("click", () => { try { window.pywebview.api.close_window(); } catch {} });
})();

// ---------- context send button ----------
$("#btn-context-send")?.addEventListener("click", () => {
  if ($("#loadout-context").value.trim()) startLoadout(true);
});

// ---------- update log accordion ----------
function loadUpdateLogAccordion(logLines) {
  const el = $("#update-log");
  if (!el) return;
  if (!logLines || !logLines.length) {
    el.innerHTML = `<div class="meta" style="padding:8px">no updates installed yet</div>`;
    return;
  }
  const grouped = [];
  let cur = null;
  for (const line of logLines) {
    const m = line.match(/^(\d+\.\d+\.\d+)\s*[-–]\s*(.*)/);
    if (m) {
      if (cur) grouped.push(cur);
      cur = { version: m[1], text: m[2], full: line };
    } else if (cur) {
      cur.text += " " + line;
      cur.full += " " + line;
    }
  }
  if (cur) grouped.push(cur);
  el.innerHTML = grouped.map((g, i) => `
    <div class="update-log-item${i === 0 ? " open" : ""}">
      <div class="update-log-head" onclick="this.parentElement.classList.toggle('open')">
        <span>v${esc(g.version)}</span>
        <span class="arrow">▶</span>
      </div>
      <div class="update-log-body">${esc(g.full)}</div>
    </div>
  `).join("");
}

// ---------- combo chip → highlight loadout slots ----------
function _comboMembers(comboName) {
  const c = ALL_COMBOS.find(x => x.name === comboName);
  return c ? c.members : "";
}
function _highlightComboSlots(comboName) {
  document.querySelectorAll(".slot.combo-highlight").forEach(s => s.classList.remove("combo-highlight"));
  if (!comboName) return;
  const members = _comboMembers(comboName).toLowerCase();
  document.querySelectorAll("#loadout-result .slot").forEach(s => {
    const name = (s.querySelector(".sub")?.textContent || "").toLowerCase();
    if (name && members.includes(name.split("·")[0].trim().split(" ")[0])) {
      s.classList.add("combo-highlight");
    }
  });
}
window._toggleComboChip = function(el) {
  const wasActive = el.classList.contains("active");
  document.querySelectorAll(".combo-chip").forEach(c => c.classList.remove("active"));
  if (wasActive) { _highlightComboSlots(""); return; }
  el.classList.add("active");
  _highlightComboSlots(el.dataset.combo);
};

// ---------- background ----------
(function makeBg() {
  const bg = document.getElementById("bg");
  if (!bg) return;
  const glyphs = ["🐾", "🐾", "🐱", "⭐", "✨", "🐟"];
  const n = 24;
  for (let i = 0; i < n; i++) {
    const s = document.createElement("span");
    s.className = "float";
    s.textContent = glyphs[i % glyphs.length];
    s.style.left = (Math.random() * 100) + "%";
    const size = 12 + Math.random() * 26;
    s.style.fontSize = size + "px";
    s.style.setProperty("--o", (0.04 + Math.random() * 0.10).toFixed(3));
    s.style.animationDuration = (12 + Math.random() * 18) + "s";
    s.style.animationDelay = (-(Math.random() * 26)) + "s";
    bg.appendChild(s);
  }
})();

// ---------- hub hero greeting ----------
(function heroGreet() {
  const el = $("#hero-title");
  if (!el) return;
  const h = new Date().getHours();
  el.textContent = (h < 5 ? "Late night commander" : h < 12 ? "Good morning commander" : h < 18 ? "Good afternoon commander" : "Good evening commander") + " 👋";
})();

positionTabInd();
refreshState();
