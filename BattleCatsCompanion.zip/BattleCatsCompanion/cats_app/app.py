import json
import os

from flask import Flask, jsonify, request, send_from_directory

import db
import detect
import ai
import evolve
import updater
import seed_track
import presets
import enemies
import banners

APP_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_DIR = os.path.dirname(APP_DIR)

app = Flask(__name__, static_folder="static", static_url_path="/static")

detect_runner = detect.DetectRunner()
loadout_runner = ai.LoadoutRunner()
evolve_advice_runner = ai.AdviceRunner()
update_runner = updater.UpdateRunner()
seed_runner = seed_track.SeedRunner()
seed_advice_runner = ai.SeedAdviceRunner()
banner_plan_runner = ai.BannerPlanRunner()
beat_check_runner = ai.BeatCheckRunner()

ai.cleanup_all_sessions()

# Set by desktop.py once the window exists: brings the running window forward
# when a duplicate launch calls /api/activate.
activate_hook = None


@app.route("/")
def index():
    return send_from_directory("static", "index.html")


@app.route("/api/state")
def api_state():
    st = db.stats()
    st["db_populated"] = st["cats_owned"] > 0
    return jsonify(st)


@app.route("/api/detect", methods=["POST"])
def api_detect():
    started = detect_runner.start()
    return jsonify({"started": started})


@app.route("/api/detect/status")
def api_detect_status():
    return jsonify(detect_runner.snapshot())


@app.route("/api/cats")
def api_cats():
    cats = db.all_cats()
    q = (request.args.get("q") or "").strip().lower()
    rarity = (request.args.get("rarity") or "").strip()
    if q:
        cats = [c for c in cats if q in c["base_name"].lower() or q in c["cur_name"].lower()]
    if rarity:
        cats = [c for c in cats if c["rarity"] == rarity]
    return jsonify(cats)


@app.route("/api/combos")
def api_combos():
    return jsonify(db.all_combos())


@app.route("/api/orbs")
def api_orbs():
    return jsonify({
        "inventory": db.orb_inventory(),
        "equipped": db.cats_with_orbs(),
    })


@app.route("/api/talents")
def api_talents():
    return jsonify(db.cats_with_talents())


@app.route("/api/items")
def api_items():
    raw = db.get_meta("items")
    if not raw:
        return jsonify({"cat_fruit": [], "battle_items": [], "has_data": False})
    try:
        return jsonify({**json.loads(raw), "has_data": True})
    except Exception:
        return jsonify({"cat_fruit": [], "battle_items": [], "has_data": False})


@app.route("/api/update/check")
def api_update_check():
    return jsonify(updater.check_for_update())


@app.route("/api/update/apply", methods=["POST"])
def api_update_apply():
    body = request.get_json(force=True) or {}
    zip_url = body.get("zip_url")
    if not zip_url:
        return jsonify({"error": "no download URL"}), 400
    started = update_runner.start(zip_url, body.get("version") or "0.0.0", body.get("changelog") or [])
    return jsonify({"started": started})


@app.route("/api/update/status")
def api_update_status():
    return jsonify(update_runner.snapshot())


@app.route("/api/update/log")
def api_update_log():
    return jsonify({"log": updater.read_update_log()})


@app.route("/api/activate")
def api_activate():
    """Called by a duplicate launch: bring the running window forward."""
    if activate_hook is None:
        return jsonify({"activated": False}), 409
    try:
        activate_hook()
        return jsonify({"activated": True})
    except Exception as e:
        return jsonify({"activated": False, "error": str(e)}), 500


@app.route("/api/restart", methods=["POST"])
def api_restart():
    try:
        _restart_app()
    except Exception as e:
        return jsonify({"error": str(e)}), 500
    return jsonify({"restarting": True})


def _restart_app():
    """Relaunch this app (e.g. after an update) and exit the current process."""
    import subprocess
    import sys
    import time
    import webview
    exe = os.path.join(sys.prefix, "Scripts", "pythonw.exe")
    if not os.path.exists(exe):
        exe = sys.executable
    subprocess.Popen(
        [exe, os.path.join(APP_DIR, "desktop.py")],
        cwd=APP_DIR,
        env={**os.environ, "BCC_RESTART": "1"},
        creationflags=subprocess.DETACHED_PROCESS | subprocess.CREATE_NEW_PROCESS_GROUP,
        close_fds=True,
    )
    time.sleep(0.3)
    try:
        for w in list(webview.windows):
            w.destroy()
    except Exception:
        pass


@app.route("/api/evolve")
def api_evolve():
    return jsonify(evolve.plan())


@app.route("/api/evolve/advice", methods=["POST"])
def api_evolve_advice():
    if not db.all_cats():
        return jsonify({"error": "no saved data yet - run Detect first"}), 400
    started = evolve_advice_runner.start()
    return jsonify({"started": started})


@app.route("/api/evolve/advice/status")
def api_evolve_advice_status():
    return jsonify(evolve_advice_runner.snapshot())


@app.route("/api/loadout", methods=["POST"])
def api_loadout():
    body = request.get_json(force=True) or {}
    stage = (body.get("stage") or "").strip()
    if not stage:
        return jsonify({"error": "enter a stage name"}), 400
    cats = db.all_cats()
    if not cats:
        return jsonify({"error": "no saved data yet - run Detect first"}), 400
    combos = db.all_combos()
    cannons = json.loads(db.get_meta("cannons") or "null") or ["Standard"]
    banned = _id_list(body.get("banned"))
    required = _id_list(body.get("required"))
    if banned is None or required is None:
        return jsonify({"error": "banned/required must be lists of cat ids"}), 400
    powerups = body.get("powerups")
    if powerups is None:
        powerups = []
    if not isinstance(powerups, list):
        return jsonify({"error": "powerups must be a list"}), 400
    powerups = [str(p).strip() for p in powerups if str(p).strip()]
    context = str(body.get("context") or "").strip()
    force = bool(body.get("force"))
    started = loadout_runner.start(stage, cats, combos, cannons, banned=banned, required=required,
                                   force=force, powerups=powerups, context=context)
    return jsonify({"started": started})


def _id_list(value):
    if value is None:
        return []
    if not isinstance(value, list):
        return None
    return [int(x) for x in value if str(x).lstrip("-").isdigit()]


@app.route("/api/loadout/status")
def api_loadout_status():
    return jsonify(loadout_runner.snapshot())


@app.route("/api/seed/track", methods=["POST"])
def api_seed_track():
    started = seed_runner.start()
    return jsonify({"started": started})


@app.route("/api/seed/track/status")
def api_seed_track_status():
    return jsonify(seed_runner.snapshot())


@app.route("/api/seed/advice", methods=["POST"])
def api_seed_advice():
    started = seed_advice_runner.start()
    return jsonify({"started": started})


@app.route("/api/seed/saved")
def api_seed_saved():
    """Last tracked result + last gacha plan, so the Seed tab can render them
    without re-tracking or re-asking the AI after an app restart."""
    return jsonify({
        "track": seed_track.load_last_result(),
        "advice": ai.load_last_advice(),
    })


@app.route("/api/seed/advice/status")
def api_seed_advice_status():
    return jsonify(seed_advice_runner.snapshot())


@app.route("/api/presets")
def api_presets():
    return jsonify(presets.list_presets())


@app.route("/api/presets/save", methods=["POST"])
def api_presets_save():
    body = request.get_json(force=True) or {}
    name = (body.get("name") or "").strip()
    result = body.get("result")
    if not name or not result:
        return jsonify({"error": "need a preset name and a loadout result"}), 400
    return jsonify(presets.save_preset(name, result))


@app.route("/api/presets/delete", methods=["POST"])
def api_presets_delete():
    body = request.get_json(force=True) or {}
    name = (body.get("name") or "").strip()
    if not name:
        return jsonify({"error": "need a preset name"}), 400
    return jsonify(presets.delete_preset(name))


@app.route("/api/enemies")
def api_enemies_search():
    q = (request.args.get("q") or "").strip()
    try:
        return jsonify({"titles": enemies.search(q)})
    except Exception as e:
        return jsonify({"error": f"wiki lookup failed: {e}"}), 502


@app.route("/api/enemies/all")
def api_enemies_all():
    try:
        return jsonify({"titles": enemies.index()})
    except Exception as e:
        return jsonify({"error": f"wiki lookup failed: {e}"}), 502


@app.route("/api/enemies/detail")
def api_enemies_detail():
    title = (request.args.get("title") or "").strip()
    if not title:
        return jsonify({"error": "need an enemy title"}), 400
    try:
        d = enemies.detail(title)
        d["counters"] = enemies.counters(d["traits"])
        return jsonify(d)
    except Exception as e:
        return jsonify({"error": f"wiki lookup failed: {e}"}), 502


@app.route("/api/banners")
def api_banners():
    try:
        return jsonify(banners.get_schedule())
    except Exception as e:
        return jsonify({"error": f"failed to fetch event schedule: {e}"}), 502


@app.route("/api/banners/refresh", methods=["POST"])
def api_banners_refresh():
    try:
        return jsonify(banners.get_schedule(force=True))
    except Exception as e:
        return jsonify({"error": f"failed to refresh event schedule: {e}"}), 502


@app.route("/api/banners/advice", methods=["POST"])
def api_banners_advice():
    if not db.all_cats():
        return jsonify({"error": "no saved data yet - run Detect first"}), 400
    started = banner_plan_runner.start()
    return jsonify({"started": started})


@app.route("/api/banners/advice/status")
def api_banners_advice_status():
    return jsonify(banner_plan_runner.snapshot())


@app.route("/api/beat", methods=["POST"])
def api_beat():
    body = request.get_json(force=True) or {}
    stage = (body.get("stage") or "").strip()
    if not stage:
        return jsonify({"error": "enter a stage name"}), 400
    if not db.all_cats():
        return jsonify({"error": "no saved data yet - run Detect first"}), 400
    loadout = body.get("loadout")
    started = beat_check_runner.start(stage, loadout=loadout)
    return jsonify({"started": started})


@app.route("/api/beat/status")
def api_beat_status():
    return jsonify(beat_check_runner.snapshot())
