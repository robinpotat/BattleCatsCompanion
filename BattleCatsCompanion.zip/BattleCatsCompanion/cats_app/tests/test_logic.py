"""Logic tests for the pure parts of the app (no network, no AI, no UI).

Covers: db round-trips, stat scaling, evolve planning, banner parsing/caching,
enemy trait/type parsing from cached wiki data, counters, presets, the loadout
rule enforcement (wave / metal / barrier), AI prompt helpers, updater version
keys and the background-runner lifecycle.
"""

import datetime
import json
import os
import time

import pytest

import db
import presets
import banners
import enemies
import ai as ai_module
import seed_track as seed_track_module
import stats as stats_module
import updater
import detect
import evolve

from conftest import SAMPLE_CATS, SAMPLE_COMBOS, SAMPLE_ORB_INV, seed_roster_data


# ---------------------------------------------------------------------------
# db
# ---------------------------------------------------------------------------


def test_db_roundtrip(fresh_db):
    seed_roster_data()
    cats = db.all_cats()
    assert len(cats) == len(SAMPLE_CATS)
    assert cats[0]["id"] == 1
    c23 = next(c for c in cats if c["id"] == 23)
    assert c23["abilities"] == ["Barrier Break 30%"]
    assert db.all_combos()[0]["name"] == "Attack Power (Sm)"
    assert db.orb_inventory()[0]["orb_name"] == "Attack Up (Red)"
    assert db.cats_with_talents()[0]["id"] == 300
    assert db.cats_with_orbs()[0]["id"] == 400
    st = db.stats()
    assert st["cats_owned"] == len(SAMPLE_CATS)
    assert st["catfood"] == 12345 and st["xp"] == 10000 and st["np"] == 99
    assert st["last_detect"] == "2026-08-13 00:00:00"


def test_db_meta(fresh_db):
    assert db.get_meta("nope") is None
    db.set_meta("k", "v")
    assert db.get_meta("k") == "v"
    db.set_meta("k", "v2")
    assert db.get_meta("k") == "v2"


# ---------------------------------------------------------------------------
# stats
# ---------------------------------------------------------------------------


def test_scale_stat():
    s = stats_module.scale_stat
    # scale_stat is a float math port; the display layer rounds, tests use approx
    assert s("Rare", 30, False, False, 100) == pytest.approx(680)
    assert s("Special", 30, False, False, 100) == pytest.approx(680)
    assert s("Special", 20, True, False, 100) == pytest.approx(480)
    assert s("Special", 21, True, False, 100) == pytest.approx(490)
    assert s("Special", 40, False, True, 100) == pytest.approx(780)
    assert s("Super Rare", 61, False, False, 100) == pytest.approx(1290)


def test_attach_stats(fresh_db):
    seed_roster_data()
    os.makedirs(stats_module.CACHE_DIR, exist_ok=True)
    with open(stats_module.CACHE_FILE, "w", encoding="utf-8") as f:
        json.dump({"sampledata": [
            {"number": "002-1", "name": "Cat", "rarity": "Basic", "iscrazed": "",
             "range": 150, "health": 100, "damage": 10, "dps": 5, "speed": 8,
             "kb": 4, "cost": 50, "target": "single", "tba": 1.0,
             "anim": 0.5, "spawn": 0, "form": "Base"},
        ]}, f)
    rows = db.all_cats()
    rows = stats_module.attach_stats(rows)
    cat = next(r for r in rows if r["id"] == 1)
    assert cat["stats"]["dps"] == 34
    assert cat["stats"]["level"] == 30
    assert cat["stats"]["form_name"] == "Cat"


# ---------------------------------------------------------------------------
# presets
# ---------------------------------------------------------------------------


def test_presets_module(fresh_db):
    assert presets.list_presets() == []
    presets.save_preset("Loadout A", {"loadout": []})
    assert presets.list_presets()[0]["name"] == "Loadout A"
    presets.save_preset("loadout a", {"loadout": [1]})
    assert len(presets.list_presets()) == 1
    assert presets.list_presets()[0]["result"] == {"loadout": [1]}
    assert presets.delete_preset("LOADOUT A")["count"] == 0
    assert presets.list_presets() == []


# ---------------------------------------------------------------------------
# banners
# ---------------------------------------------------------------------------


def test_banners_parse_and_cache(monkeypatch):
    today = datetime.datetime.now(banners.JST).date()
    day = datetime.timedelta(days=1)
    raw = {
        "Gacha Schedule": [
            ["Banner A", (today - 2 * day).isoformat(), (today + 5 * day).isoformat()],
            ["Banner B", (today + 1 * day).isoformat(), (today + 10 * day).isoformat()],
            ["Banner C", (today - 10 * day).isoformat(), (today - 3 * day).isoformat()],
        ],
        "Event Schedule": [
            ["Event A", (today - 1 * day).isoformat(), (today + 3 * day).isoformat()],
        ],
    }
    calls = {"n": 0}

    def fake_fetch():
        calls["n"] += 1
        return raw

    monkeypatch.setattr(banners, "_fetch_raw", fake_fetch)

    s = banners.get_schedule(force=True)
    assert s["today"] == today.isoformat()
    g = s["gacha"]
    assert [e["status"] for e in g] == ["current", "upcoming", "past"]
    assert g[0]["name"] == "Banner A" and g[0]["days_left"] == 5
    assert "days_left" not in g[1]
    assert s["events"][0]["name"] == "Event A"

    s2 = banners.get_schedule(force=False)
    assert calls["n"] == 1, "second call must hit the cache"
    assert s2["gacha"][0]["days_left"] == 5
    assert os.path.exists(banners.CACHE_FILE)


def test_banners_switch_day_status(monkeypatch, tmp_path):
    """A banner whose start/end date is TODAY is not 'current' before the
    11:00 JST switch - the old rotation still runs. Regression: the tab was
    showing EPICFEST / Ancient Heroes as live hours before they existed."""
    fixed = datetime.datetime(2026, 8, 14, 3, 0, 0,
                              tzinfo=banners.JST)  # before the 11:00 JST switch
    monkeypatch.setattr(banners, "_now", lambda: fixed)
    monkeypatch.setattr(banners, "CACHE_FILE",
                        os.path.join(str(tmp_path), "banners_switch.json"))
    raw = {
        "Gacha Schedule": [
            ["Starts Today", "2026-08-14", "2026-08-21"],   # live from 11:00 JST today
            ["Ends Today", "2026-08-10", "2026-08-14"],     # still live until 11:00 JST today
            ["Live", "2026-08-10", "2026-08-20"],           # mid-run, current
        ],
        "Event Schedule": [],
    }
    monkeypatch.setattr(banners, "_fetch_raw", lambda: raw)
    g = banners.get_schedule(force=True)["gacha"]
    statuses = {e["name"]: e["status"] for e in g}
    assert statuses == {"Starts Today": "upcoming",
                        "Ends Today": "current",
                        "Live": "current"}


def test_banners_schedule_text(monkeypatch):
    monkeypatch.setattr(banners, "get_schedule", lambda force=False: {
        "today": "2026-08-13",
        "gacha": [{"name": "B1", "start": "2026-08-10", "end": "2026-08-20",
                   "status": "current", "days_left": 7}],
        "events": [],
    })
    t = banners.schedule_text()
    assert "TODAY: 2026-08-13" in t
    assert "B1" in t and "7 days left" in t


def test_pick_banners_switch_day():
    """Regression: godfat's 'selected' flag can lag long past the 11:00 JST
    switch (it still flagged a banner that ended at 11:00 JST late into the
    evening). pick_banners must move to the new rotation based on the clock,
    not just godfat's flag."""
    st = seed_track_module
    today = "2026-08-14"
    events = [
        {"id": "2026-07-24_1063", "selected": False, "label": "Platinum", "date": "2026-07-24 ~ 2030-01-01"},
        {"id": "2026-08-07_1075", "selected": True,  "label": "Old Summer", "date": "2026-08-07 ~ 2026-08-14"},
        {"id": "2026-08-12_1015", "selected": False, "label": "Old Sidmi",  "date": "2026-08-12 ~ 2026-08-14"},
        {"id": "2026-08-14_1062", "selected": False, "label": "Lunos",      "date": "2026-08-14 ~ 2026-08-21"},
        {"id": "2026-08-14_1075", "selected": False, "label": "New Summer", "date": "2026-08-14 ~ 2026-08-21"},
        {"id": "2026-08-14_946",  "selected": False, "label": "Hanasaka",   "date": "2026-08-14 ~ 2026-08-17"},
        {"id": "2026-08-17_1059", "selected": False, "label": "Vornado",    "date": "2026-08-17 ~ 2026-08-19"},
    ]

    def at(hour):
        return datetime.datetime(2026, 8, 14, hour, 0, 0, tzinfo=st.JST)

    # Before the 11:00 JST switch: old rotation still live, new not picked.
    pre = st.pick_banners(events, None, today=today, now=at(3))
    assert pre == ["2026-07-24_1063", "2026-08-07_1075", "2026-08-12_1015"]
    cur_id, cur_label = st.resolve_current(events, pre)
    assert cur_label == "Old Summer"

    # After the switch, even with godfat's flag still on the old banner,
    # the app must track the new rotation (this is the reported bug).
    post = st.pick_banners(events, None, today=today, now=at(21))
    assert post == ["2026-07-24_1063", "2026-08-14_1062", "2026-08-14_1075", "2026-08-14_946"]
    cur_id, cur_label = st.resolve_current(events, post)
    assert cur_label == "Lunos"


# ---------------------------------------------------------------------------
# enemies (parsing / cache / counters - no network)
# ---------------------------------------------------------------------------


def test_trait_for():
    tr = enemies._trait_for
    assert tr("Category:Black Enemies") == "Black"
    assert tr("Category:Red Enemies") == "Red"
    assert tr("Dark") == "Black"
    assert tr("White") == "Traitless"
    assert tr("Typeless") == "Traitless"
    assert tr("Starred Alien") == "Alien"
    assert tr("unstarred alien") == "Alien"
    assert tr("Eva Angel") == "Angel"
    assert tr("Soul") == "Witch"
    assert tr("") == ""
    assert tr("Bogus") == ""


def test_collect_traits():
    text = ("'''Samurai Doggy''' is a [[:Category:Red Enemies|Red]]/"
            "[[:Category:Black Enemies|Black]] enemy.\n"
            "{{Enemy Info\n|name = Samurai Doggy\n}}")
    cats = ["Category:Red Enemies", "Category:Black Enemies"]
    assert enemies._collect_traits(text, cats) == ["Red", "Black"]


def test_collect_types():
    text = ("'''Angelic Beast Rajakong''' is a [[:Category:Behemoth Enemies|Behemoth]] "
            "enemy.\n{{Enemy Info\n|name = x\n}}")
    assert enemies._collect_types(text, ["Category:Behemoth Enemies"]) == ["Behemoth"]
    assert enemies._collect_types("'''x''' plain enemy.\n{{Enemy Info\n|name = x\n}}", []) == []


def test_detail_from_cached_page(fresh_db):
    os.makedirs(enemies.CACHE_DIR, exist_ok=True)
    wikitext = ("'''Samurai Doggy''' is a [[:Category:Red Enemies|Red]]/"
                "[[:Category:Black Enemies|Black]] enemy that appears in stages.\n\n"
                "{{Enemy Info\n|name = Samurai Doggy\n|image = E 001.png\n"
                "|first appearance = '''EoC''': Moon\n|money drop = 200¢\n}}")
    with open(os.path.join(enemies.CACHE_DIR, "page_Samurai_Doggy.json"),
              "w", encoding="utf-8") as f:
        json.dump({"title": "Samurai Doggy", "wikitext": wikitext,
                   "categories": ["Category:Red Enemies", "Category:Black Enemies"]}, f)
    d = enemies.detail("Samurai Doggy")
    assert d["title"] == "Samurai Doggy"
    assert d["traits"] == ["Red", "Black"]
    assert d["types"] == []
    assert d["info"]["name"] == "Samurai Doggy"
    assert "appears in stages" in d["intro"]


def test_enemies_index_and_search_from_cache(fresh_db):
    os.makedirs(enemies.CACHE_DIR, exist_ok=True)
    with open(os.path.join(enemies.CACHE_DIR, "index.json"), "w", encoding="utf-8") as f:
        json.dump(["Samurai Doggy", "Mega Baa Baa", "Baa Baa"], f)
    assert enemies.index() == ["Samurai Doggy", "Mega Baa Baa", "Baa Baa"]
    assert enemies.search("baa") == ["Mega Baa Baa", "Baa Baa"]
    assert enemies.search("")[:3] == ["Samurai Doggy", "Mega Baa Baa", "Baa Baa"]


def test_counters_metal(fresh_db):
    seed_roster_data()
    res = enemies.counters(["Metal"])
    assert {c["id"] for c in res} == {60, 78}


def test_counters_trait(fresh_db):
    seed_roster_data()
    res = enemies.counters(["Red"])
    assert [c["id"] for c in res] == [100]


def test_counters_traitless_top_dps(fresh_db):
    seed_roster_data()
    res = enemies.counters(["Traitless"])
    assert res and res[0]["id"] == 100


# ---------------------------------------------------------------------------
# evolve
# ---------------------------------------------------------------------------


def test_evolve_plan(fresh_db):
    seed_roster_data()
    p = evolve.plan()
    assert {e["id"] for e in p["ready"]} == {100, 500}
    assert {e["id"] for e in p["almost"]} == {600}
    assert {"name": "Epic Catfruit", "need": 2} in p["missing_fruit"]
    assert p["xp"] == 10000
    ready100 = next(e for e in p["ready"] if e["id"] == 100)
    assert ready100["form"] == 2 and ready100["form_label"] == "True"
    assert ready100["items"][0]["have"] == 5


def test_evolve_plan_text(fresh_db):
    seed_roster_data()
    assert "EVOLUTIONS YOU CAN AFFORD RIGHT NOW (2):" in evolve.plan_text()
    assert "TOTAL CATFRUIT/BEHEMOTH MISSING" in evolve.plan_detail_text()


def test_evolve_farm_urls(fresh_db):
    seed_roster_data()
    assert evolve._farm_url("Cat Fruit") == "https://battlecats.miraheze.org/wiki/Cat_fruit"
    assert evolve._farm_url("Epic Catfruit") == "https://battlecats.miraheze.org/wiki/Epic_Catfruit_Seed"
    assert evolve._farm_url("Purple Catfruit") == "https://battlecats.miraheze.org/wiki/Purple_Catfruit_Seed"
    assert evolve._farm_url("Behemoth Stone") == "https://battlecats.miraheze.org/wiki/Behemoth_Stone"
    p = evolve.plan()
    needy = next(e for e in p["almost"] if e["id"] == 600)
    assert needy["missing"] == [{
        "name": "Epic Catfruit", "have": 1, "count": 3,
        "url": "https://battlecats.miraheze.org/wiki/Epic_Catfruit_Seed",
    }]
    ready = next(e for e in p["ready"] if e["id"] == 100)
    assert ready["missing"] == []


def _evolve_cat(cid, base, level_base, need_level, need_xp, items):
    return {
        "id": cid,
        "base_name": base,
        "rarity": "Rare",
        "rarity_id": 200,
        "level_base": level_base,
        "level_plus": 0,
        "cur_name": base,
        "cur_label": "Evolved",
        "cur": 1,
        "unl": 1,
        "mf": 2,
        "true_avail": 1,
        "traits": [],
        "abilities": [],
        "immunities": [],
        "talents_spent": [],
        "orbs": [],
        "stats": {"dps": 60},
        "evolve": {"forms": {"2": {
            "level": need_level, "xp": need_xp, "items": items,
        }}},
    }


def test_evolve_almost_priority(fresh_db):
    seed_roster_data()
    only_item = _evolve_cat(700, "Item Blocked Cat", 30, 30, 5000,
                            [{"id": 3, "name": "Purple Catfruit", "count": 2}])
    level_blocked = _evolve_cat(800, "Level Blocked Cat", 25, 30, 5000, [])
    db.store_cats(SAMPLE_CATS + [only_item, level_blocked])
    p = evolve.plan()
    almost = [e["id"] for e in p["almost"]]
    assert 700 in almost and 800 in almost and 600 in almost
    assert almost.index(700) < almost.index(800), "only-items-missing cats must come first"
    assert almost.index(700) < almost.index(600)
    item700 = next(e for e in p["almost"] if e["id"] == 700)
    assert item700["ready_except_items"] is True
    assert item700["missing"] == [{
        "name": "Purple Catfruit", "have": 0, "count": 2,
        "url": "https://battlecats.miraheze.org/wiki/Purple_Catfruit_Seed",
    }]
    lb = next(e for e in p["almost"] if e["id"] == 800)
    assert lb["ready_except_items"] is False


# ---------------------------------------------------------------------------
# loadout rule enforcement (wave / metal / barrier)
# ---------------------------------------------------------------------------


def _slots(*ids):
    return [ai_module._slot_from(next(c for c in SAMPLE_CATS if c["id"] == i), "ai-pick")
            for i in ids]


def test_enforce_wave_blocker():
    cats = list(SAMPLE_CATS)
    loadout = [_slots(1)[0],
               ai_module._slot_from(next(c for c in cats if c["id"] == 200), "auto-fill")]
    ai_module.enforce_loadout_rules(loadout, cats, "The stage has wave attacks (wave shield).")
    roles = [u["role"] for u in loadout]
    assert "wave-blocker" in roles
    wb = next(u for u in loadout if u["role"] == "wave-blocker")
    assert wb["id"] == 33


def test_enforce_crit():
    cats = list(SAMPLE_CATS)
    loadout = [ai_module._slot_from(next(c for c in cats if c["id"] == 1), "ai-pick"),
               ai_module._slot_from(next(c for c in cats if c["id"] == 200), "auto-fill")]
    ai_module.enforce_loadout_rules(loadout, cats, "Metal doge appears.")
    crit = next(u for u in loadout if u["role"] == "crit-bringer")
    assert crit["id"] == 60


def test_enforce_barrier_breaker():
    cats = list(SAMPLE_CATS)
    loadout = [ai_module._slot_from(next(c for c in cats if c["id"] == 1), "ai-pick"),
               ai_module._slot_from(next(c for c in cats if c["id"] == 200), "auto-fill")]
    ai_module.enforce_loadout_rules(loadout, cats,
                                    "bring a Barrier Breaker to deal with UltraBaaBaa")
    bb = next(u for u in loadout if u["role"] == "barrier-breaker")
    assert bb["id"] == 23


def test_enforce_barrier_no_false_positive():
    cats = list(SAMPLE_CATS)
    loadout = [ai_module._slot_from(next(c for c in cats if c["id"] == 1), "ai-pick"),
               ai_module._slot_from(next(c for c in cats if c["id"] == 200), "auto-fill")]
    before = [u["role"] for u in loadout]
    ai_module.enforce_loadout_rules(loadout, cats,
                                    "the name is a reference to the great barrier reef")
    assert [u["role"] for u in loadout] == before


def test_enforce_keeps_existing_units():
    cats = list(SAMPLE_CATS)
    wb = ai_module._slot_from(next(c for c in cats if c["id"] == 33), "ai-pick")
    crit = ai_module._slot_from(next(c for c in cats if c["id"] == 60), "ai-pick")
    bb = ai_module._slot_from(next(c for c in cats if c["id"] == 23), "ai-pick")
    loadout = [wb, crit, bb]
    ai_module.enforce_loadout_rules(loadout, cats,
                                    "wave shield + metal + barrier break stage")
    assert [u["role"] for u in loadout] == ["ai-pick", "ai-pick", "ai-pick"]
    assert {u["id"] for u in loadout} == {33, 60, 23}


def test_enforce_drops_last_slot_when_no_autofill():
    cats = list(SAMPLE_CATS)
    loadout = [ai_module._slot_from(next(c for c in cats if c["id"] == 1), "ai-pick"),
               ai_module._slot_from(next(c for c in cats if c["id"] == 200), "ai-pick")]
    ai_module.enforce_loadout_rules(loadout, cats, "barrier shield enemy")
    assert loadout[-1]["role"] == "barrier-breaker"


# ---------------------------------------------------------------------------
# ai helpers
# ---------------------------------------------------------------------------


def test_read_model():
    assert ai_module._read_model() == "opencode/big-pickle"
    assert ai_module.MODEL == "opencode/big-pickle"


def test_loadout_fingerprint():
    cats = SAMPLE_CATS[:2]
    a = ai_module._loadout_fingerprint("Earth", cats, ["Standard"], "")
    b = ai_module._loadout_fingerprint("Earth", cats, ["Standard"], "")
    assert a == b
    assert a != ai_module._loadout_fingerprint("Earth", cats, ["Iron Wall"], "")
    assert a == ai_module._loadout_fingerprint("eartH", cats, ["Standard"], "")
    assert a != ai_module._loadout_fingerprint("Moon", cats, ["Standard"], "")


def test_build_items_text():
    items = {"battle_items": [{"name": "Rich Cat", "count": 2}],
             "cat_fruit": [{"name": "Cat Fruit", "count": 3}]}
    t = ai_module.build_items_text(items)
    assert "Rich Cat x2" in t and "Cat Fruit x3" in t


def test_prompt_no_ability_hallucination():
    """Regression: the AI used to claim every Alien / 'Cyclone' enemy has a
    barrier, which made it invent barriers for Super Cosmic Cyclone. Both the
    loadout and beat-check prompts must forbid inferring special abilities
    from a trait or name alone."""
    guard = "stage.txt"
    assert guard in ai_module.KNOWLEDGE
    assert "not every Alien has a barrier" in ai_module.KNOWLEDGE
    assert "not every enemy with \"Cyclone\" in its name has one" in ai_module.KNOWLEDGE
    beat = ai_module.build_beat_message()
    assert "not every Alien has a barrier" in beat
    assert "not every enemy with \"Cyclone\" in its name has one" in beat
    assert "LOOK UP its description" in ai_module.KNOWLEDGE
    assert "a Starry Alien" in ai_module.KNOWLEDGE and "usually has a barrier" in ai_module.KNOWLEDGE
    assert "a Starry Alien" in beat and "usually does" in beat


def test_parse_cannons_only_finished():
    """Regression: a cannon still under development (unlock_flag 1=effect,
    2=foundation) used to be listed as owned. Only a fully built cannon
    (unlock_flag 3=style) is usable in battle."""
    import update_cats as uc_module
    ss = {
        "ototo_cannon": {
            0: {"unlock_flag": 3, "levels": {}},
            1: {"unlock_flag": 1, "levels": {}},   # Slow Beam - still building
            2: {"unlock_flag": 3, "levels": {}},   # Iron Wall - finished
            3: {"unlock_flag": 2, "levels": {}},   # Thunderbolt - still building
        }
    }
    assert uc_module.parse_cannons(ss) == ["Standard", "Iron Wall"]


def test_lookup_stage_matched(monkeypatch):
    monkeypatch.setattr(ai_module, "STAGE_CACHE_FILE", ai_module.STAGE_CACHE_FILE + ".unit")
    monkeypatch.setattr(ai_module, "_title_candidates",
                        lambda s: [(5000, "Earth (Cats of the Cosmos)")])
    monkeypatch.setattr(ai_module, "search_wiki", lambda s: [])
    monkeypatch.setattr(ai_module, "fulltext_search", lambda s: [])
    monkeypatch.setattr(ai_module, "search_stages_mg", lambda s: [])
    calls = {"n": 0}

    def fetcher(base, title):
        calls["n"] += 1
        return "'''Earth''' is a stage. bring a Barrier Breaker."

    monkeypatch.setattr(ai_module, "fetch_wikitext", fetcher)
    d = ai_module.lookup_stage("Earth CoC")
    assert d["title"] == "Earth (Cats of the Cosmos)"
    assert d["source"] == "fandom"
    assert "barrier breaker" in d["text"].lower()

    d2 = ai_module.lookup_stage("Earth CoC")
    assert calls["n"] == 1, "second lookup must come from the cache"
    assert d2 == d


def test_lookup_stage_missing(monkeypatch):
    monkeypatch.setattr(ai_module, "STAGE_CACHE_FILE", ai_module.STAGE_CACHE_FILE + ".unit")
    monkeypatch.setattr(ai_module, "_title_candidates", lambda s: [])
    monkeypatch.setattr(ai_module, "search_wiki", lambda s: [])
    monkeypatch.setattr(ai_module, "fulltext_search", lambda s: [])
    monkeypatch.setattr(ai_module, "search_stages_mg", lambda s: [])
    d = ai_module.lookup_stage("Totally Fake Stage 98765")
    assert d["source"] == "none"
    assert d["text"] == "" and d["url"] == ""


def test_lookup_stage_merges_same_name_pages(monkeypatch):
    """Two wiki pages matching the query (the two Journey to Talent trials)
    must both end up in the stage text so the AI knows which is which."""
    monkeypatch.setattr(ai_module, "STAGE_CACHE_FILE", ai_module.STAGE_CACHE_FILE + ".unit")
    monkeypatch.setattr(ai_module, "_title_candidates",
                        lambda s: [(100, "Journey to Talent (Valkyrie Cat's Trial)"),
                                   (100, "Journey to Talent (Bahamut Cat's Trial)")])
    monkeypatch.setattr(ai_module, "search_wiki", lambda s: [])
    monkeypatch.setattr(ai_module, "fulltext_search", lambda s: [])
    monkeypatch.setattr(ai_module, "search_stages_mg", lambda s: [])

    def fetcher(base, title):
        if "Valkyrie" in title:
            return "'''Journey to Talent''' is a trial for Valkyrie Cat."
        return "'''Journey to Talent''' is a trial for Awakened Bahamut."

    monkeypatch.setattr(ai_module, "fetch_wikitext", fetcher)
    d = ai_module.lookup_stage("Journey to Talent")
    assert d["source"] == "fandom"
    assert "PAGE 1" in d["text"] and "PAGE 2" in d["text"]
    assert "Valkyrie" in d["text"] and "Bahamut" in d["text"]


def test_lookup_stage_mygamatoto_fallback(monkeypatch):
    """When both wikis have nothing, the mygamatoto/onestoppress dataset is
    the next source, with the enemy lineup included for the AI."""
    monkeypatch.setattr(ai_module, "STAGE_CACHE_FILE", ai_module.STAGE_CACHE_FILE + ".unit")
    monkeypatch.setattr(ai_module, "_title_candidates", lambda s: [])
    monkeypatch.setattr(ai_module, "search_wiki", lambda s: [])
    monkeypatch.setattr(ai_module, "fulltext_search", lambda s: [])
    monkeypatch.setattr(ai_module, "fetch_wikitext", lambda base, t: (_ for _ in ()).throw(KeyError("x")))

    def fake_mg(name):
        return [{"stage": "Brand New Stage", "category": "Regular event stages",
                 "chapter": "RS_999",
                 "enemies": [{"enemy_name": "Doge", "enemy_multiplier": 200},
                             {"enemy_name": "UltraBaaBaa"}]}]

    monkeypatch.setattr(ai_module, "search_stages_mg", fake_mg)
    d = ai_module.lookup_stage("Brand New Stage")
    assert d["source"] == "mygamatoto"
    assert d["url"] == ai_module.MG_SEARCH_URL
    assert "UltraBaaBaa" in d["text"] and "Doge x200" in d["text"]
    assert "MYGAMATOTO" in d["text"].upper()


# ---------------------------------------------------------------------------
# mygamatoto / onestoppress stage data
# ---------------------------------------------------------------------------


def _write_mg_cache(stages):
    os.makedirs(ai_module.CACHE_DIR, exist_ok=True)
    with open(ai_module.MG_STAGES_FILE, "w", encoding="utf-8") as f:
        json.dump({"fetched_at": int(time.time()), "sampledata": stages}, f)


MG_SAMPLE_STAGES = [
    {"stageid": 1, "category": "Regular event stages", "chapter": "RS_394",
     "stage": "Journey to Talent", "enemies": [{"enemy_name": "Mistress Celeboodle"},
                                               {"enemy_name": "Holy Valkyrie Cat"}]},
    {"stageid": 2, "category": "Regular event stages", "chapter": "RS_395",
     "stage": "Journey to Talent", "enemies": [{"enemy_name": "Awakened Bahumut Cat"}]},
    {"stageid": 3, "category": "Story Mode", "chapter": "CotC 1",
     "stage": "Earth", "enemies": []},
    {"stageid": 4, "category": "Story Mode", "chapter": "CotC 2",
     "stage": "Earth", "enemies": []},
    {"stageid": 5, "category": "Cats of the Cosmos", "chapter": "CotC 1",
     "stage": "Earthshaker", "enemies": []},
]


def test_mg_load_uses_cache(monkeypatch):
    monkeypatch.setattr(ai_module, "_MG_MEMO", None)
    _write_mg_cache(MG_SAMPLE_STAGES)
    calls = {"n": 0}

    def fetcher():
        calls["n"] += 1
        return {"sampledata": []}

    monkeypatch.setattr(ai_module.SESSION, "get", lambda *a, **k: fetcher())
    data = ai_module._mg_load()
    assert len(data) == len(MG_SAMPLE_STAGES)
    assert calls["n"] == 0, "fresh cache must not hit the network"


def test_search_stages_mg(monkeypatch):
    monkeypatch.setattr(ai_module, "_MG_MEMO", None)
    _write_mg_cache(MG_SAMPLE_STAGES)
    hits = ai_module.search_stages_mg("Journey to Talent")
    assert len(hits) == 2
    assert {h["chapter"] for h in hits} == {"RS_394", "RS_395"}
    hits = ai_module.search_stages_mg("journey to talent")
    assert len(hits) == 2, "case-insensitive"
    hits = ai_module.search_stages_mg("Earth")
    assert hits[0]["stage"] == "Earth", "exact matches rank first"
    assert {h["stage"] for h in hits} >= {"Earth", "Earthshaker"}  # substring mirror of mygamatoto
    assert ai_module.search_stages_mg("") == []
    assert ai_module.search_stages_mg("zzz no match") == []


def test_mg_duplicate_note_only_for_event_dups(monkeypatch):
    monkeypatch.setattr(ai_module, "_MG_MEMO", None)
    _write_mg_cache(MG_SAMPLE_STAGES)
    note = ai_module._mg_duplicate_note("Journey to Talent")
    assert "2 DIFFERENT stages" in note
    assert "RS_394" in note and "RS_395" in note and "Valkyrie" in note
    note = ai_module._mg_duplicate_note("Earth")
    assert note == "", "chapter duplicates across Story Mode must stay quiet"
    note = ai_module._mg_duplicate_note("Earthshaker")
    assert note == ""


def test_mg_stage_text():
    t = ai_module._mg_stage_text("X", MG_SAMPLE_STAGES[:2])
    assert "MYGAMATOTO" in t.upper()
    assert "Journey to Talent" in t
    assert "Mistress Celeboodle" in t


# ---------------------------------------------------------------------------
# tower handling
# ---------------------------------------------------------------------------


def test_tower_name():
    tn = ai_module._tower_name
    assert tn("Sweet Jesus Tower Floor 3") == "sweet jesus"
    assert tn("sweet jesus tower") == "sweet jesus"
    assert tn("Heavenly Tower Floor 2") == "heavenly"
    assert tn("Infernal Tower 9") == "infernal"
    assert tn("tower floor 2") == "heavenly"
    assert tn("Earth") is None
    assert tn("Journey to Talent") is None


def test_tower_title_ok():
    ok = ai_module._tower_title_ok
    assert ok("Sweet_Jesus_Tower/Floor_3", "sweet jesus")
    assert ok("Heavenly_Tower/Floor_2", "heavenly")
    assert ok("Heavenly_Tower", "heavenly")
    assert not ok("Infernal_Tower/Floor_9", "sweet jesus")
    assert not ok("Heavenly_Tower/Floor_2", "infernal")
    assert not ok("Infernal_Tower/Floor_9", "heavenly")


def test_tower_floor_candidates():
    tc = ai_module._tower_floor_candidates
    assert tc("Sweet Jesus Tower Floor 3") == [(20000, "Sweet_Jesus_Tower/Floor_3")]
    assert tc("heavenly tower 2") == [(20000, "Heavenly_Tower/Floor_2")]
    assert tc("tower floor 2") == [(20000, "Heavenly_Tower/Floor_2")]
    assert tc("Earth") == []


def test_lookup_stage_rejects_wrong_tower(monkeypatch):
    """'Sweet Jesus Tower Floor 3' must NOT resolve to Infernal Tower even
    though fulltext search would suggest it."""
    monkeypatch.setattr(ai_module, "STAGE_CACHE_FILE", ai_module.STAGE_CACHE_FILE + ".unit")
    monkeypatch.setattr(ai_module, "_title_candidates",
                        lambda s: [(9000, "Sweet_Jesus_Tower_Floor_3")])
    monkeypatch.setattr(ai_module, "search_wiki",
                        lambda s: [("fandom", "Infernal Tower/Floor 9")])
    monkeypatch.setattr(ai_module, "fulltext_search", lambda s: [])
    monkeypatch.setattr(ai_module, "fetch_wikitext",
                        lambda base, t: (_ for _ in ()).throw(KeyError("no page")))
    monkeypatch.setattr(ai_module, "search_stages_mg", lambda s: [])
    d = ai_module.lookup_stage("Sweet Jesus Tower Floor 3")
    assert d["source"] == "none"
    assert "infernal" not in d["title"].lower()


def test_strip_wikitext():
    assert ai_module.strip_wikitext("<ref>x</ref>hello <b>world</b>\n\n\n\n!") == "hello world\n\n!"
    assert ai_module.strip_wikitext("x" * 20000).endswith("[truncated]")


# ---------------------------------------------------------------------------
# updater
# ---------------------------------------------------------------------------


def test_ver_key_ordering():
    assert updater._ver_key("0.11.29") < updater._ver_key("0.12.0")
    assert updater._ver_key("1.2.3") > updater._ver_key("1.2.2")
    assert updater._ver_key("abc") == (0,)


def test_local_version_format():
    assert isinstance(updater.local_version(), str) and updater.local_version()


# ---------------------------------------------------------------------------
# background runner lifecycle (stubbed _run/_pipeline, no side effects)
# ---------------------------------------------------------------------------


def _wait_done(runner, timeout=5.0):
    deadline = time.time() + timeout
    while time.time() < deadline:
        if runner.snapshot()["done"]:
            return True
        time.sleep(0.01)
    return False


def test_loadout_runner_lifecycle(monkeypatch):
    r = ai_module.LoadoutRunner()

    def fake_run(stage, *a, **k):
        with r.lock:
            r.result = {"stage": stage}
            r.done = True
            r.running = False

    monkeypatch.setattr(r, "_run", fake_run)
    assert r.start("Earth", [], [], ["Standard"]) is True
    assert _wait_done(r)
    assert r.snapshot()["result"]["stage"] == "Earth"


def test_detect_runner_lifecycle(monkeypatch):
    r = detect.DetectRunner()

    def fake_pipeline():
        return {"cats": 11, "combos": 1, "orbs": 2, "changes": [],
                "rarity": {"Rare": 5}, "catfood": 1, "xp": 1, "np": 1}

    monkeypatch.setattr(r, "_pipeline", fake_pipeline)
    assert r.start() is True
    assert _wait_done(r)
    assert r.snapshot()["result"]["cats"] == 11


def test_cleanup_session(monkeypatch, tmp_path):
    """_cleanup_last_session deletes the most recent session + messages + parts
    for the app's directory, and cleanup_all_sessions deletes them all."""
    import sqlite3 as _sqlite3
    fake_db = tmp_path / "opencode.db"
    conn = _sqlite3.connect(str(fake_db))
    conn.executescript("""
        CREATE TABLE session (id TEXT, directory TEXT, time_created INTEGER);
        CREATE TABLE message (id TEXT, session_id TEXT);
        CREATE TABLE part (id TEXT, message_id TEXT);
    """)
    conn.execute("INSERT INTO session VALUES ('s1', 'C:/other/path', 100)")
    conn.execute("INSERT INTO session VALUES ('s2', 'C:/other/path', 200)")
    app_dir_fwd = ai_module.APP_DIR.replace("\\", "/")
    conn.execute("INSERT INTO session VALUES ('s3', ?, 300)", (app_dir_fwd,))
    conn.execute("INSERT INTO session VALUES ('s4', ?, 400)", (app_dir_fwd,))
    conn.execute("INSERT INTO message VALUES ('m1', 's3')")
    conn.execute("INSERT INTO message VALUES ('m2', 's3')")
    conn.execute("INSERT INTO message VALUES ('m3', 's4')")
    conn.execute("INSERT INTO part VALUES ('p1', 'm1')")
    conn.execute("INSERT INTO part VALUES ('p2', 'm2')")
    conn.execute("INSERT INTO part VALUES ('p3', 'm3')")
    conn.commit()
    conn.close()

    monkeypatch.setattr(ai_module, "sqlite3", _sqlite3)
    monkeypatch.setattr(ai_module.os.path, "expanduser",
                        lambda p: str(tmp_path) if "~" in p else p)
    monkeypatch.setattr(ai_module.os.path, "exists", lambda p: True)

    # Manually point the functions at our temp DB
    import types

    def _make_cleanup(fn_name):
        orig = getattr(ai_module, fn_name)
        def patched():
            db_path = str(fake_db)
            dir_pattern = ai_module.APP_DIR.replace("\\", "/")
            conn2 = _sqlite3.connect(db_path, timeout=5)
            try:
                conn2.execute("PRAGMA journal_mode=WAL")
                if fn_name == "_cleanup_last_session":
                    row = conn2.execute(
                        "SELECT id FROM session WHERE directory = ? "
                        "ORDER BY time_created DESC LIMIT 1",
                        (dir_pattern,),
                    ).fetchone()
                    if not row:
                        return
                    sid = row[0]
                    msg_ids = [r[0] for r in conn2.execute(
                        "SELECT id FROM message WHERE session_id = ?", (sid,)
                    ).fetchall()]
                    if msg_ids:
                        ph = ",".join(["?"] * len(msg_ids))
                        conn2.execute(f"DELETE FROM part WHERE message_id IN ({ph})", msg_ids)
                        conn2.execute("DELETE FROM message WHERE session_id = ?", (sid,))
                    conn2.execute("DELETE FROM session WHERE id = ?", (sid,))
                else:
                    sids = [r[0] for r in conn2.execute(
                        "SELECT id FROM session WHERE directory = ?",
                        (dir_pattern,),
                    ).fetchall()]
                    if not sids:
                        return
                    ph = ",".join(["?"] * len(sids))
                    conn2.execute(
                        f"DELETE FROM part WHERE message_id IN "
                        f"(SELECT id FROM message WHERE session_id IN ({ph}))", sids)
                    conn2.execute(f"DELETE FROM message WHERE session_id IN ({ph})", sids)
                    conn2.execute(f"DELETE FROM session WHERE id IN ({ph})", sids)
                conn2.commit()
            finally:
                conn2.close()
        return patched

    # Test _cleanup_last_session: removes s4 (most recent app session)
    ai_module._cleanup_last_session = _make_cleanup("_cleanup_last_session")
    ai_module._cleanup_last_session()
    conn2 = _sqlite3.connect(str(fake_db))
    remaining = [r[0] for r in conn2.execute("SELECT id FROM session ORDER BY id").fetchall()]
    conn2.close()
    assert remaining == ["s1", "s2", "s3"], f"expected [s1,s2,s3], got {remaining}"

    # Test cleanup_all_sessions: removes s3 too
    ai_module.cleanup_all_sessions = _make_cleanup("cleanup_all_sessions")
    ai_module.cleanup_all_sessions()
    conn2 = _sqlite3.connect(str(fake_db))
    remaining = [r[0] for r in conn2.execute("SELECT id FROM session ORDER BY id").fetchall()]
    msg_count = conn2.execute("SELECT COUNT(*) FROM message").fetchone()[0]
    part_count = conn2.execute("SELECT COUNT(*) FROM part").fetchone()[0]
    conn2.close()
    assert remaining == ["s1", "s2"], f"expected [s1,s2], got {remaining}"
    assert msg_count == 0
    assert part_count == 0


def test_clean_reasoning_strips_unselected_cats():
    """Reasoning mentioning cats not in the loadout should be cleaned."""
    cats_by_id = {
        1: {"base_name": "Valkyrie Cat", "rarity": "Special"},
        2: {"base_name": "Bahamut Cat", "rarity": "Special"},
        3: {"base_name": "Crazed Cat", "rarity": "Super Rare"},
    }
    loadout = [{"id": 1, "name": "Valkyrie Cat"}, {"id": 2, "name": "Bahamut Cat"}]
    text = "Valkyrie Cat and Bahamut Cat will handle the Red enemies. Bring Crazed Cat for extra DPS."
    result = ai_module._clean_reasoning(text, loadout, cats_by_id)
    assert "Crazed Cat" not in result
    assert "Valkyrie Cat" in result
    assert "Bahamut Cat" in result


def test_clean_reasoning_preserves_substring_of_loadout_cat():
    """A shorter cat name should NOT be stripped from inside a longer loadout cat name."""
    cats_by_id = {
        10: {"base_name": "Crazed Fish Cat", "rarity": "Super Rare"},
        11: {"base_name": "Fish Cat", "rarity": "Normal"},
    }
    loadout = [{"id": 10, "name": "Crazed Fish Cat"}]
    text = "Crazed Fish Cat is your best anti-Red option here."
    result = ai_module._clean_reasoning(text, loadout, cats_by_id)
    assert "Crazed Fish Cat" in result


def test_clean_reasoning_keeps_loadout_cats():
    """Cats in the loadout should NOT be stripped."""
    cats_by_id = {
        10: {"base_name": "Sanada Yukimura", "rarity": "Uber Rare"},
    }
    loadout = [{"id": 10, "name": "Sanada Yukimura"}]
    text = "Sanada Yukimura is a great anti-Black rusher for this stage."
    result = ai_module._clean_reasoning(text, loadout, cats_by_id)
    assert "Sanada Yukimura" in result


def test_validate_loadout_warns_wrong_trait():
    """Loadout targeting a trait not in the stage should produce warnings."""
    stage_text = "Enemies: Doge (Red), Those Guys (Red), Ginger Snache (Red)"
    cats_by_id = {
        1: {"id": 1, "base_name": "Wheel Cat", "rarity": "Rare",
            "abilities": ["Strong vs Metal"], "talents_spent": []},
        2: {"id": 2, "base_name": "Gross Cat", "rarity": "Normal",
            "abilities": [], "talents_spent": []},
    }
    loadout = [
        {"id": 1, "name": "Wheel Cat"},
        {"id": 2, "name": "Gross Cat"},
    ]
    warnings = ai_module._validate_loadout(loadout, stage_text, cats_by_id)
    assert any("Metal" in w for w in warnings)


def test_validate_loadout_no_warnings_correct_trait():
    """Loadout matching stage traits should produce no warnings."""
    stage_text = "Enemies: Metal Doge (Metal), Metal Hippoe (Metal)"
    cats_by_id = {
        1: {"id": 1, "base_name": "Catasaurus", "rarity": "Rare",
            "abilities": ["Crit 8%"], "talents_spent": []},
    }
    loadout = [{"id": 1, "name": "Catasaurus"}]
    warnings = ai_module._validate_loadout(loadout, stage_text, cats_by_id)
    assert warnings == []


def test_validate_loadout_no_warnings_empty_stage():
    """No warnings when stage text is empty (can't determine traits)."""
    cats_by_id = {
        1: {"id": 1, "base_name": "Wheel Cat", "rarity": "Rare",
            "abilities": ["Strong vs Metal"], "talents_spent": []},
    }
    loadout = [{"id": 1, "name": "Wheel Cat"}]
    warnings = ai_module._validate_loadout(loadout, "", cats_by_id)
    assert warnings == []


def test_extract_cost_restriction():
    """Parse minimum cost from various wiki formats."""
    assert ai_module._extract_cost_restriction("Cost: Only cats above 1200 cost") == 1200
    assert ai_module._extract_cost_restriction("Only cats above 1500 cost allowed") == 1500
    assert ai_module._extract_cost_restriction("Minimum cost: 800") == 800
    assert ai_module._extract_cost_restriction("Restrictions: 1200+ cost only") == 1200
    assert ai_module._extract_cost_restriction("No restrictions here") is None
    assert ai_module._extract_cost_restriction("") is None


def test_validate_loadout_warns_cost_violation():
    """Cats below the minimum cost should produce warnings."""
    stage_text = "Restrictions: 1200+ cost only"
    cats_by_id = {
        1: {"id": 1, "base_name": "Macho Cat", "rarity": "Normal",
            "abilities": [], "talents_spent": [],
            "stats": {"cost": 150}},
        2: {"id": 2, "base_name": "Titan Cat", "rarity": "Normal",
            "abilities": [], "talents_spent": [],
            "stats": {"cost": 1500}},
    }
    loadout = [
        {"id": 1, "name": "Macho Cat"},
        {"id": 2, "name": "Titan Cat"},
    ]
    warnings = ai_module._validate_loadout(loadout, stage_text, cats_by_id)
    assert any("Macho Cat" in w and "1200" in w for w in warnings)
    assert not any("Titan Cat" in w for w in warnings)
