"""Test bot for the Battle Cats Companion app.

SAFETY: this whole suite runs against an isolated temp workspace. The real
data.db, cache/, tmp/, model.txt, update_log.txt and the detect output files
(cats_report.json / cats_all.txt / cats_changes.txt) are never read *for
writes* - we repoint every path at a temp dir before running, and a session
finalizer verifies none of the real files changed.

Close the desktop app before running the tests so a concurrently running
instance cannot touch the real files (that would trip the safety check).
"""

import os
import sys
import time

import pytest

APP_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PROJECT_DIR = os.path.dirname(APP_DIR)
for _p in (APP_DIR, PROJECT_DIR):
    if _p not in sys.path:
        sys.path.insert(0, _p)

import db as db_module
import app as app_module
import ai as ai_module
import banners as banners_module
import enemies as enemies_module
import presets as presets_module
import seed_track as seed_track_module
import stats as stats_module


# ---------------------------------------------------------------------------
# Isolation: point every writable path at a temp workspace
# ---------------------------------------------------------------------------

PROTECTED = [
    os.path.join(APP_DIR, "data.db"),
    os.path.join(APP_DIR, "cache", "banners_v3.json"),
    os.path.join(APP_DIR, "tmp"),
    os.path.join(APP_DIR, "cache", "enemies"),
    os.path.join(PROJECT_DIR, "cats_report.json"),
    os.path.join(PROJECT_DIR, "cats_all.txt"),
    os.path.join(PROJECT_DIR, "cats_changes.txt"),
]


def _snapshot_files():
    """{(abs path): (mtime_ns, size)} for every existing protected file."""
    snap = {}
    for base in PROTECTED:
        if os.path.isdir(base):
            for root, _dirs, files in os.walk(base):
                for fn in files:
                    p = os.path.join(root, fn)
                    try:
                        st = os.stat(p)
                    except OSError:
                        continue
                    snap[p] = (st.st_mtime_ns, st.st_size)
        elif os.path.exists(base):
            try:
                st = os.stat(base)
            except OSError:
                continue
            snap[base] = (st.st_mtime_ns, st.st_size)
    return snap


@pytest.fixture(scope="session", autouse=True)
def isolated_env(tmp_path_factory):
    work = tmp_path_factory.mktemp("bcc_test_env")

    db_module.DB_PATH = str(work / "data.db")
    presets_module.PRESETS_FILE = str(work / "tmp" / "presets.json")
    banners_module.CACHE_FILE = str(work / "cache" / "banners_v3.json")
    enemies_module.CACHE_DIR = str(work / "cache" / "enemies")
    enemies_module.INDEX_FILE = os.path.join(enemies_module.CACHE_DIR, "index.json")
    ai_module.TMP_DIR = str(work / "tmp")
    ai_module.CACHE_DIR = os.path.join(ai_module.TMP_DIR, "loadout_cache")
    ai_module.STAGE_CACHE_FILE = os.path.join(ai_module.CACHE_DIR, "stages.json")
    ai_module.RESULT_CACHE_FILE = os.path.join(ai_module.CACHE_DIR, "results.json")
    ai_module.MG_STAGES_FILE = os.path.join(ai_module.CACHE_DIR, "mg_stages.json")
    ai_module._MG_MEMO = None
    seed_track_module.TMP_DIR = str(work / "tmp")
    seed_track_module.RESULT_PATH = os.path.join(seed_track_module.TMP_DIR, "seed_track_result.json")
    stats_module.CACHE_DIR = str(work / "cache")
    stats_module.CACHE_FILE = os.path.join(stats_module.CACHE_DIR, "allcats.json")

    for _d in (work / "tmp", work / "cache", work / "cache" / "enemies"):
        _d.mkdir(parents=True, exist_ok=True)

    db_module.init_db()

    before = _snapshot_files()
    yield work

    after = _snapshot_files()
    changed = {p for p in after if p not in before}
    changed |= {p for p in before if after.get(p) != before[p]}
    assert not changed, (
        "SAFETY CHECK FAILED - the tests touched protected real files: "
        + ", ".join(sorted(changed))
    )


# ---------------------------------------------------------------------------
# CLI options (live tiers)
# ---------------------------------------------------------------------------


def pytest_addoption(parser):
    parser.addoption("--live", action="store_true",
                     help="run live tests against the wiki / banner APIs")
    parser.addoption("--live-ai", action="store_true",
                     help="run live tests that call the real AI model (slow, costs tokens)")


def pytest_collection_modifyitems(config, items):
    live = config.getoption("--live")
    live_ai = config.getoption("--live-ai")
    for item in items:
        if "live_ai" in item.keywords and not live_ai:
            item.add_marker(pytest.mark.skip(reason="needs --live-ai"))
        elif "live" in item.keywords and not (live or live_ai):
            item.add_marker(pytest.mark.skip(reason="needs --live"))


# ---------------------------------------------------------------------------
# Sample roster (synthetic - never the user's real data)
# ---------------------------------------------------------------------------


def _cat(cid, base, rarity, rarity_id, level_base=30, level_plus=0, cur=0, unl=0,
         mf=0, cur_name=None, cur_label="Base", traits=None, abilities=None,
         immunities=None, talents=None, orbs=None, stats=None, evolve=None):
    return {
        "id": cid,
        "base_name": base,
        "rarity": rarity,
        "rarity_id": rarity_id,
        "level_base": level_base,
        "level_plus": level_plus,
        "cur_name": cur_name or base,
        "cur_label": cur_label,
        "cur": cur,
        "unl": unl,
        "mf": mf,
        "true_avail": 1,
        "traits": traits or [],
        "abilities": abilities or [],
        "immunities": immunities or [],
        "talents_spent": talents or [],
        "orbs": orbs or [],
        "stats": stats,
        "evolve": evolve or {},
    }


SAMPLE_CATS = [
    _cat(1, "Cat", "Basic", 0, stats={"dps": 10, "health": 100, "forms": {}}),
    _cat(23, "Skirt Cat", "Special", 100, abilities=["Barrier Break 30%"],
         stats={"dps": 20}),
    _cat(33, "Octopus Cat", "Super Rare", 400, immunities=["Wave Blocker"],
         abilities=["Wave Blocker"], stats={"dps": 30}),
    _cat(60, "Catasaurus", "Rare", 200, abilities=["Crit 10%"],
         stats={"dps": 40}),
    _cat(78, "Space Cat", "Rare", 200, abilities=["Barrier Break 50%", "Crit 8%"],
         stats={"dps": 35}),
    _cat(100, "Bahamut Cat", "Special", 100, cur=1, mf=2, cur_label="Evolved",
         traits=["Red"], abilities=["Massive Damage vs Red"],
         evolve={"forms": {"2": {"level": 30, "xp": 5000,
                                 "items": [{"id": 1, "name": "Cat Fruit", "count": 1}]}}},
         stats={"dps": 900}),
    _cat(200, "Tank Cat", "Basic", 0, traits=["Floating"], stats={"dps": 50}),
    _cat(300, "Talented Cat", "Rare", 200,
         talents=[{"name": "Attack Up", "level": 2, "max": 10}], stats={"dps": 60}),
    _cat(400, "Orb Cat", "Super Rare", 400,
         orbs=[{"name": "Attack Up", "slot": 0}, {"name": "(empty)", "slot": 1}],
         stats={"dps": 70}),
    _cat(500, "Evolver Cat", "Rare", 200, level_base=25, cur=1, unl=1, mf=2,
         cur_label="Evolved",
         evolve={"forms": {"2": {"level": 20, "xp": 2000, "items": []}}},
         stats={"dps": 80}),
    _cat(600, "Needy Cat", "Rare", 200, level_base=25, cur=1, mf=2,
         cur_label="Evolved",
         evolve={"forms": {"2": {"level": 30, "xp": 99999,
                                 "items": [{"id": 2, "name": "Epic Catfruit", "count": 3}]}}},
         stats={"dps": 90}),
]

SAMPLE_COMBOS = [{
    "name": "Attack Power (Sm)",
    "effect": "Unit Attack UP",
    "value": "Small",
    "members_str": "1,2",
    "note": "",
}]

SAMPLE_ORB_INV = {"Attack Up (Red)": 3, "Cost Down": 1}

SAMPLE_ITEMS = {
    "cat_fruit": [
        {"id": 1, "name": "Cat Fruit", "count": 5},
        {"id": 2, "name": "Epic Catfruit", "count": 1},
    ],
    "battle_items": [
        {"name": "Treasure Radar", "count": 2},
        {"name": "Rich Cat", "count": 1},
    ],
}


def _wipe_db():
    conn = db_module.connect()
    for t in ("cats", "combos", "orb_inventory", "meta"):
        conn.execute(f"DELETE FROM {t}")
    conn.commit()
    conn.close()


def seed_meta():
    db_module.set_meta("items", __import__("json").dumps(SAMPLE_ITEMS, ensure_ascii=False))
    db_module.set_meta("cannons", __import__("json").dumps(["Standard", "Iron Wall"]))
    db_module.set_meta("xp", "10000")
    db_module.set_meta("catfood", "12345")
    db_module.set_meta("np", "99")
    db_module.set_meta("last_detect", "2026-08-13 00:00:00")
    db_module.set_meta("game_version", "15.5.0")
    db_module.set_meta("data_version", "150500")
    db_module.set_meta("save_version", "150500")


def seed_roster_data():
    _wipe_db()
    db_module.store_cats(SAMPLE_CATS)
    db_module.store_combos(SAMPLE_COMBOS)
    db_module.store_orb_inventory(SAMPLE_ORB_INV)
    seed_meta()


@pytest.fixture
def fresh_db():
    _wipe_db()
    return db_module


@pytest.fixture
def client():
    _wipe_db()
    app_module.app.config["TESTING"] = True
    with app_module.app.test_client() as c:
        yield c


@pytest.fixture
def seeded_client(client):
    seed_roster_data()
    return client


# ---------------------------------------------------------------------------
# Helpers to stub background runners (never touch the real AI / game / network)
# ---------------------------------------------------------------------------


def stub_runner(monkeypatch, runner, result=None, started=True):
    """Patch a runner's start/snapshot so endpoints work without background work."""
    calls = {}

    def fake_start(*args, **kwargs):
        calls["__args__"] = args
        calls.update(kwargs)
        return started

    monkeypatch.setattr(runner, "start", fake_start)
    monkeypatch.setattr(runner, "snapshot", lambda: {
        "running": False, "done": True, "error": None,
        "status": "", "log": [], "result": result,
    })
    return calls


@pytest.fixture
def stub_detect(monkeypatch):
    return stub_runner(monkeypatch, app_module.detect_runner,
                       {"cats": 11, "combos": 1, "orbs": 2, "changes": [],
                        "rarity": {"Rare": 5}, "catfood": 12345, "xp": 10000, "np": 99})


@pytest.fixture
def stub_loadout(monkeypatch):
    result = {
        "stage": "Test Stage", "stage_title": "Test Stage", "stage_url": "",
        "stage_source": "none", "cannons_owned": ["Standard"],
        "loadout": [{"id": 1, "name": "Cat", "form": "Cat", "form_label": "Base",
                     "role": "ai-pick", "rarity": "Basic", "level": "Lv30+0",
                     "dps": 10, "abilities": [], "immunities": [], "talents": [], "orbs": []}],
        "combos_used": [], "cannon": "Standard", "powerups": [],
        "reasoning": "test", "cached": False,
    }
    return stub_runner(monkeypatch, app_module.loadout_runner, result)


@pytest.fixture
def stub_advice(monkeypatch):
    result = {"advice": "Evolve Bahamut Cat first.", "steps": []}
    return stub_runner(monkeypatch, app_module.evolve_advice_runner, result)


@pytest.fixture
def stub_seed(monkeypatch):
    return stub_runner(monkeypatch, app_module.seed_runner,
                       {"tracked": True, "gacha": "test"})


@pytest.fixture
def stub_seed_advice(monkeypatch):
    return stub_runner(monkeypatch, app_module.seed_advice_runner, {"advice": "roll A"})


@pytest.fixture
def stub_banner_plan(monkeypatch):
    return stub_runner(monkeypatch, app_module.banner_plan_runner, {"advice": "pull here"})


@pytest.fixture
def stub_beat(monkeypatch):
    return stub_runner(monkeypatch, app_module.beat_check_runner,
                       {"beatable": True, "reason": "test"})


@pytest.fixture
def stub_update(monkeypatch):
    return stub_runner(monkeypatch, app_module.update_runner,
                       {"version": "0.99.0", "files": 3})
