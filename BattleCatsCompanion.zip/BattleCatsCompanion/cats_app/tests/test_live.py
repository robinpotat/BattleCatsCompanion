"""Live-network / real-AI tests. Skipped unless opted in:

    run_tests.bat                 -> mock/skip everything (default, safe)
    run_tests.bat -m live         -> also hit real fandom/miraheze/banner APIs
    run_tests.bat -m "live or live_ai" -> also run real AI generations

Everything still writes only into the isolated pytest temp workspace; the real
data.db, cache/, tmp/ and BattleCatsCompanion files are never touched.
"""

import json
import os

import pytest

import banners
import enemies
import ai as ai_module
import app as app_module

pytestmark = pytest.mark.live


# ---------------------------------------------------------------------------
# fandom wiki
# ---------------------------------------------------------------------------


def test_wiki_search_and_title():
    results = ai_module._title_candidates("Earth")
    assert results, "no wiki results for 'Earth' - network problem?"
    for score, title in results:
        assert isinstance(score, (int, float)) and title


def test_lookup_stage_live():
    d = ai_module.lookup_stage("Earth (Cats of the Cosmos)")
    assert d["source"] in ("fandom", "miraheze")
    assert d["title"]
    low = d["text"].lower()
    assert "barrier" in low, "expected barrier text on this stage page"


def test_lookup_stage_live_typical_solo():
    d = ai_module.lookup_stage("The Great Abyss")
    assert d["source"] in ("fandom", "miraheze", "none")
    assert isinstance(d["text"], str)


def test_lookup_stage_live_journey_to_talent_both_trials():
    """'Journey to Talent' must surface BOTH trials (Valkyrie + Bahamut) so the
    AI never assumes a single stage."""
    d = ai_module.lookup_stage("Journey to Talent")
    assert d["source"] in ("fandom", "miraheze")
    low = d["text"].lower()
    assert "valkyrie" in low and "bahamut" in low


def test_lookup_stage_live_heavenly_tower_floor():
    d = ai_module.lookup_stage("Heavenly Tower Floor 2")
    assert d["title"].lower().startswith("heavenly tower"), d["title"]
    assert "infernal" not in d["title"].lower()


def test_lookup_stage_live_sweet_jesus_not_misresolved():
    """Fandom has no 'Sweet Jesus Tower' pages, so this must never resolve to
    Infernal Tower - fall through to none/mygamatoto instead."""
    d = ai_module.lookup_stage("Sweet Jesus Tower Floor 3")
    assert d["source"] in ("none", "mygamatoto"), d["source"]
    assert "infernal" not in d["title"].lower()
    assert "infernal" not in d["text"].lower()[:200]


def test_search_stages_mg_live():
    hits = ai_module.search_stages_mg("Journey to Talent")
    assert len(hits) == 2
    assert {h["chapter"] for h in hits} == {"RS_394", "RS_395"}
    enemies = {e.get("enemy_name") for h in hits for e in (h.get("enemies") or [])}
    assert "Holy Valkyrie Cat" in enemies and "Awakened Bahumut Cat" in enemies


# ---------------------------------------------------------------------------
# banner schedule (real onestoppress API)
# ---------------------------------------------------------------------------


def test_banners_schedule_live():
    s = banners.get_schedule(force=True)
    assert s["today"]
    assert isinstance(s["gacha"], list)
    assert isinstance(s["events"], list)
    assert all(e["name"] for e in s["gacha"])
    t = banners.schedule_text()
    assert "TODAY:" in t


# ---------------------------------------------------------------------------
# enemy pages (real fandom)
# ---------------------------------------------------------------------------


def test_enemy_index_live():
    idx = enemies.index(force=True)
    assert len(idx) > 100
    assert "Samurai Doggy" in idx


def test_enemy_detail_live():
    d = enemies.detail("Samurai Doggy")
    assert d["title"] == "Samurai Doggy"
    assert "Red" in d["traits"]
    assert "Black" in d["traits"]
    assert d["info"]["name"] == "Samurai Doggy"
    assert d["intro"]


# ---------------------------------------------------------------------------
# app endpoints backed by real AI (opt-in - this writes nothing to the save)
# ---------------------------------------------------------------------------


def _wait_runner(runner, timeout=300):
    import time
    deadline = time.time() + timeout
    while time.time() < deadline:
        if runner.snapshot()["done"]:
            return True
        time.sleep(1)
    return False


def _write_synthetic_seed_track():
    """A minimal but structurally valid godfat-style track so SeedAdviceRunner
    (which refuses to run without a saved track) can build its prompt."""
    import seed_track

    def ent(pos, rarity, name, next_=False):
        return {"pos": pos, "rarity": rarity, "name": name, "next": next_,
                "guaranteed": None, "id": None}

    def banner(bid, label, is_current):
        return {
            "id": bid, "label": label, "date": "2026-08-01 ~ 2026-08-20",
            "is_current": is_current,
            "tracks": {
                "A": [ent(1, "rare", "Rover Cat", True), ent(2, "rare", "Apple Cat"),
                      ent(3, "super", "Sniper the Heavy"), ent(4, "uber", "Bora")],
                "B": [ent(1, "rare", "Brave Cat"), ent(2, "uber", "Kamukura"),
                      ent(3, "legend", "Lumina")],
            },
            "highlights": {
                "A": {"next_uber": {"pos": 4, "name": "Bora", "rarity": "uber"},
                      "next_legend": None, "next_exclusive": None},
                "B": {"next_uber": {"pos": 2, "name": "Kamukura", "rarity": "uber"},
                      "next_legend": {"pos": 3, "name": "Lumina", "rarity": "legend"},
                      "next_exclusive": None},
            },
        }

    result = {
        "seed": 1234567890,
        "date": "2026-08-13 12:00:00",
        "resources": {"rare_tickets": 2, "platinum_tickets": 0, "legend_tickets": 0,
                      "normal_tickets": 5, "cat_food": 1500},
        "current_banner": "summer",
        "current_label": "Summer Banner",
        "upcoming": [{"label": "Lone Moon Lunos"}],
        "banners": [banner("summer", "Summer Banner", True),
                    banner("plat", "Platinum Capsule", False)],
    }
    os.makedirs(seed_track.TMP_DIR, exist_ok=True)
    with open(seed_track.RESULT_PATH, "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False)


@pytest.mark.live_ai
def test_loadout_live(seeded_client):
    r = seeded_client.post("/api/loadout", json={
        "stage": "Earth (Cats of the Cosmos)",
        "banned": [],
        "required": [60],
        "powerups": ["Rich Cat"],
        "force": True,
    })
    assert r.status_code == 200 and r.get_json()["started"] is True
    assert _wait_runner(app_module.loadout_runner), "AI loadout timed out"
    d = app_module.loadout_runner.snapshot()["result"]
    assert d["loadout"], "AI returned no loadout"
    assert len(d["loadout"]) >= 3
    names = [u["name"] for u in d["loadout"]]
    assert "Catasaurus" in names, "required cat was not honoured"


@pytest.mark.live_ai
def test_advice_live(seeded_client):
    assert seeded_client.post("/api/evolve/advice").get_json()["started"] is True
    assert _wait_runner(app_module.evolve_advice_runner), "AI advice timed out"
    result = app_module.evolve_advice_runner.snapshot()["result"]
    assert result and result["pick"], "AI evolve advice produced no pick"


@pytest.mark.live_ai
def test_banner_plan_live(seeded_client):
    assert seeded_client.post("/api/banners/advice").get_json()["started"] is True
    assert _wait_runner(app_module.banner_plan_runner), "AI banner plan timed out"
    result = app_module.banner_plan_runner.snapshot()["result"]
    assert result and result["verdict"], "AI banner plan produced no verdict"


@pytest.mark.live_ai
def test_beat_live(seeded_client):
    r = seeded_client.post("/api/beat", json={"stage": "Earth (Cats of the Cosmos)"})
    assert r.get_json()["started"] is True
    assert _wait_runner(app_module.beat_check_runner), "AI beat check timed out"
    result = app_module.beat_check_runner.snapshot()["result"]
    assert result and result["verdict"], "AI beat check produced no verdict"


@pytest.mark.live_ai
def test_seed_advice_live(seeded_client):
    _write_synthetic_seed_track()
    assert seeded_client.post("/api/seed/advice").get_json()["started"] is True
    assert _wait_runner(app_module.seed_advice_runner), "AI seed advice timed out"
    result = app_module.seed_advice_runner.snapshot()["result"]
    assert result and result["action"], "AI seed advice produced no action"
