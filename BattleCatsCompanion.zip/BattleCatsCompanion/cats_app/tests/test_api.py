"""API endpoint tests - every Flask route, happy path + error cases.

All background runners (AI, detect, update, seed) are stubbed here so nothing
touches the real model, game save, or network. Live-network endpoints (enemies,
banners) are patched here and tested for real in test_live.py.
"""

import pytest

import app as app_module
import banners
import enemies

API_RULES = {r.rule for r in app_module.app.url_map.iter_rules() if r.rule.startswith("/api/")}


def test_every_api_route_is_tested():
    """Completeness guard: adding a route without a test must fail CI."""
    tested = {
        "/api/state", "/api/detect", "/api/detect/status",
        "/api/cats", "/api/combos", "/api/orbs", "/api/talents", "/api/items",
        "/api/update/check", "/api/update/apply", "/api/update/status", "/api/update/log",
        "/api/activate", "/api/restart",
        "/api/evolve", "/api/evolve/advice", "/api/evolve/advice/status",
        "/api/loadout", "/api/loadout/status",
        "/api/seed/track", "/api/seed/track/status", "/api/seed/advice",
        "/api/seed/saved", "/api/seed/advice/status",
        "/api/presets", "/api/presets/save", "/api/presets/delete",
        "/api/enemies", "/api/enemies/all", "/api/enemies/detail",
        "/api/banners", "/api/banners/refresh", "/api/banners/advice",
        "/api/banners/advice/status",
        "/api/beat", "/api/beat/status",
        "/api/win/minimize", "/api/win/maximize", "/api/win/close",
    }
    assert API_RULES == tested, (
        "route/test mismatch - add tests for: " + str(API_RULES - tested)
    )


def test_index_serves_frontend(client):
    r = client.get("/")
    assert r.status_code == 200
    body = r.get_data(as_text=True)
    for tab in ("Detect", "Roster", "Combos", "Talents", "Items", "Evolve",
                "Loadout", "Enemies", "Banners", "Seed"):
        assert tab in body


def test_frontend_links_are_real_api_routes(client):
    import os
    from conftest import APP_DIR
    static_dir = os.path.join(APP_DIR, "static")
    referenced = set()
    for fn in ("index.html", "app.js"):
        with open(os.path.join(static_dir, fn), encoding="utf-8") as f:
            text = f.read()
        for rule in API_RULES:
            if rule.replace("/api/", "/api/") in text:
                referenced.add(rule)
    untested_by_ui = API_RULES - referenced
    assert not (untested_by_ui - {"/api/restart", "/api/activate"}), (
        "frontend does not call: " + str(untested_by_ui)
    )


# ---------------------------------------------------------------------------
# State
# ---------------------------------------------------------------------------


def test_state_empty_db(client):
    r = client.get("/api/state")
    assert r.status_code == 200
    d = r.get_json()
    assert d["db_populated"] is False
    assert d["cats_owned"] == 0


def test_state_seeded(seeded_client):
    d = seeded_client.get("/api/state").get_json()
    assert d["db_populated"] is True
    assert d["cats_owned"] == len(__import__("conftest").SAMPLE_CATS)
    assert d["catfood"] == 12345


# ---------------------------------------------------------------------------
# Detect
# ---------------------------------------------------------------------------


def test_detect_start_and_status(client, stub_detect):
    r = client.post("/api/detect")
    assert r.status_code == 200
    assert r.get_json()["started"] is True
    d = client.get("/api/detect/status").get_json()
    assert d["done"] is True
    assert d["result"]["cats"] == 11


def test_detect_start_returns_false_when_busy(client, monkeypatch):
    monkeypatch.setattr(app_module.detect_runner, "start", lambda: False)
    assert client.post("/api/detect").get_json()["started"] is False


# ---------------------------------------------------------------------------
# Cats / combos / orbs / talents / items
# ---------------------------------------------------------------------------


def test_cats_list_and_filters(seeded_client):
    cats = seeded_client.get("/api/cats").get_json()
    assert len(cats) == len(__import__("conftest").SAMPLE_CATS)
    assert cats[0]["base_name"]

    by_q = seeded_client.get("/api/cats?q=tank").get_json()
    assert len(by_q) == 1 and by_q[0]["base_name"] == "Tank Cat"

    by_rarity = seeded_client.get("/api/cats?rarity=Special").get_json()
    assert all(c["rarity"] == "Special" for c in by_rarity)
    assert {c["id"] for c in by_rarity} == {23, 100}


def test_combos(seeded_client):
    combos = seeded_client.get("/api/combos").get_json()
    assert len(combos) == 1
    assert combos[0]["name"] == "Attack Power (Sm)"


def test_orbs(seeded_client):
    d = seeded_client.get("/api/orbs").get_json()
    assert d["inventory"] == [{"orb_name": "Attack Up (Red)", "count": 3},
                              {"orb_name": "Cost Down", "count": 1}]
    assert len(d["equipped"]) == 1 and d["equipped"][0]["id"] == 400


def test_talents(seeded_client):
    d = seeded_client.get("/api/talents").get_json()
    assert [c["id"] for c in d] == [300]


def test_items_empty(client):
    d = client.get("/api/items").get_json()
    assert d == {"cat_fruit": [], "battle_items": [], "has_data": False}


def test_items_seeded(seeded_client):
    d = seeded_client.get("/api/items").get_json()
    assert d["has_data"] is True
    assert {i["name"] for i in d["cat_fruit"]} == {"Cat Fruit", "Epic Catfruit"}


# ---------------------------------------------------------------------------
# Update
# ---------------------------------------------------------------------------


def test_update_check(client, monkeypatch):
    monkeypatch.setattr(app_module.updater, "check_for_update",
                        lambda: {"current": "0.11.29", "latest": "0.12.0",
                                 "update_available": True, "changelog": ["x"], "zip_url": "u"})
    d = client.get("/api/update/check").get_json()
    assert d["update_available"] is True


def test_update_apply_requires_url(client):
    r = client.post("/api/update/apply", json={})
    assert r.status_code == 400
    assert r.get_json()["error"] == "no download URL"


def test_update_apply_starts(client, stub_update):
    r = client.post("/api/update/apply", json={"zip_url": "https://x/y.zip", "version": "0.99.0"})
    assert r.status_code == 200
    assert r.get_json()["started"] is True
    d = client.get("/api/update/status").get_json()
    assert d["result"]["version"] == "0.99.0"


def test_update_log(client, monkeypatch):
    monkeypatch.setattr(app_module.updater, "read_update_log", lambda: ["line1"])
    assert client.get("/api/update/log").get_json()["log"] == ["line1"]


# ---------------------------------------------------------------------------
# Activate / restart
# ---------------------------------------------------------------------------


def test_activate_without_hook(client):
    r = client.get("/api/activate")
    assert r.status_code == 409
    assert r.get_json()["activated"] is False


def test_activate_with_hook(client, monkeypatch):
    hook = {"called": False}
    monkeypatch.setattr(app_module, "activate_hook", lambda: hook.__setitem__("called", True))
    d = client.get("/api/activate").get_json()
    assert d["activated"] is True and hook["called"] is True


def test_activate_hook_error(client, monkeypatch):
    def boom():
        raise RuntimeError("nope")
    monkeypatch.setattr(app_module, "activate_hook", boom)
    r = client.get("/api/activate")
    assert r.status_code == 500


def test_restart(client, monkeypatch):
    monkeypatch.setattr(app_module, "_restart_app", lambda: None)
    r = client.post("/api/restart")
    assert r.status_code == 200
    assert r.get_json()["restarting"] is True


def test_restart_error(client, monkeypatch):
    def boom():
        raise RuntimeError("nope")
    monkeypatch.setattr(app_module, "_restart_app", boom)
    r = client.post("/api/restart")
    assert r.status_code == 500


# ---------------------------------------------------------------------------
# Evolve
# ---------------------------------------------------------------------------


def test_evolve_plan(seeded_client):
    d = seeded_client.get("/api/evolve").get_json()
    ready_ids = {e["id"] for e in d["ready"]}
    assert 100 in ready_ids and 500 in ready_ids
    almost_ids = {e["id"] for e in d["almost"]}
    assert 600 in almost_ids
    assert {"name": "Epic Catfruit", "need": 2} in d["missing_fruit"]


def test_evolve_advice_requires_data(client):
    assert client.post("/api/evolve/advice").status_code == 400


def test_evolve_advice_starts(seeded_client, stub_advice):
    r = seeded_client.post("/api/evolve/advice")
    assert r.status_code == 200 and r.get_json()["started"] is True
    d = seeded_client.get("/api/evolve/advice/status").get_json()
    assert d["result"]["advice"]


# ---------------------------------------------------------------------------
# Loadout
# ---------------------------------------------------------------------------


def test_loadout_requires_stage(client):
    r = client.post("/api/loadout", json={})
    assert r.status_code == 400
    assert r.get_json()["error"] == "enter a stage name"


def test_loadout_requires_data(client):
    r = client.post("/api/loadout", json={"stage": "Earth"})
    assert r.status_code == 400
    assert "Detect" in r.get_json()["error"]


def test_loadout_rejects_bad_banned(seeded_client):
    r = seeded_client.post("/api/loadout", json={"stage": "Earth", "banned": "notalist"})
    assert r.status_code == 400


def test_loadout_rejects_bad_powerups(seeded_client):
    r = seeded_client.post("/api/loadout", json={"stage": "Earth", "powerups": "Rich Cat"})
    assert r.status_code == 400


def test_loadout_starts(seeded_client, stub_loadout):
    calls = stub_loadout
    r = seeded_client.post("/api/loadout", json={
        "stage": "Earth (Cats of the Cosmos)",
        "banned": [1],
        "required": [60],
        "powerups": ["Rich Cat"],
        "force": True,
    })
    assert r.status_code == 200 and r.get_json()["started"] is True
    assert calls["__args__"][0] == "Earth (Cats of the Cosmos)"
    assert calls["banned"] == [1]
    assert calls["required"] == [60]
    assert calls["powerups"] == ["Rich Cat"]
    assert calls["force"] is True
    d = seeded_client.get("/api/loadout/status").get_json()
    assert d["done"] is True and d["result"]["loadout"][0]["name"] == "Cat"


def test_loadout_start_returns_false_when_busy(seeded_client, monkeypatch):
    monkeypatch.setattr(app_module.loadout_runner, "start",
                        lambda *a, **k: False)
    r = seeded_client.post("/api/loadout", json={"stage": "Earth"})
    assert r.get_json()["started"] is False


# ---------------------------------------------------------------------------
# Seed
# ---------------------------------------------------------------------------


def test_seed_track(client, stub_seed):
    assert client.post("/api/seed/track").get_json()["started"] is True
    assert client.get("/api/seed/track/status").get_json()["result"]["tracked"] is True


def test_seed_advice(client, stub_seed_advice):
    assert client.post("/api/seed/advice").get_json()["started"] is True
    assert client.get("/api/seed/advice/status").get_json()["result"]["advice"]


def test_seed_saved(client, monkeypatch):
    monkeypatch.setattr(app_module.seed_track, "load_last_result",
                        lambda: {"track": 1})
    monkeypatch.setattr(app_module.ai, "load_last_advice", lambda: {"advice": "a"})
    d = client.get("/api/seed/saved").get_json()
    assert d["track"]["track"] == 1 and d["advice"]["advice"] == "a"


# ---------------------------------------------------------------------------
# Presets
# ---------------------------------------------------------------------------


def test_presets_roundtrip(client):
    assert client.get("/api/presets").get_json() == []
    r = client.post("/api/presets/save", json={"name": "", "result": {}})
    assert r.status_code == 400

    d = client.post("/api/presets/save", json={"name": "My Loadout", "result": {"loadout": []}}).get_json()
    assert d["saved"] == "My Loadout" and d["count"] == 1

    presets = client.get("/api/presets").get_json()
    assert presets[0]["name"] == "My Loadout"

    # saving the same name (different case) replaces, not duplicates
    client.post("/api/presets/save", json={"name": "my loadout", "result": {"loadout": [1]}})
    assert client.get("/api/presets").get_json()[0]["result"] == {"loadout": [1]}

    d = client.post("/api/presets/delete", json={"name": "My Loadout"}).get_json()
    assert d["deleted"] == "My Loadout" and d["count"] == 0
    assert client.get("/api/presets").get_json() == []


# ---------------------------------------------------------------------------
# Enemies (network patched here; real calls live in test_live.py)
# ---------------------------------------------------------------------------


def test_enemies_search(client, monkeypatch):
    monkeypatch.setattr(enemies, "index", lambda force=False: ["Samurai Doggy", "Mega Baa Baa"])
    d = client.get("/api/enemies?q=sam").get_json()
    assert d["titles"] == ["Samurai Doggy"]
    d = client.get("/api/enemies").get_json()
    assert d["titles"][:2] == ["Samurai Doggy", "Mega Baa Baa"]


def test_enemies_all(client, monkeypatch):
    monkeypatch.setattr(enemies, "index", lambda force=False: ["Doge", "Bore", "Bun Bun"])
    d = client.get("/api/enemies/all").get_json()
    assert d["titles"] == ["Doge", "Bore", "Bun Bun"]


def test_enemies_detail_requires_title(client):
    assert client.get("/api/enemies/detail").status_code == 400


def test_enemies_detail(client, seeded_client, monkeypatch):
    detail = {"title": "Samurai Doggy", "info": {}, "traits": ["Red", "Black"],
              "types": [], "intro": "x", "variants": [], "image": ""}
    monkeypatch.setattr(enemies, "detail", lambda t: dict(detail))
    monkeypatch.setattr(enemies, "counters", lambda traits: [{"id": 100, "name": "Bahamut Cat"}])
    d = seeded_client.get("/api/enemies/detail?title=Samurai%20Doggy").get_json()
    assert d["traits"] == ["Red", "Black"]
    assert d["counters"][0]["name"] == "Bahamut Cat"


# ---------------------------------------------------------------------------
# Banners (network patched here; real calls live in test_live.py)
# ---------------------------------------------------------------------------


def test_banners_schedule(client, monkeypatch):
    monkeypatch.setattr(banners, "get_schedule",
                        lambda force=False: {"today": "2026-08-13", "gacha": [], "events": []})
    d = client.get("/api/banners").get_json()
    assert d["today"] == "2026-08-13"


def test_banners_refresh(client, monkeypatch):
    seen = {}
    monkeypatch.setattr(banners, "get_schedule",
                        lambda force=False: seen.__setitem__("force", force) or {"today": "t"})
    d = client.post("/api/banners/refresh").get_json()
    assert seen["force"] is True and d["today"] == "t"


def test_banners_advice_requires_data(client):
    assert client.post("/api/banners/advice").status_code == 400


def test_banners_advice_starts(seeded_client, stub_banner_plan):
    assert seeded_client.post("/api/banners/advice").get_json()["started"] is True
    assert seeded_client.get("/api/banners/advice/status").get_json()["result"]["advice"]


# ---------------------------------------------------------------------------
# Beat check
# ---------------------------------------------------------------------------


def test_beat_requires_stage(client):
    assert client.post("/api/beat", json={}).status_code == 400


def test_beat_requires_data(client):
    assert client.post("/api/beat", json={"stage": "Earth"}).status_code == 400


def test_beat_starts(seeded_client, stub_beat):
    r = seeded_client.post("/api/beat", json={"stage": "Earth (Cats of the Cosmos)"})
    assert r.status_code == 200 and r.get_json()["started"] is True
    d = seeded_client.get("/api/beat/status").get_json()
    assert d["result"]["beatable"] is True
