"""Gacha seed tracking: read the seed from the save, fetch live tracks from
bc.godfat.org and summarize what to roll next."""
import contextlib
import datetime
import html
import json
import os
import re
import sys
import threading
import time

import requests

APP_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_DIR = os.path.dirname(APP_DIR)
if PROJECT_DIR not in sys.path:
    sys.path.insert(0, PROJECT_DIR)

import update_cats as uc  # noqa: E402
from detect import TeeOut  # noqa: E402

GODFAT = "https://bc.godfat.org/"
UA = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) BattleCatsCompanion/1.0"}
SESSION = requests.Session()
SESSION.headers.update(UA)
JST = datetime.timezone(datetime.timedelta(hours=9))
SWITCH_HOUR = 11  # JST - Battle Cats rotates banners/events daily at 11:00 JST

TMP_DIR = os.path.join(APP_DIR, "tmp")
RESULT_PATH = os.path.join(TMP_DIR, "seed_track_result.json")

EVENT_ID = re.compile(r"^\d{4}-\d{2}-\d{2}_\d+$")

RARITY_LABELS = {
    "normal": "Normal",
    "special": "Special",
    "rare": "Rare",
    "supa": "Super Rare",
    "uber": "Uber Rare",
    "legend": "Legend Rare",
    "exclusive": "Exclusive",
    "found": "Found",
    "supa_fest": "Super Rare",
    "uber_fest": "Uber Rare",
}
HIGH_RARITY = ("uber", "legend", "exclusive")

TD = re.compile(r'<td(?P<attrs>[^>]*)>(?P<inner>.*?)</td>', re.S)
LINK = re.compile(r'<a[^>]*>(.*?)</a>', re.S)
CATID = re.compile(r'href="[^"]*?/cats/(\d+)')
RARITY = re.compile(r'minor_(\w+)')
PICK = re.compile(r"pick\('(\d+)([AB])X?'\)")
OPTION = re.compile(r'<option\s+value="([^"]+)"(\s+selected="selected")?[^>]*>\s*(.*?)\s*</option>', re.S)
TABLE = re.compile(r'<table(?P<attrs>[^>]*)>(?P<body>.*?)</table>', re.S)


def _strip_tags(s):
    s = re.sub(r"<[^>]+>", "", s)
    return " ".join(html.unescape(s).split())


_RARITY_TABLE = None


def _rarity_table():
    """All-cat rarity map {app unit id: rarity key} from the local unitbuy.csv.

    godfat's /cats/NNN ids are off by +1 from the app's unit ids, so a cell
    for godfat id N is resolved with the table key N-1. This gives the real
    rarity of the displayed cat on every banner - godfat's own minor_* class
    is only trustworthy on the standard capsule (it reflects the standard
    pool there), and is wrong on the Platinum/Legend pages.
    """
    global _RARITY_TABLE
    if _RARITY_TABLE is None:
        table = {}
        try:
            from BCSFE_Python import csv_handler, helper
            with open(os.path.join(uc.CACHE, "unitbuy.csv"), encoding="utf-8") as f:
                ub = csv_handler.parse_csv(f.read(), ",")
            rows = helper.parse_int_list_list(ub)
            keys = {"Normal": "normal", "Special": "special", "Rare": "rare",
                    "Super Rare": "supa", "Uber Rare": "uber", "Legend Rare": "legend"}
            for i, r in enumerate(rows):
                v = r[13] if len(r) > 13 else -1
                key = keys.get(uc.RARITY_NAMES.get(v, ""))
                if key:
                    table[i] = key
        except Exception:
            table = {}
        _RARITY_TABLE = table
    return _RARITY_TABLE


def _resolve_rarity(godfat_rarity, cid):
    """True rarity of a cat in a track cell, keyed by its godfat id."""
    rar = godfat_rarity
    if rar and rar.endswith("_fest"):
        rar = rar[:-5]
    if rar in ("exclusive", "found") or not cid:
        return rar
    try:
        key = int(cid) - 1
    except (TypeError, ValueError):
        return rar
    resolved = _rarity_table().get(key)
    return resolved if resolved else rar


def read_gacha_fields(save_path):
    """Pull the gacha-relevant numbers straight out of the save file."""
    with open(save_path, "rb") as f:
        data = f.read()
    cc = uc.patcher.detect_game_version(data)
    ss = uc.parse_save.start_parse(data, cc)
    fields = ["rare_gacha_seed", "rare_tickets", "legend_tickets",
              "platinum_tickets", "normal_tickets", "cat_food", "np"]
    out = {}
    for k in fields:
        v = ss.get(k)
        if isinstance(v, dict):
            v = v.get("Value")
        try:
            out[k] = int(v or 0)
        except (TypeError, ValueError):
            out[k] = 0
    return out


def fetch(params, retries=6, base_wait=1.5, log=None):
    """GET a godfat page, retrying transient failures (5xx / timeouts).

    bc.godfat.org is a community server that gets overloaded right after game
    updates - at those times even consecutive requests fail intermittently
    (502 / 500 / timeouts). We retry several times with a short backoff so a
    flaky stretch does not abort the whole seed-track run.
    """
    last_err = None
    for attempt in range(1, retries + 1):
        try:
            r = SESSION.get(GODFAT, params=params, timeout=45)
            if r.status_code == 200:
                r.encoding = "utf-8"
                return r.text
            if 500 <= r.status_code < 600:
                last_err = f"godfat replied {r.status_code} (server busy)"
            else:
                r.raise_for_status()
        except (requests.exceptions.Timeout, requests.exceptions.ConnectionError) as e:
            last_err = f"godfat unreachable ({e.__class__.__name__})"
        if attempt < retries:
            if log:
                log(f"  godfat hiccup ({last_err}) - retrying ({attempt}/{retries}) ...")
            time.sleep(min(base_wait * attempt, 10))
    raise RuntimeError(
        f"bc.godfat.org is not answering ({last_err}). It's a community server "
        f"that often gets slow right after a game update - nothing is wrong with "
        f"your save. Just try again in a few minutes.")


def parse_events(html):
    out = []
    for m in OPTION.finditer(html):
        eid = m.group(1)
        if not EVENT_ID.match(eid):
            continue
        label = " ".join(m.group(3).split())
        date = ""
        dm = re.match(r"(\d{4}-\d{2}-\d{2})\s*~\s*(\d{4}-\d{2}-\d{2})", label)
        if dm:
            date = f"{dm.group(1)} ~ {dm.group(2)}"
        out.append({"id": eid, "selected": bool(m.group(2)), "label": label, "date": date})
    return out


def parse_track(html):
    """Parse the 100-position A/B track grid from a godfat page."""
    m = TABLE.search(html)
    body = m.group("body") if m else html
    tracks = {"A": {}, "B": {}}
    cur = None
    for m in TD.finditer(body):
        attrs = m.group("attrs")
        cls = " ".join(re.findall(r'class="([^"]*)"', attrs))
        if "position" not in cls:
            continue
        inner = m.group("inner")
        pm = PICK.search(attrs)
        rar_m = RARITY.search(cls)
        rarity = rar_m.group(1) if rar_m else None
        nxt = "next_position" in cls
        fm = LINK.search(inner)
        name = _strip_tags(fm.group(1)) if fm else None
        cm = CATID.search(inner)
        cid = cm.group(1) if cm else None
        rarity = _resolve_rarity(rarity, cid)
        if pm:
            num, letter = pm.group(1), pm.group(2)
            key = (int(num), letter)
            old = tracks[letter].get(key)
            if old is None or (name and not old.get("name")):
                tracks[letter][key] = {
                    "pos": num, "track": letter, "rarity": rarity,
                    "next": nxt, "name": name, "id": cid,
                }
            cur = key
        elif cur and "cat" in cls and name:
            e = tracks[cur[1]].get(cur)
            if e is not None:
                e["guaranteed"] = {"name": name, "id": cid, "rarity": rarity}
    out = {}
    for letter in ("A", "B"):
        out[letter] = [tracks[letter][k] for k in sorted(tracks[letter])]
    return out


def banner_highlights(tracks):
    """First high-rarity unit per track (and guaranteed summary)."""
    highs = {}
    for letter in ("A", "B"):
        h = {"next_uber": None, "next_legend": None, "next_exclusive": None, "guaranteed": []}
        for e in tracks[letter]:
            rar = e["rarity"]
            if rar == "uber" and h["next_uber"] is None:
                h["next_uber"] = {"pos": e["pos"], "name": e["name"], "id": e["id"], "rarity": rar}
            if rar == "legend" and h["next_legend"] is None:
                h["next_legend"] = {"pos": e["pos"], "name": e["name"], "id": e["id"], "rarity": rar}
            if rar == "exclusive" and h["next_exclusive"] is None:
                h["next_exclusive"] = {"pos": e["pos"], "name": e["name"], "id": e["id"], "rarity": rar}
            if e.get("guaranteed"):
                h["guaranteed"].append(e["guaranteed"])
        highs[letter] = h
    return highs


def _date_bounds(e):
    m = re.match(r"(\d{4}-\d{2}-\d{2})\s*~\s*(\d{4}-\d{2}-\d{2})", e.get("date", ""))
    return (m.group(1), m.group(2)) if m else (None, None)


def pick_banners(events, current_id, today=None, now=None):
    """Choose which banners to fetch: every banner live today (start <= today
    <= end), except on a rotation switch day, plus the permanent Platinum and
    Legend capsules (godfat pads those to a far-future date - they never
    rotate, so they are always included).

    A banner ending today stays live until today's 11:00 JST switch, and a
    banner that *starts* today only becomes live at that switch. godfat's
    "current event" flag is supposed to move when the switch happens, but it
    can lag well past it (e.g. it still flagged a banner that ended at 11:00
    JST late into the evening), so the day counts as switched either when
    godfat has flipped to a banner starting today OR once 11:00 JST has
    passed - whichever comes first."""
    now = now or datetime.datetime.now(JST)
    today = today or now.strftime("%Y-%m-%d")
    switch_dt = datetime.datetime.combine(
        datetime.date.fromisoformat(today), datetime.time(SWITCH_HOUR, 0), tzinfo=JST)
    switch_passed = now >= switch_dt
    candidates = []
    for e in events:
        start, end = _date_bounds(e)
        if start and end and start <= today <= end:
            candidates.append(e)
    switched = switch_passed or any(
        e["selected"] for e in candidates if _date_bounds(e)[0] == today)
    picks = []
    for e in candidates:
        start, end = _date_bounds(e)
        if switched:
            if end == today:
                continue  # replaced by the new rotation at today's switch
        elif start == today and not e["selected"]:
            continue  # not live yet - the switch hasn't happened
        picks.append(e["id"])
    return picks


def resolve_current(events, picks, today=None):
    """Best current banner: godfat's selected event when it is still live (in
    picks), otherwise the most recently started live banner - after a game
    update the new rotation is current even before godfat's flag moves."""
    live = [e for e in events if e["id"] in picks]
    if not live:
        return None, None
    sel = [e for e in live if e["selected"]]
    if sel:
        return sel[0]["id"], sel[0]["label"]
    order = {e["id"]: i for i, e in enumerate(live)}

    def key(e):
        start, end = _date_bounds(e)
        return (start or "", end or "", len(live) - order[e["id"]])

    best = max(live, key=key)
    return best["id"], best["label"]


def _next_upcoming(events, current_id, n=6):
    """Upcoming capsule events after the current one, for timing context."""
    evs = [e for e in events if e["id"] != current_id and e["id"] > (current_id or "")]
    return [{"id": e["id"], "label": e["label"], "date": e["date"]} for e in evs[:n]]


class SeedRunner:
    def __init__(self):
        self.lock = threading.Lock()
        self.running = False
        self.done = False
        self.error = None
        self.log_lines = []
        self.result = None

    def _log(self, line):
        with self.lock:
            self.log_lines.append(line)

    def snapshot(self):
        with self.lock:
            return {
                "running": self.running,
                "done": self.done,
                "error": self.error,
                "log": list(self.log_lines),
                "result": self.result,
            }

    def start(self):
        if self.running:
            return False
        with self.lock:
            self.running = True
            self.done = False
            self.error = None
            self.result = None
            self.log_lines = []
        threading.Thread(target=self._run, daemon=True).start()
        return True

    def _run(self):
        log = self._log
        sink = []
        real_out = sys.stdout
        real_err = sys.stderr
        try:
            sys.stdout = TeeOut(real_out, sink)
            sys.stderr = TeeOut(real_err, sink)
            with contextlib.redirect_stdout(sys.stdout):
                with contextlib.redirect_stderr(sys.stderr):
                    result = self._pipeline()
        except SystemExit:
            log("ERROR: pipeline aborted")
            with self.lock:
                self.error = "Pipeline aborted (see log)"
                self.done = True
                self.running = False
        except Exception as e:
            log("ERROR: " + str(e))
            if not isinstance(e, (RuntimeError, ValueError)):
                import traceback
                for l in traceback.format_exc().splitlines():
                    log(l)
            with self.lock:
                self.error = str(e)
                self.done = True
                self.running = False
        finally:
            sys.stdout = real_out
            sys.stderr = real_err
        if not self.done:
            with self.lock:
                self.result = result
                self.done = True
                self.running = False
        for line in sink:
            self._log(line)

    def _pipeline(self):
        log = self._log
        os.makedirs(TMP_DIR, exist_ok=True)

        log("Reading the save (BlueStacks must be fully closed)...")
        save_path = uc.step_extract()
        g = read_gacha_fields(save_path)
        seed = g["rare_gacha_seed"]
        log(f"Gacha seed: {seed}")
        if not seed:
            raise ValueError("No rare gacha seed found in the save - has the gacha been used on this account yet?")

        log("Fetching live track from bc.godfat.org ...")
        html = fetch({"seed": seed}, log=log)
        events = parse_events(html)
        picks = pick_banners(events, None)
        current_id, current_label = resolve_current(events, picks)
        if not current_label:
            current_label = "current banner"
        log(f"Current banner: {current_label}")

        by_id = {e["id"]: e for e in events}
        picks = pick_banners(events, current_id)
        banners = []
        for eid in picks:
            e = by_id.get(eid, {})
            label = e.get("label") or eid
            log(f"Fetching track for {label} ...")
            ph = fetch({"seed": seed, "event": eid}, log=log)
            tracks = parse_track(ph)
            if not tracks["A"]:
                log(f"  WARNING: no track parsed for {label}")
            b = {
                "id": eid,
                "label": label,
                "date": e.get("date", ""),
                "is_current": eid == current_id,
                "tracks": tracks,
                "highlights": banner_highlights(tracks),
            }
            h = b["highlights"]
            log(f"  Track A: first Uber at {_hi(h['A']['next_uber'])}"
                f", first Legend at {_hi(h['A']['next_legend'])}"
                f", first Exclusive at {_hi(h['A']['next_exclusive'])}")
            log(f"  Track B: first Uber at {_hi(h['B']['next_uber'])}"
                f", first Legend at {_hi(h['B']['next_legend'])}"
                f", first Exclusive at {_hi(h['B']['next_exclusive'])}")
            banners.append(b)

        result = {
            "seed": seed,
            "date": time.strftime("%Y-%m-%d %H:%M:%S"),
            "resources": g,
            "current_banner": current_id,
            "current_label": current_label,
            "upcoming": _next_upcoming(events, current_id),
            "banners": banners,
        }
        with open(RESULT_PATH, "w", encoding="utf-8") as f:
            json.dump(result, f, ensure_ascii=False)
        log(f"Saved track result: {RESULT_PATH}")
        log("Done. Tracks cover the next 100 rolls per side (position 1 = your next roll).")
        return result


def _hi(h):
    if not h:
        return "none"
    return f"#{h['pos']} {h['name'] or '?'}"


def load_last_result():
    try:
        with open(RESULT_PATH, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return None
