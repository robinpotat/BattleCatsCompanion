import json
import os
import time

import requests

APP_DIR = os.path.dirname(os.path.abspath(__file__))
CACHE_DIR = os.path.join(APP_DIR, "cache")
CACHE_FILE = os.path.join(CACHE_DIR, "allcats.json")
ALL_CATS_URL = "https://onestoppress.com/api/allcats"
STALE_SECONDS = 7 * 86400

RARITY_MAP = {
    "Normal": "Basic",
    "Uber Rare": "Uber Super Rare",
    "Legend Rare": "Legendary Rare",
}


def fetch_allcats():
    """Download + cache mygamatoto's all-cats dataset. Returns True on success."""
    os.makedirs(CACHE_DIR, exist_ok=True)
    try:
        r = requests.get(ALL_CATS_URL, timeout=120)
        r.raise_for_status()
        data = r.json().get("sampledata")
        if not data:
            return False
        tmp = CACHE_FILE + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump({"fetched_at": int(time.time()), "sampledata": data}, f, ensure_ascii=False)
        os.replace(tmp, CACHE_FILE)
        return True
    except Exception:
        return False


def ensure_cache():
    """Make sure the cache exists and is fresh. Returns (bool ok, bool fetched)."""
    if not os.path.exists(CACHE_FILE):
        return fetch_allcats(), True
    if time.time() - os.path.getmtime(CACHE_FILE) > STALE_SECONDS:
        return fetch_allcats(), True
    return True, False


def load_data():
    try:
        with open(CACHE_FILE, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return None


def scale_stat(rarity, level, iscrazed, isbahamut, base):
    """Exact port of mygamatoto's client-side stat scaling (their bundle, fn 'n')."""
    if isbahamut and level > 30:
        return base * (6.8 + 0.1 * (level - 30))
    if iscrazed and level < 21:
        return base * (1 + 0.2 * (level - 1))
    if iscrazed and level > 20:
        return base * (4.8 + 0.1 * (level - 20))
    if level < 61:
        return base * (1 + 0.2 * (level - 1))
    if level < 81 and rarity != "Rare":
        return base * (12.8 + 0.1 * (level - 60))
    if level < 71 and rarity == "Rare":
        return base * (1 + 0.2 * (level - 1))
    if level < 91 and rarity == "Rare":
        return base * (14.8 + 0.1 * (level - 70))
    if level > 80 and rarity in ("Super Rare", "Uber Super Rare"):
        return base * (14.8 + 0.05 * (level - 80))
    if level > 90 and rarity == "Rare":
        return base * (16.8 + 0.05 * (level - 90))
    if level > 60:
        return base * (12.8 + 0.1 * (level - 60))
    return 0


FORM_LABEL = {0: "Base", 1: "Evolved", 2: "True", 3: "Ultra"}


def _scaled_form(entry, level):
    """Scale one mygamatoto form entry to the given level."""
    iscrazed = entry.get("iscrazed") not in (None, False, "")
    isbahamut = "bahamut" in (entry["name"] or "").lower()
    mul = scale_stat(entry["rarity"], level, iscrazed, isbahamut, 1.0)
    return {
        "form_name": entry["name"],
        "form_label": entry.get("form") or "",
        "health": int(round(entry["health"] * mul)),
        "damage": int(round(entry["damage"] * mul)),
        "dps": int(round(entry["dps"] * mul)),
        "range": entry["range"],
        "speed": entry["speed"],
        "kb": entry["kb"],
        "cost": entry["cost"],
        "target": entry["target"],
        "tba": entry["tba"],
        "anim": entry["anim"],
        "spawn": entry["spawn"],
        "base_dps": entry["dps"],
    }


def attach_stats(rows, log=None):
    """Attach 'stats' (mygamatoto, scaled to the cat's current level) to each row.

    stats holds the current form's values at the top level (backwards compat),
    plus 'form' (current form index) and 'forms' (index -> stat dict) so the
    roster can display every form a cat has.
    """
    if not ensure_cache()[0]:
        if log:
            log("  WARNING: could not fetch mygamatoto stats (DPS/HP will be unavailable)")
        for r in rows:
            r["stats"] = None
        return rows
    data = load_data()
    if not data:
        if log:
            log("  WARNING: mygamatoto cache unreadable")
        for r in rows:
            r["stats"] = None
        return rows

    by_number = {}
    for c in data["sampledata"]:
        by_number[c["number"]] = c

    matched = 0
    multi = 0
    for row in rows:
        cid = row["id"]
        level = row["level_base"] + row["level_plus"]

        forms = {}
        for f in range(0, 12):
            entry = by_number.get(f"{cid + 1:03d}-{f + 1}")
            if entry is None:
                break
            forms[str(f)] = _scaled_form(entry, level)

        if not forms:
            row["stats"] = None
            continue
        matched += 1
        if len(forms) > 1:
            multi += 1

        cur = row["cur"]
        cur_key = str(cur) if str(cur) in forms else next(iter(forms))
        row["stats"] = dict(forms[cur_key])
        row["stats"]["form"] = int(cur_key)
        row["stats"]["level"] = level
        row["stats"]["forms"] = forms

    if log:
        log(f"  mygamatoto stats attached for {matched}/{len(rows)} cats ({multi} with multiple forms)")
    return rows


if __name__ == "__main__":
    ok = fetch_allcats()
    print("fetch ok:", ok)
