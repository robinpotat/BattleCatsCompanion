@echo off
setlocal EnableExtensions
cd /d "%~dp0cats_app"
echo ============================================
echo  Battle Cats Companion - Setup
echo ============================================
echo.
echo Step 1/5  Checking for Python...

set "PYEXE="
for /f "delims=" %%i in ('where py 2^>nul') do if not defined PYEXE set "PYEXE=%%i"
for /f "delims=" %%i in ('where python 2^>nul') do if not defined PYEXE set "PYEXE=%%i"
for /f "delims=" %%i in ('where python3 2^>nul') do if not defined PYEXE set "PYEXE=%%i"

if not defined PYEXE (
  echo   Python is not installed. Trying the Windows Store installer...
  winget install -e --id Python.Python.3.11 --silent --accept-package-agreements --accept-source-agreements >nul 2>&1
  for /f "delims=" %%i in ('where py 2^>nul') do if not defined PYEXE set "PYEXE=%%i"
  for /f "delims=" %%i in ('where python 2^>nul') do if not defined PYEXE set "PYEXE=%%i"
)
if not defined PYEXE (
  echo.
  echo   [ERROR] Python is still missing.
  echo   Please install Python manually from https://www.python.org/downloads/
  echo   and tick "Add Python to PATH" during install, then run Setup.bat again.
  echo.
  pause
  exit /b 1
)
echo   Found: %PYEXE%

echo.
echo Step 2/5  Creating a private virtual environment (.venv)...
"%PYEXE%" -m venv .venv
if errorlevel 1 (
  echo   [ERROR] Could not create the virtual environment.
  pause
  exit /b 1
)

echo.
echo Step 3/5  Installing packages (needs internet, a few minutes)...
".venv\Scripts\python.exe" -m pip install --disable-pip-version-check --upgrade pip
".venv\Scripts\python.exe" -m pip install --disable-pip-version-check -r requirements.txt
if errorlevel 1 (
  echo   [ERROR] Package installation failed. Check the messages above.
  pause
  exit /b 1
)

echo.
echo Step 4/5  Verifying the install...
".venv\Scripts\python.exe" -c "import sys; sys.path.insert(0,'lib'); import flask, webview, requests, BCSFE_Python; print('   OK: flask, pywebview, requests, BCSFE_Python all import fine')"
if errorlevel 1 (
  echo   [ERROR] Verification failed - see messages above.
  pause
  exit /b 1
)

echo.
echo Step 5/5  Creating a desktop shortcut...
set "SC_OK="
set "MKSH=%TEMP%\bc_mkshortcut.ps1"
>  "%MKSH%" echo $d=[Environment]::GetFolderPath('Desktop')
>> "%MKSH%" echo $s=(New-Object -ComObject WScript.Shell).CreateShortcut($d+'\Battle Cats Companion.lnk')
>> "%MKSH%" echo $s.TargetPath='%~dp0cats_app\run.bat'
>> "%MKSH%" echo $s.WorkingDirectory='%~dp0cats_app'
>> "%MKSH%" echo $s.IconLocation='%~dp0cats_app\assets\icon.ico'
>> "%MKSH%" echo $s.Description='Battle Cats Companion'
>> "%MKSH%" echo $s.Save()
>> "%MKSH%" echo if (Test-Path ($d+'\Battle Cats Companion.lnk')) { Write-Output 'SHORTCUT_OK' } else { Write-Output 'SHORTCUT_FAIL' }
for /f "delims=" %%i in ('powershell -NoProfile -ExecutionPolicy Bypass -File "%MKSH%"') do set "SC_OK=%%i"
del "%MKSH%" >nul 2>&1

if "%SC_OK%"=="SHORTCUT_OK" (
  echo   Desktop shortcut created.
) else (
  echo   [WARN] Could not create the desktop shortcut automatically.
  echo   Launch the app from run.bat inside the cats_app folder instead.
)

echo.
echo ============================================
echo  Setup complete!
echo  Double-click "Battle Cats Companion" on your desktop.
echo.
echo  Then: close BlueStacks, open the app, and click "Detect save".
echo ============================================
echo.
pause
