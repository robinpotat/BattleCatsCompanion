import sys, os, json, csv, shutil, time, subprocess, hashlib

NO_WINDOW = subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0

# ------------------------------------------------------------------
# Paths (auto-detected; edit only if your setup differs)
# ------------------------------------------------------------------
BASE_DIR     = os.path.dirname(os.path.abspath(__file__))


def _find_vhdx():
    """Locate the BlueStacks data disk image (engine name varies)."""
    base = r"C:\ProgramData\BlueStacks_nxt\Engine"
    if os.path.isdir(base):
        for eng in sorted(os.listdir(base)):
            p = os.path.join(base, eng, "Data.vhdx")
            if os.path.exists(p):
                return p
    return r"C:\ProgramData\BlueStacks_nxt\Engine\Nougat32\Data.vhdx"


def _find_7z():
    """Use the bundled portable 7-Zip if present, else a system install."""
    bundled = os.path.join(BASE_DIR, "7zip", "7z.exe")
    if os.path.exists(bundled):
        return bundled
    for p in (r"C:\Program Files\7-Zip\7z.exe", r"C:\Program Files (x86)\7-Zip\7z.exe"):
        if os.path.exists(p):
            return p
    return r"C:\Program Files\7-Zip\7z.exe"


VHDX         = _find_vhdx()
SZ7          = _find_7z()
CACHE        = os.path.join(BASE_DIR, "cats_app", "cache", "bcdata")
TMP          = os.path.join(BASE_DIR, "cats_app", "tmp", "update")
DELIV        = BASE_DIR                                        # this project folder
OUTPUT_FILES = ["cats_report.json", "cats_all.txt"]
CHANGES_LOG  = os.path.join(DELIV, "cats_changes.txt")
BCDATA_URL   = "https://git.battlecatsmodding.org/fieryhenry/BCData/raw/branch/main/game_data/en/15.5.0/"
GAME_VERSION = "15.5.0"
COMBO_FILES  = ["NyancomboData.csv", "Nyancombo_en.csv", "Nyancombo1_en.csv",
                "NyancomboParam.tsv"]
TALENT_FILES = {"SkillAcquisition.csv": "DataLocal/", "SkillDescriptions.csv": "resLocal/"}
ORB_FILES = {"equipmentlist.json": "DataLocal/", "equipmentgrade.csv": "DataLocal/",
             "attribute_explonation.tsv": "resLocal/", "equipment_explonation.tsv": "resLocal/"}
ITEM_FILES = {"GatyaitemName.csv": "resLocal/", "Matatabi.tsv": "DataLocal/"}
BATTLE_ITEM_NAMES = ["Speed Up", "Treasure Radar", "Rich Cat", "Cat CPU", "Cat Jobs", "Sniper the Cat"]
CATSEYE_NAMES = ["Special", "Rare", "Super Rare", "Uber Rare", "Legend", "Dark"]
EXTRA_FILES = {"unitbuy.csv": "", "nyankoPictureBookData.csv": ""}
SAVE_VERSION = 150500  # set by step_parse from the save's own header
# ------------------------------------------------------------------


def _ver_str(v):
    """150500 -> '15.5.0' (matches the BCData folder layout)."""
    try:
        v = int(v)
        return f"{v // 10000}.{v // 100 % 100}.{v % 100}"
    except Exception:
        return GAME_VERSION


def bcd_url(version=None):
    """BCData URL for a game version; defaults to the detected save version."""
    version = version or _ver_str(SAVE_VERSION)
    return f"https://git.battlecatsmodding.org/fieryhenry/BCData/raw/branch/main/game_data/en/{version}/"


def data_versions():
    """Candidate versions to try when fetching data (detected first, bundled as fallback)."""
    out = [_ver_str(SAVE_VERSION), GAME_VERSION]
    seen, res = set(), []
    for v in out:
        if v and v not in seen:
            seen.add(v)
            res.append(v)
    return res


def fetch_file(sess, rel, dest):
    """Fetch one BCData file into CACHE, trying each available version. Returns version used or None."""
    os.makedirs(os.path.dirname(dest), exist_ok=True)
    for v in data_versions():
        for attempt in range(4):
            try:
                r = sess.get(bcd_url(v) + rel, timeout=45)
                if r.status_code == 200 and r.text.strip():
                    open(dest, "wb").write(r.content)
                    return v
            except Exception:
                pass
            time.sleep(attempt + 1)
    return None

_LIB = os.path.join(BASE_DIR, "cats_app", "lib")
if os.path.isdir(_LIB) and _LIB not in sys.path:
    sys.path.insert(0, _LIB)
_SITE = os.path.join(os.path.expanduser("~"), "AppData", "Roaming", "Python", "Python310", "site-packages")
if os.path.isdir(_SITE) and _SITE not in sys.path:
    sys.path.append(_SITE)
from BCSFE_Python import parse_save, patcher, csv_handler, helper

TRAITS = {10: "Red", 16: "Floating", 17: "Black", 18: "Metal", 19: "Traitless", 20: "Angel", 21: "Alien", 22: "Zombie", 54: "Witch", 76: "Eva", 78: "Relic", 96: "Aku"}
RARITY_NAMES = {0: "Normal", 1: "Special", 2: "Rare", 3: "Super Rare", 4: "Uber Rare", 5: "Legend Rare"}
FORM_LABEL = {0: "Base", 1: "Evolved", 2: "True", 3: "Ultra"}
CANNON_NAMES = {0: "Standard", 1: "Slow Beam", 2: "Iron Wall", 3: "Thunderbolt",
                4: "Waterblast", 5: "Holy Blast", 6: "Breakerblast", 7: "Curseblast"}


def log(*a):
    print(*a, flush=True)


SECTIONS = []


def section(title, lines):
    SECTIONS.append((title, lines))


def fmt_dur(f):
    return f"{f/30:.1f}s"


def decode_form(row, n=130):
    vals = [0] * n
    for i, v in enumerate(row):
        if i >= n:
            break
        try:
            vals[i] = int(v.strip().split("//")[0].strip()) if v.strip() else 0
        except ValueError:
            vals[i] = 0
    return vals


def multi_hit_count(v):
    """Number of hits in one attack cycle (attack_2_damage / attack_3_damage)."""
    hits = 1
    if v[59]:
        hits = 2
    if v[60]:
        hits = 3
    return hits


def ability_hits(v):
    """1-indexed hits that actually carry the unit's abilities (attack_N_use_ability)."""
    return [n for n, col in ((1, 63), (2, 64), (3, 65)) if v[col]]


def abilities_for(v):
    a = []
    targets = [name for col, name in TRAITS.items() if v[col]]
    t_str = ", ".join(targets) if targets else ""
    t_paren = f" vs {t_str}" if targets else ""
    if v[23]: a.append("Strong" + t_paren)
    if v[29]: a.append("Tough/Resistant" + t_paren)
    if v[30]: a.append("Massive dmg" + t_paren)
    if v[80]: a.append("Insanely Tough" + t_paren)
    if v[81]: a.append("Insane dmg" + t_paren)
    if v[70]: a.append(f"Barrier Break {v[70]}%")
    if v[95]: a.append(f"Shield Pierce {v[95]}%")
    if v[24]: a.append(f"Knockback {v[24]}%{t_paren}")
    if v[25]: a.append(f"Freeze {v[25]}% ({fmt_dur(v[26])}){t_paren}")
    if v[27]: a.append(f"Slow {v[27]}% ({fmt_dur(v[28])}){t_paren}")
    if v[37]: a.append(f"Weaken {v[37]}% ({fmt_dur(v[38])}, enemy dmg to {v[39]}%){t_paren}")
    if v[35]: a.append(f"Wave Lv{v[36]} {v[35]}%")
    if v[86]: a.append(f"Surge Lv{v[89]} {v[86]}%")
    if v[92]: a.append(f"Curse {v[92]}% ({fmt_dur(v[93])}){t_paren}")
    if v[31]: a.append(f"Crit {v[31]}%")
    if v[82]: a.append(f"Savage Blow {v[82]}% ({(100+v[83])//100 if v[83] else 2}x dmg)")
    if v[84]: a.append(f"Dodge {v[84]}% ({fmt_dur(v[85])})")
    if v[71]: a.append(f"Warp {v[71]}% ({fmt_dur(v[72])})")
    if v[40]: a.append(f"Strengthen {v[41]}% dmg at <= {v[40]}% HP")
    if v[42]: a.append(f"Survive lethal hit {v[42]}%")
    if v[43]: a.append("Metal (takes 1 dmg/hit)")
    if v[52]: a.append("Zombie Killer")
    if v[53]: a.append("Witch Killer")
    if v[77]: a.append("Eva Killer")
    if v[98]: a.append("Soul Strike")
    if v[32]: a.append("Attacks Only" + t_paren)
    if v[33]: a.append("2x Money")
    if v[34]: a.append("Base Destroyer (4x dmg to base)")
    if v[97]: a.append("Colossus Slayer")
    if v[105]: a.append("Behemoth Slayer")
    if v[111]: a.append("Sage Slayer")
    if v[112]: a.append(f"Metal Killer ({v[112]}% of max HP)")
    if v[109]: a.append("Counter Surge")
    if v[44] or v[45]:
        start, rng = v[44], v[45]
        if rng >= 0:
            a.append(f"Long Distance {start}~{start+rng}")
        else:
            a.append(f"Omni Strike {start+rng}~{start}")
    if v[110]: a.append(f"Summon (1x max)")
    if v[55] and v[55] > 0: a.append(f"Attacks {v[55]}x then stops")
    if v[57] and v[57] > 0: a.append(f"Dies after {v[57]}f")
    if v[94]: a.append("Mini-Wave")
    if v[106]: a.append(f"Behemoth Dodge {v[106]}% ({fmt_dur(v[107])})")
    if v[113]: a.append(f"Explosion {v[113]}%")
    if v[12]: a.append("Area Attack")
    hits = multi_hit_count(v)
    if hits > 1:
        ah = ability_hits(v)
        if len(ah) == hits:
            a.append(f"Multi-Hit ({hits} hits)")
        else:
            ord_label = {1: "1st", 2: "2nd", 3: "3rd"}
            labels = [ord_label[n] for n in sorted(set(ah))]
            if len(labels) <= 1:
                where = labels[0] if labels else "?"
            else:
                where = ", ".join(labels[:-1]) + f" and {labels[-1]}"
            a.append(f"Multi-Hit ({hits} hits; abilities on {where})")
    return a, targets


def immunities_for(v):
    im = []
    if v[46]: im.append("Wave")
    if v[48]: im.append("Knockback")
    if v[49]: im.append("Freeze")
    if v[50]: im.append("Slow")
    if v[51]: im.append("Weaken")
    if v[79]: im.append("Curse")
    if v[90]: im.append("Toxic")
    if v[91]: im.append("Surge")
    if v[75]: im.append("Warp")
    if v[56]: im.append("Boss Shockwave")
    if v[116]: im.append("Explosion")
    if v[47]: im.append("Wave Blocker")
    return im


def names_for(cid):
    fn = f"Unit_Explanation{cid+1}_en.csv"
    p = os.path.join(CACHE, "resLocal", fn)
    if not os.path.exists(p):
        return None
    rows = csv_handler.parse_csv(open(p, encoding="utf-8").read(), "|")
    out = [r[0].strip() if r else "" for r in rows]
    while len(out) < 4:
        out.append("")
    return out


# ------------------------------------------------------------------
def _bluestacks_running():
    out = subprocess.run(
        ["powershell", "-NoProfile", "-Command",
         "Get-Process -Name 'HD-Player','BlueStacksServices' -ErrorAction SilentlyContinue | Select-Object -ExpandProperty ProcessName"],
        capture_output=True, text=True, timeout=30, creationflags=NO_WINDOW).stdout.strip()
    return bool(out)


def _close_bluestacks():
    """Force BlueStacks to quit without a confirm dialog (the save was already written to the disk)."""
    log("  BlueStacks is running - closing it automatically ...")
    subprocess.run(["taskkill", "/IM", "HD-Player.exe", "/F", "/T"],
                   capture_output=True, text=True, timeout=30, creationflags=NO_WINDOW)
    subprocess.run(["taskkill", "/IM", "BlueStacksServices.exe", "/F"],
                   capture_output=True, text=True, timeout=30, creationflags=NO_WINDOW)
    for _ in range(60):
        if not _bluestacks_running():
            time.sleep(3)
            log("  BlueStacks closed.")
            return
        time.sleep(0.5)
    log("  WARNING: BlueStacks is still shutting down - continuing anyway ...")


def _is_vhdx_unlocked():
    """Check if the VHDX file is no longer locked by another process."""
    try:
        f = open(VHDX, "rb")
        f.close()
        return True
    except (PermissionError, OSError):
        return False


def step_extract():
    log("[1/8] Closing BlueStacks if it is running ...")
    if _bluestacks_running():
        _close_bluestacks()

    if not os.path.exists(VHDX):
        log(f"  ERROR: disk image not found: {VHDX}")
        sys.exit(1)
    if not os.path.exists(SZ7):
        log(f"  ERROR: 7-Zip not found: {SZ7}")
        sys.exit(1)

    # Wait for file locks to release
    log("  Waiting for file locks to release ...")
    for i in range(12):
        if _is_vhdx_unlocked():
            break
        time.sleep(5)
    if not _is_vhdx_unlocked():
        log("  WARNING: VHDX still locked after waiting - attempting extraction anyway ...")

    log("[2/8] Pulling fresh SAVE_DATA from the BlueStacks disk image ...")
    os.makedirs(TMP, exist_ok=True)
    save_path = os.path.join(TMP, "data", "jp.co.ponos.battlecatsen", "files", "SAVE_DATA")
    if os.path.exists(save_path):
        os.remove(save_path)

    for attempt in range(3):
        if os.path.exists(save_path):
            os.remove(save_path)
        r = subprocess.run([SZ7, "x", "-ssp", "-y", VHDX,
                            "data/jp.co.ponos.battlecatsen/files/SAVE_DATA",
                            f"-o{TMP}"], capture_output=True, text=True, creationflags=NO_WINDOW)
        if os.path.exists(save_path) and os.path.getsize(save_path) > 0:
            break
        if attempt < 2:
            log(f"  extraction attempt {attempt+1} failed (file locked?) - retrying in 5s ...")
            time.sleep(5)
    # A force-closed BlueStacks leaves the guest filesystem needing journal recovery, so
    # 7-Zip prints "Headers Error" and exits 2 even though it extracted the file fine.
    if not os.path.exists(save_path) or os.path.getsize(save_path) == 0:
        log("  ERROR: SAVE_DATA not extracted:\n" + r.stdout + r.stderr)
        sys.exit(1)
    if r.returncode != 0:
        log("  WARNING: 7-Zip exited {} (the disk image shows recovery flags after the force-close) but SAVE_DATA was extracted fine.".format(r.returncode))
    log(f"  extracted SAVE_DATA ({os.path.getsize(save_path)} bytes, mtime {time.ctime(os.path.getmtime(save_path))})")
    return save_path


def parse_cannons(ss):
    data = ss.get("ototo_cannon") or {}
    out = []
    for cid in sorted(CANNON_NAMES):
        if cid == 0:
            out.append(CANNON_NAMES[cid])
            continue
        info = data.get(cid, data.get(str(cid)))
        if info and info.get("unlock_flag", 0) >= 3:
            out.append(CANNON_NAMES[cid])
    return out


def parse_fruit_names():
    """Item display names in the order the save's cat_fruit list uses them."""
    item_names = csv_handler.parse_csv(open(os.path.join(CACHE, "GatyaitemName.csv"), encoding="utf-8-sig").read(), "|")
    fruit_ids = helper.parse_int_list_list(
        csv_handler.parse_csv(open(os.path.join(CACHE, "Matatabi.tsv"), encoding="utf-8-sig").read(), "\t")
    )[1:]
    out = []
    for fr in fruit_ids:
        idx = int(fr[0])
        out.append(item_names[idx][0] if idx < len(item_names) and item_names[idx] else f"Item {idx}")
    return out


def item_name(item_id):
    """Display name for an item id (GatyaitemName.csv line index = item id)."""
    try:
        rows = csv_handler.parse_csv(
            open(os.path.join(CACHE, "GatyaitemName.csv"), encoding="utf-8-sig").read(), "|")
        if 0 <= item_id < len(rows) and rows[item_id]:
            return rows[item_id][0].strip()
    except Exception:
        pass
    return f"Item {item_id}"


def build_items(cat_fruit, battle_items, catseyes=None):
    """Turn the raw save lists into named items for the Items tab + AI prompt."""
    names = parse_fruit_names()
    fruit_ids = helper.parse_int_list_list(
        csv_handler.parse_csv(open(os.path.join(CACHE, "Matatabi.tsv"), encoding="utf-8-sig").read(), "\t")
    )[1:]
    fruit = [{"id": fruit_ids[i][0], "name": names[i] if i < len(names) else f"Item {i}", "count": cat_fruit[i]}
             for i in range(len(cat_fruit))]
    battle = [{"id": i, "name": BATTLE_ITEM_NAMES[i] if i < len(BATTLE_ITEM_NAMES) else f"Item {i}", "count": battle_items[i]}
              for i in range(len(battle_items))]
    eyes = []
    if catseyes:
        for i, count in enumerate(catseyes):
            eyes.append({"id": i, "name": CATSEYE_NAMES[i] if i < len(CATSEYE_NAMES) else f"Catseye {i}", "count": count})
    return {"cat_fruit": fruit, "battle_items": battle, "catseyes": eyes}


def step_parse(save_path):
    global SAVE_VERSION
    log("[3/8] Decoding the save ...")
    with open(save_path, "rb") as f:
        save_data = f.read()
    cc = patcher.detect_game_version(save_data)
    ss = parse_save.start_parse(save_data, cc)
    try:
        SAVE_VERSION = int(ss["game_version"]["Value"])
    except Exception:
        SAVE_VERSION = 150500
    cats = ss["cats"]
    base_l = ss["cat_upgrades"]["Base"]
    plus_l = ss["cat_upgrades"]["Plus"]
    cur_f = ss["current_forms"]
    unl_f = ss["unlocked_forms"]
    talents = ss["talents"]
    orb_equips = parse_orb_equips(ss.get("unknown_86", []))
    talent_orbs = ss["talent_orbs"]
    owned = [i for i, flag in enumerate(cats) if flag != 0]
    cannons = parse_cannons(ss)
    cat_fruit = ss.get("cat_fruit") or []
    battle_items = ss.get("battle_items") or []
    catseyes = ss.get("catseyes") or []
    raw_cat_food = ss.get("cat_food") or 0
    if isinstance(raw_cat_food, dict):
        raw_cat_food = raw_cat_food.get("Value", 0)
    cat_food = int(raw_cat_food or 0)
    raw_xp = ss.get("xp") or 0
    if isinstance(raw_xp, dict):
        raw_xp = raw_xp.get("Value", 0)
    xp = int(raw_xp or 0)
    raw_np = ss.get("np") or 0
    if isinstance(raw_np, dict):
        raw_np = raw_np.get("Value", 0)
    np = int(raw_np or 0)
    log(f"  game version: {ss['game_version']['Value']}, owned cats: {len(owned)}")
    if _ver_str(SAVE_VERSION) != GAME_VERSION:
        log(f"  WARNING: your save is v{_ver_str(SAVE_VERSION)} but the bundled data is v{GAME_VERSION};")
        log(f"  new/updated units will be fetched from BCData v{_ver_str(SAVE_VERSION)} when available.")
    log("  cat cannons: " + ", ".join(cannons))
    return (cats, base_l, plus_l, cur_f, unl_f, owned, talents, orb_equips,
            talent_orbs, cannons, cat_fruit, battle_items, catseyes, xp, cat_food, np)


def step_fetch(owned):
    log("[4/8] Making sure unit data is cached for every owned cat ...")
    import requests
    sess = requests.Session()
    missing = []
    for cid in owned:
        n = cid + 1
        tasks = [
            (os.path.join(CACHE, "units155", f"unit{n:03d}.csv"), f"DataLocal/unit{n:03d}.csv"),
            (os.path.join(CACHE, "resLocal", f"Unit_Explanation{n}_en.csv"), f"resLocal/Unit_Explanation{n}_en.csv"),
        ]
        for dest, rel in tasks:
            if os.path.exists(dest) and os.path.getsize(dest) > 0:
                continue
            v = fetch_file(sess, rel, dest)
            if v is not None:
                log(f"  fetched {os.path.basename(dest)} for cat {cid} (BCData v{v})")
            else:
                missing.append((cid, rel))
    if missing:
        log("  WARNING: could not fetch data for:", missing)
    else:
        log("  all unit data cached")


def step_combo_fetch():
    log("[5/8] Making sure combo + talent + orb data is cached ...")
    import requests
    sess = requests.Session()
    fetch = {fn: "" for fn in COMBO_FILES}
    fetch.update(TALENT_FILES)
    fetch.update(ORB_FILES)
    fetch.update(ITEM_FILES)
    fetch.update(EXTRA_FILES)
    for fn, subdir in fetch.items():
        dest = os.path.join(CACHE, fn)
        if os.path.exists(dest) and os.path.getsize(dest) > 0:
            continue
        v = fetch_file(sess, subdir + fn, dest)
        if v is not None:
            log(f"  fetched {fn} (BCData v{v})")
        else:
            log(f"  WARNING: could not fetch {fn}")


def invalidate_cache():
    """Wipe the downloaded BCData cache so a newer game version's data is re-fetched."""
    if os.path.isdir(CACHE):
        shutil.rmtree(CACHE)
        os.makedirs(CACHE)
    log("  invalidated BCData cache (game updated - will re-fetch for the new version)")


COMBO_SIZE = {0: "Sm", 1: "M", 2: "L", 3: "XL"}
NYANKO_ONLY = {"Red Strike", "Blue Strike", "Yellow Strike", "Green Strike", "Pink Strike", "Gold Silver Strike"}
TALENT_NAMES = {
    1: "Weaken", 2: "Freeze", 3: "Slow", 4: "Only Attacks", 5: "Strong", 6: "Tough Vs",
    7: "Massive Damage", 8: "Knockback", 9: "Warp", 10: "Strengthen", 11: "Survive",
    12: "Base Destroyer", 13: "Critical", 14: "Zombie Killer", 15: "Barrier Breaker",
    16: "Money Up", 17: "Wave Attack", 18: "Resist Weaken", 19: "Resist Freeze",
    20: "Resist Slow", 21: "Resist Knockback", 22: "Resist Wave", 23: "Wave Immunity",
    24: "Warp Resistant", 25: "Curse Immunity", 26: "Resist Curse", 27: "Defense Up",
    28: "Attack Up", 29: "Movement Speed Up", 30: "Knockback Rate Up", 31: "Deploy Cost Down",
    32: "Recharge Time Down", 33: "Target: Red", 34: "Target: Floating", 35: "Target: Black",
    36: "Target: Metal", 37: "Target: Angel", 38: "Target: Alien", 39: "Target: Zombie",
    40: "Target: Relic", 41: "Target: Traitless", 42: "Weaken Up", 43: "Freeze Up",
    44: "Slow Up", 45: "Knockback Up", 46: "Strengthen Up", 47: "Survive Up",
    48: "Critical Up", 49: "Barrier Breaker Up", 50: "Wave Attack Up", 51: "Warp Up",
    52: "Critical", 53: "Immune to Weaken", 54: "Immune to Freeze", 55: "Immune to Slow",
    56: "Immune to Knockback", 57: "Immune to Waves", 58: "Warp Blocker", 59: "Savage Blow",
    60: "Dodge", 61: "Savage Blow Up", 62: "Dodge Up", 63: "Slow Up", 64: "Resist Toxic",
    65: "Immune to Toxic", 66: "Resist Surge", 67: "Immune to Surge", 68: "Surge Attack",
    69: "Slow Relic", 70: "Weaken Relic", 71: "Weaken Alien", 72: "Slow Metal",
    73: "Knockback Zombie", 74: "Freeze Up", 75: "Knockback Aliens", 76: "Freeze Metal",
    77: "Target: Aku", 78: "Shield Piercing", 79: "Soulstrike", 80: "Curse",
    81: "Dodge Strengthen", 82: "Attack Frequency Up", 83: "Mini-Wave", 84: "Immune to Zombies",
    85: "Colossus Slayer", 86: "Behemoth Slayer", 87: "Dodge Traitless", 88: "Dodge",
    89: "Mini-Surge", 90: "Dodge All Attacks", 91: "Sage Slayer", 92: "Strong vs Relics",
    93: "Curse Up", 94: "Explosion", 95: "Dodge Metal", 96: "Counter-Surge",
    97: "Immune to Explosion", 98: "Weaken vs All", 99: "Freeze vs All", 100: "Slow vs All",
    101: "Knockback vs All", 102: "Curse vs All",
}


def combo_value(eff, lv, params):
    v = 0
    if 0 < eff <= len(params):
        row = params[eff - 1]
        if 0 <= lv < len(row):
            try:
                v = int(row[lv])
            except ValueError:
                v = 0
    if eff == 4:
        return f"+{v}%"
    if eff == 5:
        return f"+{v} worker level"
    if eff == 6:
        return f"+{v} starting money"
    if eff == 25:
        return f"+{v}% crit rate"
    if eff == 26:
        return f"{v/1000:g}x dmg"
    if eff == 28:
        return f"-{v}% deploy cost"
    if eff in (27, 29):
        return "full immunity"
    return f"+{v}%"


def step_combos(owned, cur_f, unl_f, total):
    log("[7/8] Building the combo list ...")
    hi = {i: max(cur_f[i], unl_f[i]) for i in owned}
    with open(os.path.join(CACHE, "NyancomboData.csv"), encoding="utf-8-sig", newline="") as f:
        data = [[int(x.strip()) if x.strip() else 0 for x in row] for row in csv.reader(f)
                if row and row[0].strip()]
    names = [l.rstrip("\n").strip("|").strip() for l in open(os.path.join(CACHE, "Nyancombo_en.csv"), encoding="utf-8-sig")]
    effnames = [l.rstrip("\n").strip("|").strip() for l in open(os.path.join(CACHE, "Nyancombo1_en.csv"), encoding="utf-8-sig")]
    params = [l.rstrip("\n").split("\t") for l in open(os.path.join(CACHE, "NyancomboParam.tsv"), encoding="utf-8-sig") if l.strip()]

    avail = []
    for i, r in enumerate(data):
        if r[1] == -1:
            continue
        units = [(r[3 + 2 * j], r[4 + 2 * j]) for j in range(5) if r[3 + 2 * j] >= 0]
        if not all(hi.get(u, -1) >= f for u, f in units):
            continue
        eff, lv = r[13] + 1, r[14]
        eff_disp = effnames[eff - 1] if eff - 1 < len(effnames) else f"Effect {eff}"
        if lv in COMBO_SIZE:
            eff_disp = f"{eff_disp} ({COMBO_SIZE[lv]})"
        val = combo_value(eff, lv, params)
        mem = []
        for u, f in units:
            nms = names_for(u)
            nm = nms[f] if nms and f < len(nms) and nms[f] else (nms[0] if nms else f"Cat {u}")
            mem.append({"id": u, "form": f, "name": nm, "label": FORM_LABEL.get(f, f"F{f}")})
        nm = names[i] if i < len(names) and names[i] else f"(Unnamed) Combo {r[0]}"
        note = " [Nyanko Rangers only]" if nm in NYANKO_ONLY else ""
        avail.append({"name": nm, "effect": eff_disp, "value": val,
                      "members": mem, "members_str": " + ".join(f"{m['name']} ({m['label']})" for m in mem),
                      "note": note})

    avail.sort(key=lambda x: x["name"].lower())
    lines = [
        f"BATTLE CATS COMBOS - EN v{GAME_VERSION} ({total} owned cats) - {len(avail)} combos you can activate",
        "A combo works when you own every cat in it at the required form (or a more advanced form).",
        "Effect sizes: Sm / M / L / XL.  Values are the game's raw magnitudes.",
        "'[Nyanko Rangers only]' = the buff applies only to Nyanko Rangers, not all cats.",
        "-" * 130,
    ]
    for c in avail:
        lines.append(f"{c['name']:<30} | {c['effect']:<34} | {c['value']:<12} | {c['members_str']}{c['note']}")
    section("COMBOS", lines)
    log(f"  {len(avail)} available combos")
    return avail


def load_talent_trees():
    trees = {}
    with open(os.path.join(CACHE, "SkillAcquisition.csv"), encoding="utf-8-sig", newline="") as f:
        for row in csv.DictReader(f):
            cid = int(row["ID"])
            slots = []
            for L in "ABCDEFGH":
                ab = row.get(f"abilityID_{L}")
                if ab is None or ab == "":
                    continue
                ab_i = int(ab)
                tid = int(row[f"tFxtID_F" if L == "F" else f"textID_{L}"])
                if ab_i == 0 or tid == 0:
                    continue
                slots.append({
                    "slot": L,
                    "ability": ab_i,
                    "max": int(row[f"MAXLv_{L}"]) or 1,
                    "text": tid,
                })
            trees[cid] = slots
    return trees


def talent_name(cid, ability, trees):
    for s in trees.get(cid, []):
        if s["ability"] == ability:
            return TALENT_NAMES.get(s["text"], f"Talent {s['text']}")
    return f"Ability {ability}"


def parse_orb_equips(raw):
    out = {}
    vals = [d["Value"] for d in raw]
    i = 0
    n = vals[i] if vals else 0
    i += 1
    for _ in range(n):
        cid = vals[i]; i += 1
        m = vals[i]; i += 1
        slots = []
        for _ in range(m):
            pos, oid = vals[i], vals[i + 1]
            i += 2
            slots.append((pos, oid))
        out[cid] = slots
    return out


def load_orb_names():
    data = json.load(open(os.path.join(CACHE, "equipmentlist.json"), encoding="utf-8"))
    grade = csv_handler.parse_csv(open(os.path.join(CACHE, "equipmentgrade.csv"), encoding="utf-8-sig").read(), ",")
    attr = csv_handler.parse_csv(open(os.path.join(CACHE, "attribute_explonation.tsv"), encoding="utf-8-sig").read(), "\t")
    eff = csv_handler.parse_csv(open(os.path.join(CACHE, "equipment_explonation.tsv"), encoding="utf-8-sig").read(), "\t")
    names = {}
    for i, o in enumerate(data["ID"]):
        g = grade[o["gradeID"]][3]
        e = eff[o["content"]][0]
        try:
            if "attribute" in o:
                a = attr[o["attribute"]][0]
                names[i] = e.replace("%@", "{}").format(g, a).strip()
            else:
                names[i] = e.replace("%@", "{}").format(g).strip()
        except IndexError:
            names[i] = f"Orb {i}"
    return names


def step_talents(owned, talents, orb_equips, talent_orbs, total):
    log("[8/8] Building the talent + orb list ...")
    trees = load_talent_trees()

    have = sorted(set(owned) & set(trees))
    spent = {int(k): [t for t in v if t["level"] > 0] for k, v in talents.items() if any(t["level"] > 0 for t in v)}

    lines = [
        f"BATTLE CATS TALENTS - EN v{GAME_VERSION} ({total} owned cats)",
        "'Has a talent tree' = this cat can unlock talents (True Form).  'NP spent' = you've spent NP on it.",
        "Levels shown as current/max.",
        "=" * 100,
        "",
        f"CATS YOU OWN THAT HAVE A TALENT TREE ({len(have)}):",
    ]
    for cid in have:
        nms = names_for(cid)
        nm = nms[0] if nms else f"Cat {cid}"
        tlist = ", ".join(f"{talent_name(cid, s['ability'], trees)} ({s['max']})" for s in trees[cid])
        lines.append(f"  [{cid:3d}] {nm}: {tlist}")
    lines.append("")
    lines.append(f"CATS YOU'VE SPENT NP ON ({len(spent)}):")
    if not spent:
        lines.append("  (none)")
    for cid in sorted(spent):
        nms = names_for(cid)
        nm = nms[0] if nms else f"Cat {cid}"
        lines.append(f"  [{cid:3d}] {nm}:")
        for t in spent[cid]:
            mx = next((s["max"] for s in trees.get(cid, []) if s["ability"] == t["id"]), "?")
            lines.append(f"      {talent_name(cid, t['id'], trees)}  Lv {t['level']}/{mx}")

    orb_names = load_orb_names()
    lines.append("")
    lines.append(f"CATS WITH TALENT ORB SLOTS ({len(orb_equips)}):")
    if not orb_equips:
        lines.append("  (none)")
    for cid in sorted(orb_equips):
        nms = names_for(cid)
        nm = nms[0] if nms else f"Cat {cid}"
        parts = []
        for pos, oid in orb_equips[cid]:
            if oid == 65535:
                parts.append(f"slot {pos + 1}: empty")
            else:
                parts.append(f"slot {pos + 1}: {orb_names.get(oid, f'Orb {oid}')}")
        lines.append(f"  [{cid:3d}] {nm}: {', '.join(parts)}")

    inv = {int(k): v for k, v in talent_orbs.items() if v > 0}
    lines.append("")
    lines.append(f"ORB INVENTORY ({len(inv)} types, count > 0):")
    if not inv:
        lines.append("  (none)")
    for oid in sorted(inv):
        lines.append(f"  {orb_names.get(oid, f'Orb {oid}')}: x{inv[oid]}")

    section("TALENTS + ORBS", lines)
    log(f"  {len(have)} cats with talent trees, {len(spent)} with NP spent, {len(orb_equips)} with orb slots")


def step_combine():
    out = [f"THE BATTLE CATS - COMPLETE DATA EXPORT (EN v{GAME_VERSION})",
           "Combined sections: SAVE REPORT, ROSTER (AI-FRIENDLY), COMBOS, TALENTS + ORBS.",
           "-" * 100]
    for title, lines in SECTIONS:
        out.append("")
        out.append("=" * 100)
        out.append(title)
        out.append("=" * 100)
        out.extend(lines)
    with open(os.path.join(TMP, "cats_all.txt"), "w", encoding="utf-8") as f:
        f.write("\n".join(out) + "\n")
    log(f"  combined {len(SECTIONS)} sections into cats_all.txt")


def deliver():
    for fn in OUTPUT_FILES:
        src = os.path.join(TMP, fn)
        if os.path.exists(src):
            shutil.copy(src, os.path.join(DELIV, fn))
            log(f"  updated {fn}")


def evolve_forms_for(i, ub_row, mf):
    """Build per-form evolution requirements from unitbuy.csv columns.

    Cols: 21 = evolved-form level, 25 = TF level (-1 = no catfruit/special),
    26 = UF level, 27 = TF XP cost, 28-37 = TF item id/count pairs,
    38 = UF XP cost, 39-48 = UF item id/count pairs.
    """
    def cell(n, default=0):
        try:
            v = ub_row[n].strip()
            if not v:
                return default
            if v == "-1":
                return -1
            return int(v)
        except (IndexError, ValueError):
            return default

    def items_from(start):
        out = []
        for k in range(5):
            iid, cnt = cell(start + 2 * k), cell(start + 2 * k + 1)
            if iid > 0 and cnt > 0:
                out.append({"id": iid, "name": item_name(iid), "count": cnt})
        return out

    forms = {}
    lvl_evolved = cell(21, 10)
    if lvl_evolved < 0:
        lvl_evolved = 10
    forms["1"] = {"level": lvl_evolved, "xp": 0, "items": []}
    if mf >= 3:
        lvl_tf = cell(25, -1)
        if lvl_tf >= 0:
            forms["2"] = {"level": lvl_tf, "xp": cell(27), "items": items_from(28)}
        else:
            forms["2"] = {"level": None, "xp": 0, "items": [], "special": True}
    if mf >= 4:
        lvl_uf = cell(26, -1)
        if lvl_uf >= 0:
            forms["3"] = {"level": lvl_uf, "xp": cell(38), "items": items_from(39)}
        else:
            forms["3"] = {"level": None, "xp": 0, "items": [], "special": True}
    return {"forms": forms}


def step_build(cats, base_l, plus_l, cur_f, unl_f, owned, save_mtime, talents, orb_equips):
    log("[6/8] Building the report files ...")
    pb = csv_handler.parse_csv(open(os.path.join(CACHE, "nyankoPictureBookData.csv"), encoding="utf-8").read(), ",")
    max_form = [row[2] for row in helper.parse_int_list_list(pb)]

    ub = csv_handler.parse_csv(open(os.path.join(CACHE, "unitbuy.csv"), encoding="utf-8").read(), ",")
    rarity = [row[13] if len(row) > 13 else -1 for row in helper.parse_int_list_list(ub)]

    trees = load_talent_trees()
    orb_names = load_orb_names()

    missing_units = []
    rows = []
    for i in owned:
        mf = max_form[i] if i < len(max_form) else 0
        nm = names_for(i)
        base_name = nm[0] if nm else f"Cat id {i}"
        cur = cur_f[i]
        unl = unl_f[i]
        true_avail = (mf >= 3) and (cur >= 2 or unl >= 2)
        if i in (92, 93, 94, 95, 96, 97, 98, 99):
            true_avail = "unknown"
        cur_name = nm[cur] if nm and cur < len(nm) and nm[cur] else base_name
        cur_label = FORM_LABEL.get(cur, f"F{cur}")
        rar_id = rarity[i] if i < len(rarity) else -1

        up = os.path.join(CACHE, "units155", f"unit{i+1:03d}.csv")
        forms = []
        try:
            with open(up, encoding="utf-8-sig", newline="") as f:
                for row in csv.reader(f):
                    if not row or not row[0].strip():
                        continue
                    forms.append(decode_form(row))
        except FileNotFoundError:
            missing_units.append(i)

        per_form = []
        for fi, fv in enumerate(forms):
            ab, tgs = abilities_for(fv)
            im = immunities_for(fv)
            per_form.append({"form": fi, "abilities": ab, "traits": tgs, "immunities": im})

        if forms and cur < len(forms):
            cur_ab, cur_tgs = abilities_for(forms[cur])
            cur_im = immunities_for(forms[cur])
        else:
            cur_ab, cur_tgs, cur_im = [], [], []

        spent = []
        for s in trees.get(i, []):
            lv = next((t["level"] for t in talents.get(i, []) if t["id"] == s["ability"]), 0)
            if lv > 0:
                spent.append({"name": TALENT_NAMES.get(s["text"], f"Talent {s['text']}"),
                              "level": lv, "max": s["max"]})

        slots = orb_equips.get(i, [])
        orbs = [{"slot": p + 1, "name": (orb_names.get(o, f"Orb {o}") if o != 65535 else "(empty)")}
                for p, o in slots]

        ub_row = ub[i] if i < len(ub) else []

        rows.append({
            "id": i,
            "base_name": base_name,
            "rarity": RARITY_NAMES.get(rar_id, f"Rarity{rar_id}"),
            "rarity_id": rar_id,
            "level": f"{base_l[i]+1}+{plus_l[i]}",
            "level_base": base_l[i]+1,
            "level_plus": plus_l[i],
            "cur_name": cur_name,
            "cur_label": cur_label,
            "cur": cur,
            "unl": unl,
            "mf": mf,
            "true_avail": true_avail,
            "traits": cur_tgs,
            "abilities": cur_ab,
            "immunities": cur_im,
            "forms": per_form,
            "talents_spent": spent,
            "orbs": orbs,
            "evolve": evolve_forms_for(i, ub_row, mf),
        })

    rows.sort(key=lambda r: (RARITY_NAMES.get(r["rarity_id"], "z"), r["base_name"].lower(), r["id"]))
    total = len(rows)

    if missing_units:
        log("  WARNING: no unit data for cats " + ", ".join(str(i) for i in sorted(missing_units)) + " (stats/DPS unavailable)")
    unknown_rarity = [r["id"] for r in rows if r["rarity_id"] < 0]
    if unknown_rarity:
        log("  WARNING: no rarity data for cats " + ", ".join(str(i) for i in unknown_rarity) + " (not in the bundled unit tables)")

    report = {
        "game": "The Battle Cats (EN)",
        "version": GAME_VERSION,
        "source": "decoded save file + game unit data (DataLocal/unit{id+1}.csv)",
        "cat_total_slots": len(cats),
        "cats_owned": total,
        "save_file_mtime": save_mtime,
        "rarity_legend": RARITY_NAMES,
        "form_legend": FORM_LABEL,
        "ability_note": "traits/abilities/immunities listed for the CURRENT form only; per-form data under 'forms'.",
        "cats": rows,
    }
    with open(os.path.join(TMP, "cats_report.json"), "w", encoding="utf-8") as f:
        json.dump(report, f, indent=1, ensure_ascii=False)

    list_lines = [f"BATTLE CATS SAVE REPORT  (EN v{GAME_VERSION}, decoded save, {total} owned cats)",
                  "Rarity: Normal | Special | Rare | Super Rare | Uber Rare | Legend Rare",
                  "Form: Base / Evolved / True / Ultra   |   TF = True form unlocked (yes/?/no)",
                  "Abilities are for the CURRENT form.  Targets = enemy traits its abilities affect.",
                  "=" * 110]
    for r in rows:
        tf = "yes" if r["true_avail"] is True else ("?" if r["true_avail"] == "unknown" else "-")
        tr = ", ".join(r["traits"]) if r["traits"] else "none"
        ab = "; ".join(r["abilities"]) if r["abilities"] else "none"
        im = ", ".join(r["immunities"]) if r["immunities"] else "none"
        list_lines.append(f"[{r['id']:3d}] {r['base_name']:<30} {r['rarity']:<11} Lv {r['level']:<6} | now: {r['cur_name']} ({r['cur_label']}) | TF: {tf}")
        list_lines.append(f"      traits: {tr}")
        list_lines.append(f"      abilities: {ab}")
        list_lines.append(f"      immune to: {im}")
    section("SAVE REPORT", list_lines)

    lines = [f"BATTLE CATS ROSTER - EN v{GAME_VERSION} save, {total} owned cats"]
    lines.append("COLUMNS: id | name | rarity | level_base | level_plus | current_form(0=Base,1=Evolved,2=True,3=Ultra) | current_form_name | true_form_unlocked | targets | abilities | immune_to")
    lines.append("NOTES: targets = enemy traits the cat's abilities affect (Traitless = non-trait 'White' enemies). Abilities/immunities are for the CURRENT form. Durations in seconds; 'vs X' suffix = that ability only affects listed target traits. immune_to = status effects the cat is IMMUNE TO (defensive), NOT abilities.")
    lines.append("-" * 160)
    for c in rows:
        tf = "yes" if c["true_avail"] is True else ("unknown" if c["true_avail"] == "unknown" else "no")
        tr = ", ".join(c["traits"]) if c["traits"] else "none"
        ab = "; ".join(c["abilities"]) if c["abilities"] else "none"
        im = "Immune: " + ", ".join(c["immunities"]) if c["immunities"] else "none"
        lines.append(f"{c['id']:4d} | {c['base_name']} | {c['rarity']} | {c['level_base']:3d} | {c['level_plus']:3d} | {c['cur']} | {c['cur_name']} | {tf} | {tr} | {ab} | {im}")
    section("ROSTER (AI-FRIENDLY)", lines)

    return rows


def append_changes(lines, header=""):
    import datetime
    if not lines:
        return
    with open(CHANGES_LOG, "a", encoding="utf-8") as f:
        f.write(f"\n===== {datetime.datetime.now():%Y-%m-%d %H:%M:%S} =====\n")
        if header:
            f.write(header + "\n")
        for l in lines:
            f.write(l + "\n")


def summary(rows):
    from collections import Counter
    prev = os.path.join(DELIV, "cats_report.json")
    new_by = {r["id"]: r for r in rows}
    changes = []
    if os.path.exists(prev):
        old = json.load(open(prev, encoding="utf-8"))
        old_by = {c["id"]: c for c in old.get("cats", [])}
        added = sorted(set(new_by) - set(old_by))
        removed = sorted(set(old_by) - set(new_by))
        if added:
            changes.append("NEW CATS: " + ", ".join(f"[{i}] {new_by[i]['base_name']}" for i in added))
        if removed:
            changes.append("REMOVED: " + ", ".join(f"[{i}] {old_by[i]['base_name']}" for i in removed))
        leveled, evolved, talup, orbc = [], [], [], []
        for i in sorted(new_by):
            if i not in old_by:
                continue
            o, n = old_by[i], new_by[i]
            if n["level_base"] > o["level_base"] or n["level_plus"] > o["level_plus"]:
                leveled.append(f"[{i}] {n['base_name']} Lv{o['level_base']}+{o['level_plus']} -> Lv{n['level_base']}+{n['level_plus']}")
            if n["cur"] > o["cur"]:
                evolved.append(f"[{i}] {n['base_name']} {o['cur_name']} ({o['cur_label']}) -> {n['cur_name']} ({n['cur_label']})")
            elif n["unl"] > o["unl"]:
                # Form unlocked but not switched yet — show the newly unlocked form name
                nm = names_for(i)
                new_form_name = nm[n["unl"]] if nm and n["unl"] < len(nm) and nm[n["unl"]] else f"Form {n['unl']}"
                new_form_label = FORM_LABEL.get(n["unl"], f"F{n['unl']}")
                evolved.append(f"[{i}] {n['base_name']}: {new_form_name} ({new_form_label}) unlocked")
            if "talents_spent" in o and "talents_spent" in n:
                o_t = {t["name"]: t["level"] for t in o["talents_spent"]}
                for t in n["talents_spent"]:
                    if t["level"] > o_t.get(t["name"], 0):
                        talup.append(f"[{i}] {n['base_name']}: {t['name']} Lv{o_t.get(t['name'], 0)} -> Lv{t['level']}")
            if "orbs" in o and "orbs" in n:
                o_s = [(t["slot"], t["name"]) for t in o["orbs"]]
                n_s = [(t["slot"], t["name"]) for t in n["orbs"]]
                if n_s != o_s:
                    desc = ", ".join(f"slot{s}={nm}" for s, nm in n_s) or "no orbs"
                    orbc.append(f"[{i}] {n['base_name']}: {desc}")
        if leveled:
            changes.append("LEVELED UP:")
            changes += [f"  {l}" for l in leveled]
        if evolved:
            changes.append("FORM CHANGED / UNLOCKED:")
            changes += [f"  {e}" for e in evolved]
        if talup:
            changes.append("TALENTS UPGRADED:")
            changes += [f"  {t}" for t in talup]
        if orbc:
            changes.append("ORBS CHANGED:")
            changes += [f"  {o}" for o in orbc]
        if changes:
            for l in changes:
                log(l)
            append_changes(changes)
        else:
            log("No changes since the last run.")
    rc = Counter(r["rarity"] for r in rows)
    log("Total:", len(rows))
    for k in RARITY_NAMES.values():
        log(f"  {k}: {rc.get(k, 0)}")


def main():
    save_path = step_extract()
    save_mtime = time.ctime(os.path.getmtime(save_path))
    (cats, base_l, plus_l, cur_f, unl_f, owned, talents, orb_equips,
     talent_orbs, cannons, cat_fruit, battle_items, xp, _cat_food, _np) = step_parse(save_path)
    step_fetch(owned)
    step_combo_fetch()
    rows = step_build(cats, base_l, plus_l, cur_f, unl_f, owned, save_mtime, talents, orb_equips)
    step_combos(owned, cur_f, unl_f, len(rows))
    step_talents(owned, talents, orb_equips, talent_orbs, len(rows))
    step_combine()
    summary(rows)
    deliver()
    log("Done. Files updated in:", DELIV)


if __name__ == "__main__":
    main()
